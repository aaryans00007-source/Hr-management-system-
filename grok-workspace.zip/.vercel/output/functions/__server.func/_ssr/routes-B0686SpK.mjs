import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Calendar, a as Settings, b as Building2, c as Menu, d as Files, f as FileChartColumnIncreasing, g as Check, h as ChevronDown, i as TrendingUp, l as LayoutDashboard, m as ChevronLeft, n as Users, o as Receipt, p as ChevronRight, s as Plus, t as X, u as IndianRupee, v as CalendarDays, x as Bell, y as CalendarCheck } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { a as Area, c as ResponsiveContainer, i as XAxis, l as Tooltip, n as BarChart, o as CartesianGrid, r as YAxis, s as Bar, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B0686SpK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TODAY = "2026-10-08";
var TARGET_NET = 8245600;
var DEPARTMENTS = [
	"Product",
	"Marketing",
	"Sales",
	"HR",
	"Finance",
	"Engineering",
	"Operations",
	"Support",
	"Design"
];
var ROLES = {
	Product: [
		"Product Manager",
		"Associate PM",
		"Product Analyst"
	],
	Marketing: [
		"Marketing Lead",
		"Content Strategist",
		"Growth Associate"
	],
	Sales: [
		"Sales Executive",
		"Account Manager",
		"Sales Lead"
	],
	HR: [
		"HR Executive",
		"HR Manager",
		"Recruiter"
	],
	Finance: [
		"Finance Analyst",
		"Accountant",
		"Finance Manager"
	],
	Engineering: [
		"Software Engineer",
		"Senior Engineer",
		"QA Engineer"
	],
	Operations: [
		"Ops Executive",
		"Ops Manager",
		"Admin Associate"
	],
	Support: [
		"Support Executive",
		"Support Lead",
		"Customer Associate"
	],
	Design: [
		"Product Designer",
		"Visual Designer",
		"Design Intern"
	]
};
var DOC_CATEGORIES = [
	"Policy",
	"Payroll",
	"Offer",
	"ID proof",
	"Other"
];
var LEAVE_QUOTA = {
	Casual: 12,
	Sick: 8,
	Earned: 15,
	Unpaid: 365
};
var LEAVE_TYPES = [
	"Casual",
	"Sick",
	"Earned",
	"Unpaid"
];
var HOLIDAYS = /* @__PURE__ */ new Set([
	"2026-01-26",
	"2026-08-15",
	"2026-10-02"
]);
var MONTH_NAMES = [
	"January",
	"February",
	"March",
	"April",
	"May",
	"June",
	"July",
	"August",
	"September",
	"October",
	"November",
	"December"
];
var SHORT_MONTHS = [
	"Jan",
	"Feb",
	"Mar",
	"Apr",
	"May",
	"Jun",
	"Jul",
	"Aug",
	"Sep",
	"Oct",
	"Nov",
	"Dec"
];
function monthLabel(ym) {
	const [y, m] = ym.split("-");
	return `${MONTH_NAMES[Number(m) - 1] ?? ym} ${y}`;
}
function shortMonth(ym) {
	return SHORT_MONTHS[Number(ym.split("-")[1]) - 1] ?? ym;
}
function inr(n) {
	const rounded = Math.round(n);
	const formatted = Math.abs(rounded).toLocaleString("en-IN");
	return `${rounded < 0 ? "-" : ""}₹ ${formatted}`;
}
function isoDate(d) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function prettyDate(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return `${d} ${SHORT_MONTHS[(m ?? 1) - 1]} ${y}`;
}
function isWeekoff(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	const day = new Date(y, (m ?? 1) - 1, d).getDay();
	return day === 0 || day === 6;
}
function isHoliday(iso) {
	return HOLIDAYS.has(iso);
}
function weekdayShort(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return [
		"Sun",
		"Mon",
		"Tue",
		"Wed",
		"Thu",
		"Fri",
		"Sat"
	][new Date(y, (m ?? 1) - 1, d).getDay()];
}
function monthEndIso(ym) {
	const [y, m] = ym.split("-").map(Number);
	return isoDate(new Date(y, m, 0));
}
function daysInMonth(ym) {
	const [y, m] = ym.split("-").map(Number);
	return new Date(y, m, 0).getDate();
}
function monthDates(ym) {
	const n = daysInMonth(ym);
	return Array.from({ length: n }, (_, i) => `${ym}-${String(i + 1).padStart(2, "0")}`);
}
function eachWorkingDay(from, to) {
	const out = [];
	const [ys, ms, ds] = from.split("-").map(Number);
	const [ye, me, de] = to.split("-").map(Number);
	const cur = new Date(ys, (ms ?? 1) - 1, ds);
	const end = new Date(ye, (me ?? 1) - 1, de);
	if (Number.isNaN(cur.getTime()) || Number.isNaN(end.getTime()) || cur > end) return out;
	while (cur <= end) {
		const iso = isoDate(cur);
		if (!isWeekoff(iso) && !isHoliday(iso)) out.push(iso);
		cur.setDate(cur.getDate() + 1);
	}
	return out;
}
function grossOf(e) {
	return e.basic + e.hra + e.special;
}
function statutoryOf(e) {
	return e.pf + e.tax + e.other;
}
function codeNum(code) {
	return Number(code.replace(/\D/g, "")) || 0;
}
function byCode(a, b) {
	return codeNum(a.code) - codeNum(b.code);
}
function nextIdentity(employees) {
	const max = employees.reduce((m, e) => Math.max(m, codeNum(e.code)), 0) + 1;
	return {
		id: `e${String(max).padStart(3, "0")}`,
		code: `EMP${String(max).padStart(3, "0")}`
	};
}
function employeeMap(list) {
	return new Map(list.map((e) => [e.id, e]));
}
function eligible(e, month) {
	return e.status === "active" && e.joinDate <= monthEndIso(month);
}
function dayKind(employee, date, marks) {
	if (date < employee.joinDate) return "absent";
	if (isHoliday(date)) return "holiday";
	if (isWeekoff(date)) return "weekoff";
	return marks.find((m) => m.employeeId === employee.id && m.date === date)?.status ?? "present";
}
function lopDays(employee, month, marks) {
	let lop = 0;
	for (const date of monthDates(month)) {
		if (date < employee.joinDate) continue;
		const kind = dayKind(employee, date, marks);
		if (kind === "absent" || kind === "unpaid") lop += 1;
		else if (kind === "half") lop += .5;
	}
	return lop;
}
function blankLine(employee) {
	const gross = grossOf(employee);
	const deductions = statutoryOf(employee);
	return {
		employeeId: employee.id,
		gross,
		deductions,
		net: gross - deductions,
		bonus: 0,
		lop: 0,
		extra: 0
	};
}
function computeLive(data, month) {
	const days = Math.max(1, data.settings.workingDays);
	return data.employees.filter((e) => eligible(e, month)).sort(byCode).map((e) => {
		const gross = grossOf(e);
		const statutory = statutoryOf(e);
		const adj = data.adjustments[`${month}:${e.id}`] ?? {
			bonus: 0,
			extra: 0
		};
		const bonus = Math.max(0, Math.round(adj.bonus || 0));
		const extra = Math.max(0, Math.round(adj.extra || 0));
		const lop = Math.round(gross / days * lopDays(e, month, data.marks));
		const deductions = statutory + extra + lop;
		return {
			employeeId: e.id,
			gross,
			deductions,
			net: gross + bonus - deductions,
			bonus,
			lop,
			extra
		};
	});
}
function linesFor(data, month) {
	const snap = data.snapshots[month];
	if (snap) return {
		lines: snap,
		locked: true
	};
	return {
		lines: computeLive(data, month),
		locked: false
	};
}
function sumLines(lines) {
	return lines.reduce((a, l) => ({
		gross: a.gross + l.gross + l.bonus,
		deductions: a.deductions + l.deductions,
		net: a.net + l.net,
		lop: a.lop + l.lop,
		count: a.count + 1
	}), {
		gross: 0,
		deductions: 0,
		net: 0,
		lop: 0,
		count: 0
	});
}
function leaveReserved(leaves, employeeId, type) {
	return leaves.filter((l) => l.employeeId === employeeId && l.type === type && l.status !== "rejected").reduce((s, l) => s + l.days, 0);
}
function notifications(data) {
	const items = [];
	const pending = data.leaves.filter((l) => l.status === "pending");
	if (pending.length) items.push({
		id: "leave",
		title: `${pending.length} leave ${pending.length === 1 ? "request" : "requests"} waiting`,
		detail: "Approve or reject before payroll locks",
		view: "leave"
	});
	const dueMonth = TODAY.slice(0, 7);
	const day = Number(TODAY.slice(8, 10));
	if (!data.snapshots[dueMonth] && day >= data.settings.payDay) items.push({
		id: "pay",
		title: `${monthLabel(dueMonth)} payroll is due`,
		detail: `Pay day is the ${data.settings.payDay}th. Review LOP and complete the run.`,
		view: "payroll"
	});
	return items;
}
function mulberry32(seed) {
	let a = seed >>> 0;
	return () => {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function splitPay(gross, ded) {
	const basic = Math.round(gross * .62);
	let hra = Math.round((gross - basic) * .66);
	if (basic + hra > gross) hra = gross - basic;
	const special = gross - basic - hra;
	const pf = Math.round(ded * .62);
	let tax = Math.round((ded - pf) * .75);
	if (pf + tax > ded) tax = ded - pf;
	const other = ded - pf - tax;
	return {
		basic,
		hra,
		special,
		pf,
		tax,
		other
	};
}
function scaleLines(lines, factor) {
	if (factor === 1) return lines;
	const target = Math.round(lines.reduce((s, l) => s + l.net, 0) * factor);
	const next = lines.map((l) => {
		const gross = Math.max(0, Math.round(l.gross * factor));
		const deductions = Math.max(0, Math.round(l.deductions * factor));
		return {
			...l,
			gross,
			deductions,
			net: gross - deductions,
			bonus: 0,
			lop: 0,
			extra: 0
		};
	});
	let diff = target - next.reduce((s, l) => s + l.net, 0);
	let i = 0;
	while (diff !== 0 && i < next.length * 50) {
		const line = next[i % next.length];
		if (!line) break;
		if (diff > 0) {
			line.gross += 1;
			line.net += 1;
			diff -= 1;
		} else if (line.net > 1 && line.gross > 1) {
			line.gross -= 1;
			line.net -= 1;
			diff += 1;
		}
		i += 1;
	}
	return next;
}
var FIRST_M = [
	"Vivaan",
	"Aditya",
	"Vihaan",
	"Arjun",
	"Reyansh",
	"Ayaan",
	"Ishaan",
	"Shaurya",
	"Atharv",
	"Advik",
	"Pranav",
	"Kabir",
	"Dhruv",
	"Rudra",
	"Virat",
	"Dev",
	"Harsh",
	"Kunal",
	"Manav",
	"Nikhil",
	"Rahul",
	"Siddharth",
	"Tarun",
	"Varun",
	"Amit",
	"Deepak",
	"Gaurav",
	"Jatin",
	"Lokesh",
	"Mohit",
	"Naveen",
	"Pankaj",
	"Sachin",
	"Tushar",
	"Uday",
	"Vikas",
	"Ankit",
	"Rohit",
	"Karan",
	"Aarav"
];
var FIRST_F = [
	"Aanya",
	"Ananya",
	"Diya",
	"Myra",
	"Sara",
	"Ira",
	"Anika",
	"Navya",
	"Kiara",
	"Pari",
	"Anvi",
	"Prisha",
	"Kavya",
	"Isha",
	"Mira",
	"Riya",
	"Saanvi",
	"Avni",
	"Meera",
	"Nisha",
	"Shreya",
	"Tanvi",
	"Aditi",
	"Divya",
	"Ishita",
	"Khushi",
	"Lavanya",
	"Nikita",
	"Palak",
	"Ritika",
	"Sneha",
	"Trisha",
	"Vidya",
	"Anjali",
	"Bhavya",
	"Neha",
	"Pooja",
	"Gauri",
	"Heena",
	"Juhi"
];
var LAST = [
	"Sharma",
	"Verma",
	"Singh",
	"Patel",
	"Mehta",
	"Gupta",
	"Reddy",
	"Iyer",
	"Nair",
	"Khan",
	"Joshi",
	"Kapoor",
	"Malhotra",
	"Chopra",
	"Bose",
	"Das",
	"Banerjee",
	"Rao",
	"Pillai",
	"Jain",
	"Agarwal",
	"Mishra",
	"Yadav",
	"Chauhan",
	"Saxena",
	"Bhatt",
	"Shah",
	"Menon",
	"Naidu",
	"Gill",
	"Bansal",
	"Arora",
	"Khanna",
	"Sethi",
	"Dubey",
	"Pandey",
	"Tiwari",
	"Thakur",
	"Shetty",
	"Hegde"
];
function buildEmployees() {
	const named = [
		{
			id: "e001",
			code: "EMP001",
			name: "Aarav Sharma",
			gender: "m",
			department: "Product",
			designation: "Product Manager",
			email: "aarav.sharma@abcpvt.in",
			phone: "9811122301",
			joinDate: "2022-04-11",
			status: "active",
			basic: 45e3,
			hra: 18e3,
			special: 5750,
			pf: 5400,
			tax: 2500,
			other: 750
		},
		{
			id: "e002",
			code: "EMP002",
			name: "Neha Verma",
			gender: "f",
			department: "Marketing",
			designation: "Marketing Lead",
			email: "neha.verma@abcpvt.in",
			phone: "9822233402",
			joinDate: "2023-01-16",
			status: "active",
			basic: 36e3,
			hra: 14400,
			special: 5e3,
			pf: 4320,
			tax: 1500,
			other: 380
		},
		{
			id: "e003",
			code: "EMP003",
			name: "Rohit Singh",
			gender: "m",
			department: "Sales",
			designation: "Sales Executive",
			email: "rohit.singh@abcpvt.in",
			phone: "9833344503",
			joinDate: "2021-08-02",
			status: "active",
			basic: 48e3,
			hra: 19200,
			special: 5100,
			pf: 5760,
			tax: 3e3,
			other: 690
		},
		{
			id: "e004",
			code: "EMP004",
			name: "Pooja Mehta",
			gender: "f",
			department: "HR",
			designation: "HR Executive",
			email: "pooja.mehta@abcpvt.in",
			phone: "9844455604",
			joinDate: "2024-02-19",
			status: "active",
			basic: 32e3,
			hra: 12800,
			special: 4100,
			pf: 3840,
			tax: 1400,
			other: 360
		},
		{
			id: "e005",
			code: "EMP005",
			name: "Karan Patel",
			gender: "m",
			department: "Finance",
			designation: "Finance Analyst",
			email: "karan.patel@abcpvt.in",
			phone: "9855566705",
			joinDate: "2022-11-07",
			status: "active",
			basic: 42e3,
			hra: 16800,
			special: 6300,
			pf: 5040,
			tax: 2200,
			other: 560
		}
	];
	const used = new Set(named.map((e) => e.name));
	const rand = mulberry32(202606);
	const count = 143;
	const weights = Array.from({ length: count }, () => .72 + rand() * .7);
	const wsum = weights.reduce((a, b) => a + b, 0);
	const target = TARGET_NET - named.reduce((s, e) => s + (grossOf(e) - statutoryOf(e)), 0);
	const nets = weights.map((w) => Math.round(target * w / wsum));
	let diff = target - nets.reduce((a, b) => a + b, 0);
	let guard = 0;
	while (diff !== 0 && guard < 2e6) {
		const idx = guard % count;
		const current = nets[idx] ?? 0;
		if (diff > 0 && current < 92e3) {
			nets[idx] = current + 1;
			diff -= 1;
		} else if (diff < 0 && current > 34e3) {
			nets[idx] = current - 1;
			diff += 1;
		}
		guard += 1;
	}
	const rest = [];
	let k = 0;
	for (let i = 0; i < count; i += 1) {
		const female = i % 2 === 1;
		let name = "";
		while (!name) {
			const first = (female ? FIRST_F : FIRST_M)[k % 40];
			const last = LAST[Math.floor(k / 2) % LAST.length];
			const candidate = `${first} ${last}`;
			k += 1;
			if (first && last && !used.has(candidate)) {
				used.add(candidate);
				name = candidate;
			}
			if (k > 8e3) {
				name = `Employee ${i + 6}`;
				break;
			}
		}
		const net = nets[i] ?? 5e4;
		const ratio = .112 + rand() * .025;
		const ded = Math.max(1200, Math.round(net * ratio / (1 - ratio)));
		const gross = net + ded;
		const dept = DEPARTMENTS[i % DEPARTMENTS.length] ?? "Operations";
		const roles = ROLES[dept] ?? ["Associate"];
		const designation = roles[i % roles.length] ?? "Associate";
		const n = i + 6;
		const slug = name.toLowerCase().replace(/[^a-z]+/g, ".").replace(/^\.|\.$/g, "");
		const start = new Date(2019, 3, 1).getTime();
		const end = new Date(2025, 10, 15).getTime();
		const joined = new Date(start + Math.floor(rand() * (end - start)));
		rest.push({
			id: `e${String(n).padStart(3, "0")}`,
			code: `EMP${String(n).padStart(3, "0")}`,
			name,
			gender: female ? "f" : "m",
			department: dept,
			designation,
			email: `${slug}@abcpvt.in`,
			phone: `98${String(1e7 + n * 7919 % 9e7).padStart(8, "0")}`,
			joinDate: isoDate(joined),
			status: "active",
			...splitPay(gross, ded)
		});
	}
	return [...named, ...rest].sort(byCode);
}
function buildSnapshot(employees, factor) {
	return scaleLines(employees.filter((e) => e.status === "active").sort(byCode).map(blankLine), factor);
}
function buildLeaves(employees) {
	const pick = (code) => employees.find((e) => e.code === code)?.id ?? "e001";
	return [
		{
			id: "l1",
			employeeId: pick("EMP001"),
			type: "Casual",
			from: "2026-10-09",
			to: "2026-10-09",
			reason: "Family function",
			status: "pending",
			appliedOn: "2026-10-03"
		},
		{
			id: "l2",
			employeeId: pick("EMP002"),
			type: "Sick",
			from: "2026-10-06",
			to: "2026-10-06",
			reason: "Fever and rest advised",
			status: "approved",
			appliedOn: "2026-10-06"
		},
		{
			id: "l3",
			employeeId: pick("EMP003"),
			type: "Earned",
			from: "2026-10-13",
			to: "2026-10-14",
			reason: "Out of station",
			status: "pending",
			appliedOn: "2026-10-01"
		},
		{
			id: "l4",
			employeeId: pick("EMP004"),
			type: "Casual",
			from: "2026-06-15",
			to: "2026-06-16",
			reason: "Personal work",
			status: "approved",
			appliedOn: "2026-06-08"
		},
		{
			id: "l5",
			employeeId: pick("EMP012"),
			type: "Sick",
			from: "2026-09-18",
			to: "2026-09-18",
			reason: "Migraine",
			status: "rejected",
			appliedOn: "2026-09-20"
		},
		{
			id: "l6",
			employeeId: pick("EMP018"),
			type: "Unpaid",
			from: "2026-10-07",
			to: "2026-10-07",
			reason: "Personal travel beyond balance",
			status: "pending",
			appliedOn: "2026-10-02"
		},
		{
			id: "l7",
			employeeId: pick("EMP009"),
			type: "Earned",
			from: "2026-10-01",
			to: "2026-10-01",
			reason: "Bank and documentation",
			status: "approved",
			appliedOn: "2026-09-25"
		},
		{
			id: "l8",
			employeeId: pick("EMP021"),
			type: "Casual",
			from: "2026-10-08",
			to: "2026-10-08",
			reason: "Parent-teacher meeting",
			status: "pending",
			appliedOn: "2026-10-07"
		}
	].map((s) => ({
		...s,
		days: eachWorkingDay(s.from, s.to).length
	}));
}
function buildMarks(employees, leaves) {
	const rand = mulberry32(77);
	const dates = [
		"2026-06-03",
		"2026-06-10",
		"2026-06-18",
		"2026-10-01",
		"2026-10-05",
		"2026-10-06",
		"2026-10-07",
		"2026-10-08"
	];
	const marks = [];
	for (const date of dates) {
		if (isWeekoff(date) || isHoliday(date)) continue;
		for (const e of employees) {
			const r = rand();
			if (r < .035) marks.push({
				employeeId: e.id,
				date,
				status: "absent"
			});
			else if (r < .05) marks.push({
				employeeId: e.id,
				date,
				status: "half"
			});
		}
	}
	for (const leave of leaves) {
		if (leave.status !== "approved") continue;
		const status = leave.type === "Unpaid" ? "unpaid" : "leave";
		for (const date of eachWorkingDay(leave.from, leave.to)) {
			const idx = marks.findIndex((m) => m.employeeId === leave.employeeId && m.date === date);
			if (idx >= 0) marks.splice(idx, 1);
			marks.push({
				employeeId: leave.employeeId,
				date,
				status
			});
		}
	}
	return marks;
}
function createSeed() {
	const employees = buildEmployees();
	const factors = {
		"2026-01": .86,
		"2026-02": .9,
		"2026-03": .93,
		"2026-04": .955,
		"2026-05": .978,
		"2026-06": 1
	};
	const snapshots = {};
	for (const [month, factor] of Object.entries(factors)) snapshots[month] = buildSnapshot(employees, factor);
	const leaves = buildLeaves(employees);
	return {
		employees,
		marks: buildMarks(employees, leaves),
		leaves,
		snapshots,
		adjustments: {},
		documents: [
			{
				id: "d1",
				title: "Employee Handbook 2026",
				category: "Policy",
				note: "Working hours, conduct, and leave rules for ABC Pvt. Ltd.",
				date: "2026-01-06"
			},
			{
				id: "d2",
				title: "POSH Policy",
				category: "Policy",
				note: "Prevention of sexual harassment at the workplace.",
				date: "2026-01-06"
			},
			{
				id: "d3",
				title: "Payroll Calendar 2026",
				category: "Payroll",
				note: "Salaries are processed by the 7th, or the previous working day.",
				date: "2026-04-01"
			},
			{
				id: "d4",
				title: "Offer — Aarav Sharma",
				category: "Offer",
				employeeId: "e001",
				note: "Product Manager, Product department.",
				date: "2022-04-01"
			},
			{
				id: "d5",
				title: "Form 16 checklist",
				category: "Payroll",
				note: "Collect PAN and investment proofs before January.",
				date: "2026-01-15"
			}
		],
		settings: {
			company: "ABC Pvt. Ltd.",
			adminName: "Rahul Mehta",
			adminRole: "Admin",
			workingDays: 26,
			payDay: 7
		},
		period: "2026-06"
	};
}
function csvCell(value) {
	const s = String(value ?? "");
	return /[",\n]/.test(s) ? `"${s.replace(/"/g, "\"\"")}"` : s;
}
function payrollCsv(lines, employees, month) {
	const map = employeeMap(employees);
	const header = [
		"Code",
		"Name",
		"Department",
		"Designation",
		"Gross",
		"Bonus",
		"LOP",
		"Deductions",
		"Net",
		"Month"
	];
	const rows = lines.map((l) => {
		const e = map.get(l.employeeId);
		return [
			e?.code ?? "",
			e?.name ?? "",
			e?.department ?? "",
			e?.designation ?? "",
			l.gross,
			l.bonus,
			l.lop,
			l.deductions,
			l.net,
			month
		].map(csvCell).join(",");
	});
	return [header.join(","), ...rows].join("\n");
}
function employeesCsv(employees) {
	const header = [
		"Code",
		"Name",
		"Status",
		"Department",
		"Designation",
		"Email",
		"Phone",
		"Join date",
		"Basic",
		"HRA",
		"Special",
		"PF",
		"Tax",
		"Other",
		"Gross",
		"Deductions",
		"Net"
	];
	const rows = [...employees].sort(byCode).map((e) => [
		e.code,
		e.name,
		e.status,
		e.department,
		e.designation,
		e.email,
		e.phone,
		e.joinDate,
		e.basic,
		e.hra,
		e.special,
		e.pf,
		e.tax,
		e.other,
		grossOf(e),
		statutoryOf(e),
		grossOf(e) - statutoryOf(e)
	].map(csvCell).join(","));
	return [header.join(","), ...rows].join("\n");
}
var KEY = "bizhr-ledger-v1";
var useHr = create()((set, get) => ({
	...createSeed(),
	view: "payroll",
	hydrated: false,
	setView: (view) => set({ view }),
	setPeriod: (period) => set({ period }),
	addEmployee: (input) => {
		const { id, code } = nextIdentity(get().employees);
		const employee = {
			...input,
			id,
			code,
			name: input.name.trim(),
			email: input.email.trim().toLowerCase(),
			designation: input.designation.trim(),
			phone: input.phone.trim()
		};
		set((s) => ({ employees: [...s.employees, employee].sort(byCode) }));
		return employee;
	},
	updateEmployee: (id, patch) => set((s) => ({ employees: s.employees.map((e) => e.id === id ? {
		...e,
		...patch,
		id: e.id,
		code: e.code,
		name: patch.name?.trim() ?? e.name,
		email: (patch.email ?? e.email).trim().toLowerCase(),
		designation: patch.designation?.trim() ?? e.designation
	} : e) })),
	setStatus: (id, status) => set((s) => ({ employees: s.employees.map((e) => e.id === id ? {
		...e,
		status
	} : e) })),
	setMark: (employeeId, date, status) => set((s) => {
		const marks = s.marks.filter((m) => !(m.employeeId === employeeId && m.date === date));
		if (status === "present") return { marks };
		const next = {
			employeeId,
			date,
			status
		};
		return { marks: [...marks, next] };
	}),
	clearDay: (date) => set((s) => ({ marks: s.marks.filter((m) => m.date !== date) })),
	addLeave: (input) => {
		const s = get();
		const days = eachWorkingDay(input.from, input.to);
		if (!days.length) return {
			ok: false,
			reason: "Choose at least one working day."
		};
		if (!input.reason.trim()) return {
			ok: false,
			reason: "Add a short reason."
		};
		if (input.type !== "Unpaid") {
			const left = LEAVE_QUOTA[input.type] - leaveReserved(s.leaves, input.employeeId, input.type);
			if (days.length > left) return {
				ok: false,
				reason: `Only ${Math.max(0, left)} ${input.type.toLowerCase()} day${left === 1 ? "" : "s"} left.`
			};
		}
		set({ leaves: [{
			id: `l${s.leaves.reduce((m, l) => Math.max(m, Number(l.id.slice(1)) || 0), 0) + 1}`,
			employeeId: input.employeeId,
			type: input.type,
			from: input.from,
			to: input.to,
			days: days.length,
			reason: input.reason.trim(),
			status: "pending",
			appliedOn: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10)
		}, ...s.leaves] });
		return { ok: true };
	},
	decideLeave: (id, status) => set((s) => {
		const leave = s.leaves.find((l) => l.id === id);
		if (!leave || leave.status !== "pending") return {};
		const leaves = s.leaves.map((l) => l.id === id ? {
			...l,
			status
		} : l);
		if (status !== "approved") return { leaves };
		const dates = eachWorkingDay(leave.from, leave.to);
		const markStatus = leave.type === "Unpaid" ? "unpaid" : "leave";
		return {
			leaves,
			marks: [...s.marks.filter((m) => !(m.employeeId === leave.employeeId && dates.includes(m.date))), ...dates.map((date) => ({
				employeeId: leave.employeeId,
				date,
				status: markStatus
			}))]
		};
	}),
	withdrawLeave: (id) => set((s) => ({ leaves: s.leaves.filter((l) => !(l.id === id && l.status === "pending")) })),
	setAdjustment: (month, employeeId, patch) => set((s) => {
		if (s.snapshots[month]) return {};
		const key = `${month}:${employeeId}`;
		const prev = s.adjustments[key] ?? {
			bonus: 0,
			extra: 0
		};
		return { adjustments: {
			...s.adjustments,
			[key]: {
				...prev,
				...patch
			}
		} };
	}),
	completePayroll: (month) => {
		const data = get();
		if (data.snapshots[month]) return {
			ok: false,
			reason: "This month is already completed."
		};
		const lines = computeLive(data, month);
		if (!lines.length) return {
			ok: false,
			reason: "No active employees to pay in this month."
		};
		if (lines.some((l) => l.net < 0)) return {
			ok: false,
			reason: "Fix negative net pay before completing."
		};
		set({ snapshots: {
			...data.snapshots,
			[month]: lines
		} });
		return { ok: true };
	},
	reopenPayroll: (month) => set((s) => {
		const snapshots = { ...s.snapshots };
		delete snapshots[month];
		return { snapshots };
	}),
	addDocument: (doc) => set((s) => {
		const n = s.documents.reduce((m, d) => Math.max(m, Number(d.id.slice(1)) || 0), 0) + 1;
		return { documents: [{
			...doc,
			id: `d${n}`
		}, ...s.documents] };
	}),
	removeDocument: (id) => set((s) => ({ documents: s.documents.filter((d) => d.id !== id) })),
	updateSettings: (patch) => set((s) => ({ settings: {
		...s.settings,
		...patch
	} })),
	loadData: (data) => set({
		...data,
		view: "payroll"
	}),
	resetDemo: () => set({
		...createSeed(),
		view: "payroll"
	})
}));
function payload(s) {
	return {
		employees: s.employees,
		marks: s.marks,
		leaves: s.leaves,
		snapshots: s.snapshots,
		adjustments: s.adjustments,
		documents: s.documents,
		settings: s.settings,
		period: s.period
	};
}
function isHrData(value) {
	if (!value || typeof value !== "object") return false;
	const v = value;
	return Array.isArray(v.employees) && v.employees.length > 0 && !!v.settings && !!v.snapshots && Array.isArray(v.leaves) && Array.isArray(v.marks) && Array.isArray(v.documents);
}
function useHydrateHr() {
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem(KEY);
			if (raw) {
				const parsed = JSON.parse(raw);
				if (isHrData(parsed)) {
					useHr.setState({
						...parsed,
						hydrated: true
					});
					return;
				}
			}
		} catch {}
		useHr.setState({ hydrated: true });
	}, []);
	(0, import_react.useEffect)(() => {
		return useHr.subscribe((s) => {
			if (!s.hydrated) return;
			try {
				localStorage.setItem(KEY, JSON.stringify(payload(s)));
			} catch {}
		});
	}, []);
}
var fieldClass = "h-11 w-full rounded-xl border border-border bg-surface px-3 text-sm text-fg outline-none transition-colors focus:border-primary";
function useMounted() {
	const [on, setOn] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setOn(true), []);
	return on;
}
function Avatar({ name, female, size = "md" }) {
	const initials = name.split(" ").filter(Boolean).slice(0, 2).map((p) => p[0]?.toUpperCase() ?? "").join("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: clsx("grid shrink-0 place-items-center rounded-full font-semibold", size === "sm" ? "size-9 text-xs" : "size-10 text-sm", female ? "bg-primary-soft text-primary-dark" : "bg-bg text-fg ring-1 ring-border"),
		"aria-hidden": true,
		children: initials
	});
}
function Modal({ open, title, subtitle, onClose, children, wide }) {
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (e) => {
			if (e.key === "Escape") onClose();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open, onClose]);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-3 sm:items-center",
		onMouseDown: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			className: clsx("max-h-[92dvh] w-full overflow-y-auto rounded-2xl bg-surface p-5 shadow-card", wide ? "max-w-3xl" : "max-w-lg"),
			onMouseDown: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: title
				}), subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: subtitle
				}) : null] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Close",
					onClick: onClose,
					className: "grid size-11 place-items-center rounded-full text-muted hover:bg-bg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}), children]
		})
	});
}
function ConfirmDialog({ open, title, body, confirmLabel, danger, onConfirm, onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		open,
		title,
		onClose,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: body
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 flex flex-wrap justify-end gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onClose,
				className: "h-11 rounded-xl px-4 text-sm font-medium text-fg hover:bg-bg",
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onConfirm,
				className: clsx("h-11 rounded-xl px-4 text-sm font-semibold text-on-primary", danger ? "bg-danger" : "bg-primary"),
				children: confirmLabel
			})]
		})]
	});
}
var PAGE_SIZES = [
	5,
	10,
	20,
	50
];
function Pagination({ page, pages, pageSize, total, onPage, onPageSize, noun }) {
	const from = total === 0 ? 0 : (page - 1) * pageSize + 1;
	const to = Math.min(total, page * pageSize);
	const items = pageList(page, pages);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3 border-t border-border px-4 py-3 text-sm text-muted sm:flex-row sm:items-center sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
			"Showing ",
			from,
			" to ",
			to,
			" of ",
			total,
			" ",
			noun
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageButton, {
						label: "Previous page",
						disabled: page <= 1,
						onClick: () => onPage(page - 1),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
					}),
					items.map((item, i) => item === "..." ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "px-1",
						children: "…"
					}, `gap-${i}`) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onPage(item),
						className: clsx("grid size-11 place-items-center rounded-xl text-sm font-semibold", item === page ? "bg-primary text-on-primary" : "text-fg hover:bg-bg"),
						"aria-current": item === page ? "page" : void 0,
						children: item
					}, item)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageButton, {
						label: "Next page",
						disabled: page >= pages,
						onClick: () => onPage(page + 1),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Rows per page" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "h-11 rounded-xl border border-border bg-surface px-2 text-fg",
					value: pageSize,
					onChange: (e) => onPageSize(Number(e.target.value)),
					children: PAGE_SIZES.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: n,
						children: n
					}, n))
				})]
			})]
		})]
	});
}
function PageButton({ children, label, disabled, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		disabled,
		onClick,
		className: "grid size-11 place-items-center rounded-xl text-fg hover:bg-bg disabled:opacity-40",
		children
	});
}
function pageList(page, pages) {
	if (pages <= 7) return Array.from({ length: pages }, (_, i) => i + 1);
	const items = [1];
	const start = Math.max(2, page - 1);
	const end = Math.min(pages - 1, page + 1);
	if (start > 2) items.push("...");
	for (let i = start; i <= end; i += 1) items.push(i);
	if (end < pages - 1) items.push("...");
	items.push(pages);
	return items;
}
function MonthPicker({ value, onChange }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [year, setYear] = (0, import_react.useState)(Number(value.slice(0, 4)) || 2026);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => {
				setYear(Number(value.slice(0, 4)) || 2026);
				setOpen((v) => !v);
			},
			className: "inline-flex h-11 items-center gap-2 rounded-xl border border-border bg-surface px-3 text-sm font-medium",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-4 text-muted" }),
				monthLabel(value),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: clsx("size-4 text-muted transition-transform", open && "rotate-90") })
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "fixed inset-0 z-30 cursor-default",
			"aria-label": "Close month picker",
			onClick: () => setOpen(false)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute right-0 z-40 mt-2 w-72 rounded-2xl border border-border bg-surface p-3 shadow-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center rounded-xl hover:bg-bg",
						"aria-label": "Previous year",
						onClick: () => setYear((y) => y - 1),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold",
						children: year
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center rounded-xl hover:bg-bg",
						"aria-label": "Next year",
						onClick: () => setYear((y) => y + 1),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					"Jan",
					"Feb",
					"Mar",
					"Apr",
					"May",
					"Jun",
					"Jul",
					"Aug",
					"Sep",
					"Oct",
					"Nov",
					"Dec"
				].map((name, i) => {
					const key = `${year}-${String(i + 1).padStart(2, "0")}`;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							onChange(key);
							setOpen(false);
						},
						className: clsx("h-11 rounded-xl text-sm font-medium", key === value ? "bg-primary text-on-primary" : "hover:bg-bg"),
						children: name
					}, key);
				})
			})]
		})] }) : null]
	});
}
function StatusPill({ tone, children, check }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: clsx("inline-flex h-8 items-center gap-1 rounded-full px-3 text-xs font-semibold", tone === "good" && "bg-primary-soft text-primary-dark", tone === "warn" && "bg-warning-soft text-warning", tone === "bad" && "bg-danger-soft text-danger", tone === "neutral" && "bg-bg text-muted"),
		children: [children, check ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : null]
	});
}
function EmptyState({ title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-6 py-16 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-semibold",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mx-auto mt-1 max-w-sm text-sm text-muted",
			children: body
		})]
	});
}
function downloadText(filename, text, type = "text/csv;charset=utf-8") {
	const blob = new Blob([text], { type });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}
function PrimaryButton({ children, onClick, type = "button" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		onClick,
		className: "inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-primary px-4 text-sm font-semibold text-on-primary hover:bg-primary-dark",
		children
	});
}
function GhostButton({ children, onClick, type = "button" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		onClick,
		className: "inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-border bg-surface px-4 text-sm font-medium hover:bg-bg",
		children
	});
}
var NAV = [
	{
		id: "dashboard",
		label: "Dashboard",
		short: "Home",
		icon: LayoutDashboard
	},
	{
		id: "employees",
		label: "Employees",
		short: "People",
		icon: Users
	},
	{
		id: "attendance",
		label: "Attendance",
		short: "Attend",
		icon: CalendarCheck
	},
	{
		id: "leave",
		label: "Leave",
		short: "Leave",
		icon: CalendarDays
	},
	{
		id: "payroll",
		label: "Payroll",
		short: "Pay",
		icon: IndianRupee
	},
	{
		id: "reports",
		label: "Reports",
		short: "Reports",
		icon: FileChartColumnIncreasing
	},
	{
		id: "documents",
		label: "Documents",
		short: "Docs",
		icon: Files
	},
	{
		id: "settings",
		label: "Settings",
		short: "Setup",
		icon: Settings
	}
];
var TOP = NAV.filter((item) => [
	"employees",
	"attendance",
	"leave",
	"payroll",
	"reports"
].includes(item.id));
function Shell({ children }) {
	const view = useHr((s) => s.view);
	const setView = useHr((s) => s.setView);
	const settings = useHr((s) => s.settings);
	const leaves = useHr((s) => s.leaves);
	const snapshots = useHr((s) => s.snapshots);
	const resetDemo = useHr((s) => s.resetDemo);
	const pending = leaves.filter((l) => l.status === "pending").length;
	const notes = notifications({
		employees: [],
		marks: [],
		leaves,
		snapshots,
		adjustments: {},
		documents: [],
		settings,
		period: ""
	});
	const [open, setOpen] = (0, import_react.useState)(false);
	const [bell, setBell] = (0, import_react.useState)(false);
	const [companyOpen, setCompanyOpen] = (0, import_react.useState)(false);
	const [adminOpen, setAdminOpen] = (0, import_react.useState)(false);
	const [confirmReset, setConfirmReset] = (0, import_react.useState)(false);
	const go = (id) => {
		setView(id);
		setOpen(false);
		setBell(false);
		setCompanyOpen(false);
		setAdminOpen(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh bg-bg text-fg",
		children: [
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "fixed inset-0 z-40 bg-ink/40 lg:hidden",
				"aria-label": "Close menu",
				onClick: () => setOpen(false)
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: clsx("fixed inset-y-0 left-0 z-50 flex w-60 flex-col border-r border-border bg-surface transition-transform lg:static lg:translate-x-0", open ? "translate-x-0" : "-translate-x-full"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-16 items-center px-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-2xl font-extrabold tracking-tight text-primary",
							children: "BIZHR"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "by Qklipit"
						})] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex min-h-0 flex-1 flex-col gap-1 overflow-y-auto px-3 py-2",
						children: NAV.map((item) => {
							const active = view === item.id;
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => go(item.id),
								className: clsx("flex h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium", active ? "bg-primary text-on-primary" : "text-fg hover:bg-bg"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 shrink-0" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate",
										children: item.label
									}),
									item.id === "leave" && pending > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: clsx("ml-auto rounded-full px-2 text-xs font-semibold", active ? "bg-on-primary text-primary" : "bg-primary-soft text-primary-dark"),
										children: pending
									}) : null
								]
							}, item.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setCompanyOpen((v) => !v),
							className: "flex w-full items-center gap-3 rounded-2xl border border-border p-3 text-left hover:bg-bg",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-10 shrink-0 place-items-center rounded-xl bg-primary-soft text-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-sm font-semibold",
										children: settings.company
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-xs text-muted",
										children: settings.adminRole
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4 shrink-0 text-muted" })
							]
						}), companyOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute inset-x-3 bottom-full z-40 mb-2 rounded-2xl border border-border bg-surface p-1 shadow-card",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
									label: "Company settings",
									onClick: () => go("settings")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
									label: "Payroll reports",
									onClick: () => go("reports")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
									label: "Reset demo data",
									onClick: () => {
										setCompanyOpen(false);
										setConfirmReset(true);
									}
								})
							]
						}) : null]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "relative z-20 flex h-16 shrink-0 items-center gap-2 border-b border-border bg-surface px-3 sm:px-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "grid size-11 place-items-center rounded-xl hover:bg-bg lg:hidden",
								"aria-label": "Open menu",
								onClick: () => setOpen(true),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
								className: "no-scrollbar hidden min-w-0 flex-1 items-center gap-1 overflow-x-auto md:flex",
								children: TOP.map((item) => {
									const active = view === item.id;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => go(item.id),
										className: clsx("h-16 shrink-0 border-b-2 px-3 text-sm", active ? "border-primary font-semibold text-fg" : "border-transparent text-muted hover:text-fg"),
										children: item.label
									}, item.id);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "ml-auto flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										"aria-label": "Notifications",
										onClick: () => setBell((v) => !v),
										className: "relative grid size-11 place-items-center rounded-full hover:bg-bg",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-5" }), notes.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-2 right-2 size-2 rounded-full bg-danger" }) : null]
									}), bell ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "fixed inset-0 z-30 cursor-default",
										"aria-label": "Close notifications",
										onClick: () => setBell(false)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute right-0 z-40 mt-2 w-80 max-w-[calc(100vw-1.5rem)] rounded-2xl border border-border bg-surface p-2 shadow-card",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "px-2 py-1 text-sm font-semibold",
												children: "Notifications"
											}),
											notes.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "px-2 py-4 text-sm text-muted",
												children: "You're all caught up."
											}) : null,
											notes.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => go(note.view),
												className: "block w-full rounded-xl px-2 py-3 text-left hover:bg-bg",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "block text-sm font-semibold",
													children: note.title
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "block text-xs text-muted",
													children: note.detail
												})]
											}, note.id))
										]
									})] }) : null]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setAdminOpen((v) => !v),
										className: "flex h-11 items-center gap-2 rounded-full pr-2 pl-1 hover:bg-bg",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
												name: settings.adminName,
												size: "sm"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "hidden text-left sm:block",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "block text-sm font-semibold leading-tight",
													children: settings.adminName
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "block text-xs text-muted",
													children: settings.adminRole
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "hidden size-4 text-muted sm:block" })
										]
									}), adminOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "fixed inset-0 z-30 cursor-default",
										"aria-label": "Close account menu",
										onClick: () => setAdminOpen(false)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute right-0 z-40 mt-2 w-52 rounded-2xl border border-border bg-surface p-1 shadow-card",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
												label: "Settings",
												onClick: () => go("settings")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
												label: "Documents",
												onClick: () => go("documents")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
												label: "Reset demo data",
												onClick: () => {
													setAdminOpen(false);
													setConfirmReset(true);
												}
											})
										]
									})] }) : null]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "min-h-0 flex-1 overflow-y-auto pb-20 lg:pb-0",
						children
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-border bg-surface lg:hidden",
						children: TOP.map((item) => {
							const active = view === item.id;
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => go(item.id),
								className: clsx("flex h-16 flex-col items-center justify-center gap-1 text-xs", active ? "text-primary" : "text-muted"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "max-w-full truncate px-1",
									children: item.short
								})]
							}, item.id);
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmReset,
				title: "Reset demo data?",
				body: "This restores the original June 2026 payroll, 148 employees, and sample leave. Your edits on this browser will be replaced.",
				confirmLabel: "Reset",
				danger: true,
				onClose: () => setConfirmReset(false),
				onConfirm: () => {
					resetDemo();
					setConfirmReset(false);
					setOpen(false);
				}
			})
		]
	});
}
function MenuItem({ label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: "flex h-11 w-full items-center rounded-xl px-3 text-left text-sm font-medium hover:bg-bg",
		children: label
	});
}
function Sparkline({ data }) {
	if (!useMounted()) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-16 w-full" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-16 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AreaChart, {
				data,
				margin: {
					top: 8,
					right: 0,
					left: 0,
					bottom: 0
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
					type: "monotone",
					dataKey: "total",
					stroke: "var(--color-primary)",
					fill: "var(--color-primary-soft)",
					strokeWidth: 2,
					dot: false
				})
			})
		})
	});
}
function TrendChart({ data }) {
	if (!useMounted()) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-64 w-full rounded-xl bg-bg" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-64 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
				data,
				margin: {
					top: 8,
					right: 8,
					left: 0,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
						stroke: "var(--color-border)",
						vertical: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "label",
						tick: {
							fill: "var(--color-muted)",
							fontSize: 12
						},
						axisLine: false,
						tickLine: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						tick: {
							fill: "var(--color-muted)",
							fontSize: 12
						},
						axisLine: false,
						tickLine: false,
						width: 72,
						tickFormatter: (v) => inr(v).replace("₹ ", "₹")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { formatter: (value) => inr(Number(value ?? 0)) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
						type: "monotone",
						dataKey: "total",
						name: "Net payroll",
						stroke: "var(--color-primary)",
						fill: "var(--color-primary-soft)",
						strokeWidth: 2
					})
				]
			})
		})
	});
}
function DeptChart({ data }) {
	if (!useMounted()) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-72 w-full rounded-xl bg-bg" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-72 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
				data,
				margin: {
					top: 8,
					right: 8,
					left: 0,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
						stroke: "var(--color-border)",
						vertical: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "name",
						tick: {
							fill: "var(--color-muted)",
							fontSize: 11
						},
						axisLine: false,
						tickLine: false,
						interval: 0,
						angle: -25,
						height: 56,
						textAnchor: "end"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						tick: {
							fill: "var(--color-muted)",
							fontSize: 12
						},
						axisLine: false,
						tickLine: false,
						width: 72,
						tickFormatter: (v) => inr(v).replace("₹ ", "₹")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { formatter: (value) => inr(Number(value ?? 0)) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
						dataKey: "net",
						name: "Net pay",
						fill: "var(--color-primary)",
						radius: [
							6,
							6,
							0,
							0
						]
					})
				]
			})
		})
	});
}
function PayrollView() {
	const data = useHr();
	const { period, employees, setPeriod, setView, completePayroll, reopenPayroll, setAdjustment } = data;
	const map = (0, import_react.useMemo)(() => employeeMap(employees), [employees]);
	const { lines, locked } = linesFor(data, period);
	const [dept, setDept] = (0, import_react.useState)("all");
	const [query, setQuery] = (0, import_react.useState)("");
	const [page, setPage] = (0, import_react.useState)(1);
	const [pageSize, setPageSize] = (0, import_react.useState)(10);
	const [sortKey, setSortKey] = (0, import_react.useState)("code");
	const [sortDir, setSortDir] = (0, import_react.useState)("asc");
	const [slip, setSlip] = (0, import_react.useState)(null);
	const [confirm, setConfirm] = (0, import_react.useState)(null);
	const departments = (0, import_react.useMemo)(() => Array.from(new Set(employees.map((e) => e.department))).sort(), [employees]);
	const deptLines = dept === "all" ? lines : lines.filter((l) => map.get(l.employeeId)?.department === dept);
	const totals = sumLines(deptLines);
	const sorted = [...deptLines.filter((l) => {
		const e = map.get(l.employeeId);
		if (!e) return false;
		return `${e.name} ${e.code} ${e.department}`.toLowerCase().includes(query.trim().toLowerCase());
	})].sort((a, b) => {
		const ea = map.get(a.employeeId);
		const eb = map.get(b.employeeId);
		const dir = sortDir === "asc" ? 1 : -1;
		const av = sortValue(sortKey, a, ea);
		const bv = sortValue(sortKey, b, eb);
		if (typeof av === "number" && typeof bv === "number") return (av - bv) * dir;
		return String(av).localeCompare(String(bv)) * dir;
	});
	const pages = Math.max(1, Math.ceil(sorted.length / pageSize));
	const safePage = Math.min(page, pages);
	const rows = sorted.slice((safePage - 1) * pageSize, safePage * pageSize);
	const trend = (0, import_react.useMemo)(() => Object.keys(data.snapshots).sort().map((month) => ({
		label: shortMonth(month),
		total: data.snapshots[month]?.reduce((s, l) => s + l.net, 0) ?? 0
	})), [data.snapshots]);
	const toggleSort = (key) => {
		if (sortKey === key) setSortDir((d) => d === "asc" ? "desc" : "asc");
		else {
			setSortKey(key);
			setSortDir(key === "name" || key === "department" || key === "code" ? "asc" : "desc");
		}
		setPage(1);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5 p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-bold tracking-tight",
					children: "Payroll"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MonthPicker, {
							value: period,
							onChange: (next) => {
								setPeriod(next);
								setPage(1);
								setSlip(null);
							}
						}),
						locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex h-11 items-center gap-2 rounded-full bg-primary px-4 text-sm font-bold tracking-wide text-on-primary",
							children: ["PAYROLL COMPLETED", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-5 place-items-center rounded-full bg-on-primary text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" })
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setConfirm("complete"),
							className: "inline-flex h-11 items-center gap-2 rounded-full bg-primary px-4 text-sm font-bold tracking-wide text-on-primary hover:bg-primary-dark",
							children: "COMPLETE PAYROLL"
						}),
						locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setConfirm("reopen"),
							className: "h-11 rounded-xl px-3 text-sm font-medium text-muted hover:bg-surface hover:text-fg",
							children: "Reopen"
						}) : null
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5" }),
						label: "Employees",
						value: String(totals.count),
						hint: dept === "all" ? "Total Active" : dept
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-5" }),
						label: "Processed",
						value: locked ? `${totals.count} / ${totals.count}` : `0 / ${totals.count}`,
						hint: locked ? "100% Completed" : "Not completed"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndianRupee, { className: "size-5" }),
						label: "Total Payroll",
						value: inr(totals.net),
						hint: dept === "all" ? "All Departments" : dept
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-surface p-4 shadow-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "Auto-Calculated"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-4 text-primary" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkline, { data: trend.length ? trend : [{
							label: period.slice(5),
							total: totals.net
						}] })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "overflow-hidden rounded-2xl border border-border bg-surface shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3 border-b border-border p-4 sm:flex-row sm:items-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: query,
								onChange: (e) => {
									setQuery(e.target.value);
									setPage(1);
								},
								placeholder: "Search name or code",
								className: clsx(fieldClass, "sm:max-w-xs")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: dept,
								onChange: (e) => {
									setDept(e.target.value);
									setPage(1);
								},
								className: clsx(fieldClass, "sm:max-w-xs"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "all",
									children: "All departments"
								}), departments.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: d,
									children: d
								}, d))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "sm:ml-auto",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
									onClick: () => downloadText(`payroll-${period}.csv`, payrollCsv(deptLines, employees, period)),
									children: "Export CSV"
								})
							})
						]
					}),
					rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						title: "No employees in this view",
						body: "Try another department, or add an active employee who joined before this month ends."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-3xl text-left text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "text-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Th, {
											label: "Employee",
											k: "name",
											sortKey,
											sortDir,
											onSort: toggleSort
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Th, {
											label: "Department",
											k: "department",
											sortKey,
											sortDir,
											onSort: toggleSort
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Th, {
											label: "Gross Salary",
											k: "gross",
											sortKey,
											sortDir,
											onSort: toggleSort
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Th, {
											label: "Deductions",
											k: "deductions",
											sortKey,
											sortDir,
											onSort: toggleSort
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Th, {
											label: "Net Salary",
											k: "net",
											sortKey,
											sortDir,
											onSort: toggleSort
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 font-medium",
											children: "Status"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 font-medium",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "sr-only",
												children: "Payslip"
											})
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((line) => {
								const e = map.get(line.employeeId);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border last:border-0 hover:bg-bg",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
													name: e?.name ?? "?",
													female: e?.gender === "f"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "font-semibold",
													children: e?.name ?? "Former employee"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-muted",
													children: e?.code ?? line.employeeId
												})] })]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3",
											children: e?.department ?? "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 font-medium",
											children: inr(line.gross + line.bonus)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3",
											children: inr(line.deductions)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 font-semibold",
											children: inr(line.net)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3",
											children: locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, {
												tone: "good",
												check: true,
												children: "Processed"
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, {
												tone: "warn",
												children: "Draft"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												"aria-label": `Payslip for ${e?.name ?? "employee"}`,
												onClick: () => setSlip(line),
												className: "grid size-11 place-items-center rounded-xl text-muted hover:bg-primary-soft hover:text-primary",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "size-4" })
											})
										})
									]
								}, line.employeeId);
							}) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pagination, {
						page: safePage,
						pages,
						pageSize,
						total: sorted.length,
						noun: "employees",
						onPage: setPage,
						onPageSize: (size) => {
							setPageSize(size);
							setPage(1);
						}
					})
				]
			}),
			slip ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Payslip, {
				line: slip,
				employee: map.get(slip.employeeId),
				month: period,
				locked,
				company: data.settings.company,
				onClose: () => setSlip(null),
				onSave: (bonus, extra) => {
					setAdjustment(period, slip.employeeId, {
						bonus,
						extra
					});
					toast.success("Adjustment saved");
					setSlip(null);
				},
				onAttendance: () => {
					setSlip(null);
					setView("attendance");
				}
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirm === "complete",
				title: `Complete ${monthLabel(period)}?`,
				body: "Salaries lock for this month. Later attendance or salary edits will not change this run unless you reopen it.",
				confirmLabel: "Complete payroll",
				onClose: () => setConfirm(null),
				onConfirm: () => {
					const result = completePayroll(period);
					setConfirm(null);
					if (!result.ok) toast.error(result.reason);
					else toast.success(`${monthLabel(period)} payroll completed`);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirm === "reopen",
				title: `Reopen ${monthLabel(period)}?`,
				body: "Locked amounts are discarded. The month is recalculated from current salaries, bonuses, and attendance — including loss of pay.",
				confirmLabel: "Reopen",
				danger: true,
				onClose: () => setConfirm(null),
				onConfirm: () => {
					reopenPayroll(period);
					setConfirm(null);
					toast.success(`${monthLabel(period)} is a draft again`);
				}
			})
		]
	});
}
function sortValue(key, line, employee) {
	if (key === "gross") return line.gross + line.bonus;
	if (key === "deductions") return line.deductions;
	if (key === "net") return line.net;
	if (key === "name") return employee?.name ?? "";
	if (key === "department") return employee?.department ?? "";
	return employee?.code ?? line.employeeId;
}
function Th({ label, k, sortKey, sortDir, onSort }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
		className: "px-4 py-3 font-medium",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => onSort(k),
			className: "inline-flex items-center gap-1",
			children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs",
				children: sortKey === k ? sortDir === "asc" ? "↑" : "↓" : ""
			})]
		})
	});
}
function Stat({ icon, label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-4 rounded-2xl border border-border bg-surface p-4 shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid size-12 shrink-0 place-items-center rounded-full bg-primary-soft text-primary",
			children: icon
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-2xl font-semibold tracking-tight",
					children: value
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: hint
				})
			]
		})]
	});
}
function Payslip({ line, employee, month, locked, company, onClose, onSave, onAttendance }) {
	const [bonus, setBonus] = (0, import_react.useState)(String(line.bonus || ""));
	const [extra, setExtra] = (0, import_react.useState)(String(line.extra || ""));
	const bonusN = Math.max(0, Math.round(Number(bonus) || 0));
	const extraN = Math.max(0, Math.round(Number(extra) || 0));
	const statutory = line.deductions - line.lop - line.extra;
	const previewNet = line.gross + (locked ? line.bonus : bonusN) - (statutory + line.lop + (locked ? line.extra : extraN));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-3 sm:items-center",
		onMouseDown: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-label": "Payslip",
			className: "max-h-[92dvh] w-full max-w-lg overflow-y-auto rounded-2xl bg-surface p-5 shadow-card",
			onMouseDown: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-wide text-primary",
						children: company
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-lg font-semibold",
						children: ["Payslip · ", monthLabel(month)]
					})] }), locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, {
						tone: "good",
						check: true,
						children: "Processed"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, {
						tone: "warn",
						children: "Draft"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						name: employee?.name ?? "?",
						female: employee?.gender === "f"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: employee?.name ?? "Former employee"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							employee?.code,
							" · ",
							employee?.department,
							" · ",
							employee?.designation
						]
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid grid-cols-2 gap-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Gross earnings",
							value: inr(line.gross)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Bonus",
							value: inr(locked ? line.bonus : bonusN)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "PF, tax & other",
							value: inr(statutory)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Loss of pay",
							value: inr(line.lop)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Extra deduction",
							value: inr(locked ? line.extra : extraN)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Net pay",
							value: inr(previewNet),
							strong: true
						})
					]
				}),
				!locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mb-1 block font-medium",
							children: "Bonus"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							inputMode: "numeric",
							value: bonus,
							onChange: (e) => setBonus(e.target.value)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mb-1 block font-medium",
							children: "Extra deduction"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							inputMode: "numeric",
							value: extra,
							onChange: (e) => setExtra(e.target.value)
						})]
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-muted",
					children: "This month is locked. Reopen payroll to change bonus or deductions."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-wrap justify-end gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
							onClick: onAttendance,
							children: "Attendance"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
							onClick: () => {
								const html = payslipHtml({
									company,
									month: monthLabel(month),
									employee,
									line,
									net: previewNet,
									statutory,
									bonus: locked ? line.bonus : bonusN,
									extra: locked ? line.extra : extraN
								});
								const w = window.open("", "_blank", "noopener,noreferrer");
								if (!w) {
									toast.error("Allow pop-ups to print the payslip");
									return;
								}
								w.document.write(html);
								w.document.close();
								w.focus();
								w.print();
							},
							children: "Print"
						}),
						locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
							onClick: onClose,
							children: "Close"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
							onClick: () => onSave(bonusN, extraN),
							children: "Save adjustment"
						})
					]
				})
			]
		})
	});
}
function Row({ label, value, strong }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-bg px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: strong ? "font-semibold" : "font-medium",
			children: value
		})]
	});
}
function payslipHtml({ company, month, employee, line, net, statutory, bonus, extra }) {
	const row = (label, value) => `<tr><td style="padding:8px 0;color:#6b7682">${label}</td><td style="padding:8px 0;text-align:right;font-weight:600">${value}</td></tr>`;
	return `<!doctype html><html><head><title>Payslip ${employee?.code ?? ""}</title></head><body style="font-family:sans-serif;color:#1b2430;padding:32px">
  <p style="color:#1c9a48;font-weight:700;margin:0">${company}</p>
  <h1 style="margin:4px 0 16px">Payslip · ${month}</h1>
  <p style="margin:0"><strong>${employee?.name ?? ""}</strong> · ${employee?.code ?? ""} · ${employee?.department ?? ""}</p>
  <p style="margin:4px 0 16px;color:#6b7682">${employee?.designation ?? ""}</p>
  <table style="width:100%;border-collapse:collapse">${row("Gross", inr(line.gross))}${row("Bonus", inr(bonus))}${row("PF, tax & other", inr(statutory))}${row("Loss of pay", inr(line.lop))}${row("Extra deduction", inr(extra))}${row("Net pay", inr(net))}</table>
  </body></html>`;
}
var emptyDraft = () => ({
	name: "",
	gender: "m",
	department: "Product",
	designation: "Associate",
	email: "",
	phone: "",
	joinDate: "2026-10-08",
	status: "active",
	basic: "",
	hra: "",
	special: "",
	pf: "",
	tax: "",
	other: ""
});
function fromEmployee(e) {
	return {
		name: e.name,
		gender: e.gender,
		department: e.department,
		designation: e.designation,
		email: e.email,
		phone: e.phone,
		joinDate: e.joinDate,
		status: e.status,
		basic: String(e.basic),
		hra: String(e.hra),
		special: String(e.special),
		pf: String(e.pf),
		tax: String(e.tax),
		other: String(e.other)
	};
}
function num(value) {
	const n = Number(value);
	if (!Number.isFinite(n) || n < 0) return null;
	return Math.round(n);
}
function EmployeesView() {
	const employees = useHr((s) => s.employees);
	const leaves = useHr((s) => s.leaves);
	const marks = useHr((s) => s.marks);
	const period = useHr((s) => s.period);
	const addEmployee = useHr((s) => s.addEmployee);
	const updateEmployee = useHr((s) => s.updateEmployee);
	const setStatus = useHr((s) => s.setStatus);
	const [query, setQuery] = (0, import_react.useState)("");
	const [dept, setDept] = (0, import_react.useState)("all");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("all");
	const [page, setPage] = (0, import_react.useState)(1);
	const [pageSize, setPageSize] = (0, import_react.useState)(10);
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [profile, setProfile] = (0, import_react.useState)(null);
	const departments = (0, import_react.useMemo)(() => Array.from(/* @__PURE__ */ new Set([...DEPARTMENTS, ...employees.map((e) => e.department)])).sort(), [employees]);
	const filtered = employees.filter((e) => {
		if (dept !== "all" && e.department !== dept) return false;
		if (statusFilter !== "all" && e.status !== statusFilter) return false;
		return `${e.name} ${e.code} ${e.email} ${e.designation}`.toLowerCase().includes(query.trim().toLowerCase());
	});
	const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
	const safePage = Math.min(page, pages);
	const rows = filtered.slice((safePage - 1) * pageSize, safePage * pageSize);
	const activeCount = employees.filter((e) => e.status === "active").length;
	const person = employees.find((e) => e.id === profile);
	const save = () => {
		if (!draft) return;
		if (draft.name.trim().length < 2) {
			toast.error("Enter the employee name");
			return;
		}
		const basic = num(draft.basic);
		const hra = num(draft.hra);
		const special = num(draft.special);
		const pf = num(draft.pf);
		const tax = num(draft.tax);
		const other = num(draft.other);
		if ([
			basic,
			hra,
			special,
			pf,
			tax,
			other
		].some((n) => n === null)) {
			toast.error("Salary fields must be zero or more");
			return;
		}
		if ((basic ?? 0) + (hra ?? 0) + (special ?? 0) - ((pf ?? 0) + (tax ?? 0) + (other ?? 0)) < 0) {
			toast.error("Deductions cannot be more than gross pay");
			return;
		}
		const email = draft.email.trim().toLowerCase();
		if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
			toast.error("Enter a valid email");
			return;
		}
		if (employees.some((e) => e.email === email && e.id !== editing && email)) {
			toast.error("That email is already used");
			return;
		}
		const payload = {
			name: draft.name.trim(),
			gender: draft.gender,
			department: draft.department,
			designation: draft.designation.trim() || "Associate",
			email,
			phone: draft.phone.trim(),
			joinDate: draft.joinDate,
			status: draft.status,
			basic: basic ?? 0,
			hra: hra ?? 0,
			special: special ?? 0,
			pf: pf ?? 0,
			tax: tax ?? 0,
			other: other ?? 0
		};
		if (editing) {
			updateEmployee(editing, payload);
			toast.success("Employee updated");
		} else {
			const created = addEmployee(payload);
			toast.success(`${created.name} added as ${created.code}`);
		}
		setDraft(null);
		setEditing(null);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5 p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-bold tracking-tight",
					children: "Employees"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						activeCount,
						" active · ",
						employees.length - activeCount,
						" inactive"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						onClick: () => downloadText("employees.csv", employeesCsv(employees)),
						children: "Export CSV"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
						onClick: () => {
							setEditing(null);
							setDraft(emptyDraft());
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Add employee"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "overflow-hidden rounded-2xl border border-border bg-surface shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 border-b border-border p-4 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								placeholder: "Search name, code, email",
								value: query,
								onChange: (e) => {
									setQuery(e.target.value);
									setPage(1);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: fieldClass,
								value: dept,
								onChange: (e) => {
									setDept(e.target.value);
									setPage(1);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "all",
									children: "All departments"
								}), departments.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: d }, d))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: fieldClass,
								value: statusFilter,
								onChange: (e) => {
									setStatusFilter(e.target.value);
									setPage(1);
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "all",
										children: "Active and inactive"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "active",
										children: "Active only"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "inactive",
										children: "Inactive only"
									})
								]
							})
						]
					}),
					rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						title: "No matching employees",
						body: "Change the filters, or add someone new."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-3xl text-left text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "text-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 font-medium",
											children: "Employee"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 font-medium",
											children: "Department"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 font-medium",
											children: "Gross"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 font-medium",
											children: "Net"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 font-medium",
											children: "Status"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 font-medium",
											children: "Action"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: clsx("border-b border-border last:border-0", e.status === "inactive" && "opacity-70"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setProfile(e.id),
											className: "flex items-center gap-3 text-left",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
												name: e.name,
												female: e.gender === "f"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block font-semibold",
												children: e.name
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "block text-xs text-muted",
												children: [
													e.code,
													" · ",
													e.designation
												]
											})] })]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: e.department
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: inr(grossOf(e))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 font-semibold",
										children: inr(grossOf(e) - statutoryOf(e))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: e.status === "active" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, {
											tone: "good",
											children: "Active"
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, {
											tone: "neutral",
											children: "Inactive"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "h-11 rounded-xl px-3 text-sm font-medium hover:bg-bg",
												onClick: () => {
													const next = e.status === "active" ? "inactive" : "active";
													setStatus(e.id, next);
													toast.success(`${e.name} is now ${next}`);
												},
												children: e.status === "active" ? "Deactivate" : "Activate"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "h-11 rounded-xl px-3 text-sm font-medium text-primary hover:bg-primary-soft",
												onClick: () => {
													setEditing(e.id);
													setDraft(fromEmployee(e));
												},
												children: "Edit"
											})]
										})
									})
								]
							}, e.id)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pagination, {
						page: safePage,
						pages,
						pageSize,
						total: filtered.length,
						noun: "employees",
						onPage: setPage,
						onPageSize: (n) => {
							setPageSize(n);
							setPage(1);
						}
					})
				]
			}),
			draft ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmployeeForm, {
				title: editing ? "Edit employee" : "New employee",
				draft,
				departments,
				onChange: setDraft,
				onClose: () => {
					setDraft(null);
					setEditing(null);
				},
				onSave: save
			}) : null,
			person ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-3 sm:items-center",
				onMouseDown: () => setProfile(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "dialog",
					"aria-label": person.name,
					className: "max-h-[92dvh] w-full max-w-lg overflow-y-auto rounded-2xl bg-surface p-5 shadow-card",
					onMouseDown: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
									name: person.name,
									female: person.gender === "f"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "truncate text-lg font-semibold",
										children: person.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm text-muted",
										children: [
											person.code,
											" · ",
											person.designation,
											" · ",
											person.department
										]
									})]
								}),
								person.status === "active" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, {
									tone: "good",
									children: "Active"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, {
									tone: "neutral",
									children: "Inactive"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-4 grid grid-cols-2 gap-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
									label: "Email",
									value: person.email || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
									label: "Phone",
									value: person.phone || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
									label: "Joined",
									value: person.joinDate
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
									label: "Net salary",
									value: inr(grossOf(person) - statutoryOf(person))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
									label: "Basic",
									value: inr(person.basic)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
									label: "HRA",
									value: inr(person.hra)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
									label: "Special",
									value: inr(person.special)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
									label: "PF",
									value: inr(person.pf)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
									label: "Tax",
									value: inr(person.tax)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
									label: "Other",
									value: inr(person.other)
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-4 text-sm font-semibold",
							children: "Leave balance"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 grid grid-cols-2 gap-2 text-sm sm:grid-cols-4",
							children: LEAVE_TYPES.map((type) => {
								const used = leaveReserved(leaves, person.id, type);
								const left = Math.max(0, LEAVE_QUOTA[type] - used);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl bg-bg px-3 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted",
										children: type
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-semibold",
										children: type === "Unpaid" ? "Open" : `${left} left`
									})]
								}, type);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-xs text-muted",
							children: ["This month attendance exceptions: ", monthDates(period).filter((d) => {
								const kind = dayKind(person, d, marks);
								return kind === "absent" || kind === "half" || kind === "leave" || kind === "unpaid";
							}).length]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex flex-wrap justify-end gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
									onClick: () => setProfile(null),
									children: "Close"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
									onClick: () => {
										const next = person.status === "active" ? "inactive" : "active";
										setStatus(person.id, next);
										toast.success(`${person.name} is now ${next}`);
									},
									children: person.status === "active" ? "Mark inactive" : "Mark active"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
									onClick: () => {
										setEditing(person.id);
										setDraft(fromEmployee(person));
										setProfile(null);
									},
									children: "Edit"
								})
							]
						})
					]
				})
			}) : null
		]
	});
}
function Info({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-bg px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "truncate font-medium",
			children: value
		})]
	});
}
function EmployeeForm({ title, draft, departments, onChange, onClose, onSave }) {
	const set = (patch) => onChange({
		...draft,
		...patch
	});
	const gross = (num(draft.basic) ?? 0) + (num(draft.hra) ?? 0) + (num(draft.special) ?? 0);
	const ded = (num(draft.pf) ?? 0) + (num(draft.tax) ?? 0) + (num(draft.other) ?? 0);
	const roles = ROLES[draft.department] ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-3 sm:items-center",
		onMouseDown: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-label": title,
			className: "max-h-[92dvh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-surface p-5 shadow-card",
			onMouseDown: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Inactive people stay on record but drop out of future payroll runs."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm sm:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-1 block font-medium",
								children: "Full name"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: draft.name,
								onChange: (e) => set({ name: e.target.value })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-1 block font-medium",
								children: "Gender"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: fieldClass,
								value: draft.gender,
								onChange: (e) => set({ gender: e.target.value }),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "m",
									children: "Male"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "f",
									children: "Female"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-1 block font-medium",
								children: "Status"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: fieldClass,
								value: draft.status,
								onChange: (e) => set({ status: e.target.value }),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "active",
									children: "Active"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "inactive",
									children: "Inactive"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-1 block font-medium",
								children: "Department"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: fieldClass,
								value: draft.department,
								onChange: (e) => set({ department: e.target.value }),
								children: departments.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: d }, d))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-1 block font-medium",
									children: "Designation"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: fieldClass,
									list: "role-list",
									value: draft.designation,
									onChange: (e) => set({ designation: e.target.value })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
									id: "role-list",
									children: roles.map((role) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: role }, role))
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-1 block font-medium",
								children: "Email"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: draft.email,
								onChange: (e) => set({ email: e.target.value })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-1 block font-medium",
								children: "Phone"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: draft.phone,
								onChange: (e) => set({ phone: e.target.value })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-1 block font-medium",
								children: "Join date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "date",
								className: fieldClass,
								value: draft.joinDate,
								onChange: (e) => set({ joinDate: e.target.value })
							})]
						}),
						[
							["basic", "Basic"],
							["hra", "HRA"],
							["special", "Special allowance"],
							["pf", "PF deduction"],
							["tax", "Tax"],
							["other", "Other deduction"]
						].map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-1 block font-medium",
								children: label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								inputMode: "numeric",
								value: draft[key],
								onChange: (e) => set({ [key]: e.target.value })
							})]
						}, key))
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-muted",
					children: [
						"Gross ",
						inr(gross),
						" · Deductions ",
						inr(ded),
						" · Net ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-fg",
							children: inr(gross - ded)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						onClick: onClose,
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						onClick: onSave,
						children: "Save employee"
					})]
				})
			]
		})
	});
}
var OPTIONS = [
	{
		value: "present",
		label: "Present"
	},
	{
		value: "absent",
		label: "Absent"
	},
	{
		value: "half",
		label: "Half day"
	},
	{
		value: "leave",
		label: "Paid leave"
	},
	{
		value: "unpaid",
		label: "Unpaid leave"
	}
];
function AttendanceView() {
	const employees = useHr((s) => s.employees);
	const marks = useHr((s) => s.marks);
	const period = useHr((s) => s.period);
	const setPeriod = useHr((s) => s.setPeriod);
	const setMark = useHr((s) => s.setMark);
	const clearDay = useHr((s) => s.clearDay);
	const dates = (0, import_react.useMemo)(() => monthDates(period), [period]);
	const [day, setDay] = (0, import_react.useState)(() => dates.find((d) => !isWeekoff(d) && !isHoliday(d)) ?? dates[0] ?? period + "-01");
	const [query, setQuery] = (0, import_react.useState)("");
	const [onlyExceptions, setOnlyExceptions] = (0, import_react.useState)(false);
	const [showInactive, setShowInactive] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const next = monthDates(period);
		const preferred = next.includes("2026-10-08") && period === "2026-10" ? "2026-10-08" : next.find((d) => !isWeekoff(d) && !isHoliday(d)) ?? next[0];
		if (preferred) setDay(preferred);
	}, [period]);
	const holiday = isHoliday(day);
	const weekend = isWeekoff(day);
	const lockedDay = holiday || weekend;
	const visible = employees.filter((e) => {
		if (!showInactive && e.status !== "active") return false;
		if (e.joinDate > day) return false;
		if (!`${e.name} ${e.code} ${e.department}`.toLowerCase().includes(query.trim().toLowerCase())) return false;
		if (!onlyExceptions) return true;
		const kind = dayKind(e, day, marks);
		return kind === "absent" || kind === "half" || kind === "leave" || kind === "unpaid";
	});
	const counts = countKinds(employees.filter((e) => e.status === "active" && e.joinDate <= day).map((e) => dayKind(e, day, marks)));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5 p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-bold tracking-tight",
					children: "Attendance"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						prettyDate(day),
						" · ",
						monthLabel(period)
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MonthPicker, {
					value: period,
					onChange: setPeriod
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "no-scrollbar flex gap-2 overflow-x-auto pb-1",
				children: dates.map((date) => {
					const off = isWeekoff(date) || isHoliday(date);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setDay(date),
						className: clsx("flex h-16 w-14 shrink-0 flex-col items-center justify-center rounded-xl border text-xs", date === day ? "border-primary bg-primary text-on-primary" : off ? "border-transparent bg-surface text-muted" : "border-border bg-surface"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: weekdayShort(date) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-semibold",
							children: Number(date.slice(8))
						})]
					}, date);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						label: "Present",
						value: counts.present
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						label: "Absent / unpaid",
						value: counts.absent + counts.unpaid
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						label: "Half day",
						value: counts.half
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						label: "Paid leave",
						value: counts.leave
					})
				]
			}),
			holiday ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-2xl bg-primary-soft px-4 py-3 text-sm text-primary-dark",
				children: "National holiday — paid day off. Attendance is not required."
			}) : null,
			weekend ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-2xl bg-bg px-4 py-3 text-sm text-muted",
				children: "Weekend. Loss of pay is not counted."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "overflow-hidden rounded-2xl border border-border bg-surface shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 border-b border-border p-4 lg:flex-row lg:items-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: clsx(fieldClass, "lg:max-w-xs"),
							placeholder: "Search employee",
							value: query,
							onChange: (e) => setQuery(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex h-11 items-center gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: onlyExceptions,
								onChange: (e) => setOnlyExceptions(e.target.checked)
							}), "Exceptions only"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex h-11 items-center gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: showInactive,
								onChange: (e) => setShowInactive(e.target.checked)
							}), "Show inactive"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "lg:ml-auto",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
								onClick: () => {
									if (lockedDay) return;
									clearDay(day);
									toast.success("Everyone marked present");
								},
								children: "Mark everyone present"
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "divide-y divide-border",
					children: [
						visible.slice(0, 80).map((e) => {
							const kind = dayKind(e, day, marks);
							const editable = !lockedDay && e.status === "active";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex min-w-0 flex-1 items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
										name: e.name,
										female: e.gender === "f"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate font-semibold",
											children: e.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-muted",
											children: [
												e.code,
												" · ",
												e.department
											]
										})]
									})]
								}), editable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									className: clsx(fieldClass, "sm:max-w-48", kind !== "present" && "border-primary text-primary-dark"),
									value: kind === "weekoff" || kind === "holiday" ? "present" : kind,
									onChange: (e2) => setMark(e.id, day, e2.target.value),
									children: OPTIONS.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: opt.value,
										children: opt.label
									}, opt.value))
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-muted",
									children: labelFor(kind, e.status)
								})]
							}, e.id);
						}),
						visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "px-4 py-10 text-center text-sm text-muted",
							children: "No employees match."
						}) : null,
						visible.length > 80 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "px-4 py-3 text-sm text-muted",
							children: [
								"Showing 80 of ",
								visible.length,
								". Search to narrow the list."
							]
						}) : null
					]
				})]
			})
		]
	});
}
function countKinds(kinds) {
	return kinds.reduce((a, k) => ({
		...a,
		[k]: (a[k] ?? 0) + 1
	}), {
		present: 0,
		absent: 0,
		half: 0,
		leave: 0,
		unpaid: 0,
		weekoff: 0,
		holiday: 0
	});
}
function labelFor(kind, status) {
	if (status !== "active") return "Inactive";
	if (kind === "holiday") return "Holiday";
	if (kind === "weekoff") return "Week off";
	return kind;
}
function Chip({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-border bg-surface px-4 py-3 shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xl font-semibold",
			children: value
		})]
	});
}
function LeaveView() {
	const employees = useHr((s) => s.employees);
	const leaves = useHr((s) => s.leaves);
	const addLeave = useHr((s) => s.addLeave);
	const decideLeave = useHr((s) => s.decideLeave);
	const withdrawLeave = useHr((s) => s.withdrawLeave);
	const map = employeeMap(employees);
	const [tab, setTab] = (0, import_react.useState)("pending");
	const [page, setPage] = (0, import_react.useState)(1);
	const [pageSize, setPageSize] = (0, import_react.useState)(10);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [employeeId, setEmployeeId] = (0, import_react.useState)(employees.find((e) => e.status === "active")?.id ?? "");
	const [type, setType] = (0, import_react.useState)("Casual");
	const [from, setFrom] = (0, import_react.useState)("2026-10-09");
	const [to, setTo] = (0, import_react.useState)("2026-10-09");
	const [reason, setReason] = (0, import_react.useState)("");
	const filtered = leaves.filter((l) => tab === "all" || l.status === tab);
	const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
	const safePage = Math.min(page, pages);
	const rows = filtered.slice((safePage - 1) * pageSize, safePage * pageSize);
	const days = eachWorkingDay(from, to);
	const selected = employees.find((e) => e.id === employeeId);
	const left = selected && type !== "Unpaid" ? LEAVE_QUOTA[type] - leaveReserved(leaves, selected.id, type) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5 p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-bold tracking-tight",
					children: "Leave"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [leaves.filter((l) => l.status === "pending").length, " waiting for a decision"]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					onClick: () => setOpen(true),
					children: "Apply leave"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					"pending",
					"approved",
					"rejected",
					"all"
				].map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setTab(key);
						setPage(1);
					},
					className: clsx("h-11 rounded-full px-4 text-sm font-medium capitalize", tab === key ? "bg-primary text-on-primary" : "bg-surface text-fg ring-1 ring-border"),
					children: key
				}, key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "overflow-hidden rounded-2xl border border-border bg-surface shadow-card",
				children: [rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					title: "Nothing in this tab",
					body: "New requests show up under Pending until you approve or reject them."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-border",
					children: rows.map((leave) => {
						const e = map.get(leave.employeeId);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex flex-col gap-3 px-4 py-4 lg:flex-row lg:items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex min-w-0 flex-1 items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
									name: e?.name ?? "?",
									female: e?.gender === "f"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "truncate font-semibold",
											children: [
												e?.name ?? "Employee",
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-normal text-muted",
													children: e?.code
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-sm text-muted",
											children: [
												leave.type,
												" · ",
												prettyDate(leave.from),
												leave.from !== leave.to ? ` – ${prettyDate(leave.to)}` : "",
												" · ",
												leave.days,
												" day",
												leave.days === 1 ? "" : "s"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm",
											children: leave.reason
										})
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									leave.status === "pending" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, {
										tone: "warn",
										children: "Pending"
									}) : null,
									leave.status === "approved" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, {
										tone: "good",
										check: true,
										children: "Approved"
									}) : null,
									leave.status === "rejected" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, {
										tone: "bad",
										children: "Rejected"
									}) : null,
									leave.status === "pending" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "h-11 rounded-xl bg-primary px-3 text-sm font-semibold text-on-primary",
											onClick: () => {
												decideLeave(leave.id, "approved");
												toast.success("Leave approved and marked on attendance");
											},
											children: "Approve"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "h-11 rounded-xl px-3 text-sm font-medium text-danger hover:bg-danger-soft",
											onClick: () => {
												decideLeave(leave.id, "rejected");
												toast.success("Leave rejected");
											},
											children: "Reject"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "h-11 rounded-xl px-3 text-sm text-muted hover:bg-bg",
											onClick: () => {
												withdrawLeave(leave.id);
												toast.success("Request withdrawn");
											},
											children: "Withdraw"
										})
									] }) : null
								]
							})]
						}, leave.id);
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pagination, {
					page: safePage,
					pages,
					pageSize,
					total: filtered.length,
					noun: "requests",
					onPage: setPage,
					onPageSize: (size) => {
						setPageSize(size);
						setPage(1);
					}
				})]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-3 sm:items-center",
				onMouseDown: () => setOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "dialog",
					"aria-label": "Apply leave",
					className: "w-full max-w-lg rounded-2xl bg-surface p-5 shadow-card",
					onMouseDown: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold",
							children: "Apply leave"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mb-1 block font-medium",
										children: "Employee"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										className: fieldClass,
										value: employeeId,
										onChange: (e) => setEmployeeId(e.target.value),
										children: employees.filter((e) => e.status === "active").map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
											value: e.id,
											children: [
												e.name,
												" · ",
												e.code
											]
										}, e.id))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mb-1 block font-medium",
										children: "Type"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										className: fieldClass,
										value: type,
										onChange: (e) => setType(e.target.value),
										children: LEAVE_TYPES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mb-1 block font-medium",
											children: "From"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "date",
											className: fieldClass,
											value: from,
											onChange: (e) => setFrom(e.target.value)
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mb-1 block font-medium",
											children: "To"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "date",
											className: fieldClass,
											value: to,
											onChange: (e) => setTo(e.target.value)
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mb-1 block font-medium",
										children: "Reason"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										className: "min-h-24 w-full rounded-xl border border-border px-3 py-2 text-sm outline-none focus:border-primary",
										value: reason,
										onChange: (e) => setReason(e.target.value)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted",
									children: [
										days.length,
										" working day",
										days.length === 1 ? "" : "s",
										left !== null ? ` · ${Math.max(0, left)} ${type.toLowerCase()} left` : ""
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
								onClick: () => setOpen(false),
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
								onClick: () => {
									const result = addLeave({
										employeeId,
										type,
										from,
										to,
										reason
									});
									if (!result.ok) {
										toast.error(result.reason);
										return;
									}
									toast.success("Leave request submitted");
									setReason("");
									setOpen(false);
									setTab("pending");
								},
								children: "Submit"
							})]
						})
					]
				})
			}) : null
		]
	});
}
function DashboardView() {
	const data = useHr();
	const { employees, marks, leaves, settings, period, setView, setPeriod, decideLeave } = data;
	const active = employees.filter((e) => e.status === "active");
	const todayPeople = active.filter((e) => e.joinDate <= TODAY);
	const present = todayPeople.filter((e) => dayKind(e, TODAY, marks) === "present").length;
	const away = todayPeople.filter((e) => {
		const kind = dayKind(e, TODAY, marks);
		return kind === "absent" || kind === "unpaid" || kind === "leave" || kind === "half";
	}).length;
	const pending = leaves.filter((l) => l.status === "pending");
	const { lines, locked } = linesFor(data, period);
	const net = lines.reduce((s, l) => s + l.net, 0);
	const trend = Object.keys(data.snapshots).sort().map((month) => ({
		label: monthLabel(month).slice(0, 3),
		total: data.snapshots[month]?.reduce((s, l) => s + l.net, 0) ?? 0
	}));
	const deptNet = /* @__PURE__ */ new Map();
	const map = new Map(employees.map((e) => [e.id, e]));
	for (const line of lines) {
		const dept = map.get(line.employeeId)?.department ?? "Other";
		deptNet.set(dept, (deptNet.get(dept) ?? 0) + line.net);
	}
	const bars = [...deptNet.entries()].sort((a, b) => b[1] - a[1]);
	const max = Math.max(...bars.map((b) => b[1]), 1);
	const recent = [...employees].sort((a, b) => b.joinDate.localeCompare(a.joinDate)).slice(0, 5);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5 p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-bold tracking-tight",
					children: settings.company
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: ["Overview for ", prettyDate(TODAY)]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setView("payroll"),
					className: "h-11 rounded-xl bg-primary px-4 text-sm font-semibold text-on-primary",
					children: "Open payroll"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						label: "Active employees",
						value: String(active.length),
						hint: `${employees.length - active.length} inactive`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						label: "Present today",
						value: String(present),
						hint: `${away} away or half day`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						label: "Leave waiting",
						value: String(pending.length),
						hint: "Needs a decision"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						label: monthLabel(period),
						value: inr(net),
						hint: locked ? "Payroll completed" : "Draft projection"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 xl:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-border bg-surface p-4 shadow-card xl:col-span-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-semibold",
							children: "Payroll trend"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-sm text-muted",
							children: "Completed months, net pay"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendChart, { data: trend })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-border bg-surface p-4 shadow-card xl:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-semibold",
							children: "Cost by department"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-sm text-muted",
							children: monthLabel(period)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "flex flex-col gap-3",
							children: bars.map(([name, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-1 flex justify-between text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: inr(value)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-2 overflow-hidden rounded-full bg-bg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full bg-primary",
									style: { width: `${Math.max(4, value / max * 100)}%` }
								})
							})] }, name))
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-border bg-surface p-4 shadow-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-semibold",
								children: "Pending leave"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-sm font-medium text-primary",
								onClick: () => setView("leave"),
								children: "View all"
							})]
						}),
						pending.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "No requests waiting."
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "flex flex-col gap-3",
							children: pending.slice(0, 4).map((leave) => {
								const e = map.get(leave.employeeId);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex flex-wrap items-center justify-between gap-2 rounded-xl bg-bg px-3 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold",
										children: e?.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted",
										children: [
											leave.type,
											" · ",
											leave.days,
											" day",
											leave.days === 1 ? "" : "s",
											" · ",
											leave.reason
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "h-10 rounded-xl bg-primary px-3 text-sm font-semibold text-on-primary",
										onClick: () => decideLeave(leave.id, "approved"),
										children: "Approve"
									})]
								}, leave.id);
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-border bg-surface p-4 shadow-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-3 font-semibold",
							children: "Recently joined"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "flex flex-col gap-3",
							children: recent.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between gap-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: e.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted",
									children: [
										e.department,
										" · ",
										prettyDate(e.joinDate)
									]
								})] }), e.status === "active" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, {
									tone: "good",
									children: "Active"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, {
									tone: "neutral",
									children: "Inactive"
								})]
							}, e.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-wrap gap-2",
							children: [[
								["employees", "Employees"],
								["attendance", "Attendance"],
								["reports", "Reports"]
							].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setView(id),
								className: "h-11 rounded-xl border border-border px-3 text-sm font-medium hover:bg-bg",
								children: label
							}, id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setPeriod(TODAY.slice(0, 7)),
								className: "h-11 rounded-xl border border-border px-3 text-sm font-medium hover:bg-bg",
								children: "Jump to October"
							})]
						})
					]
				})]
			})
		]
	});
}
function Tile({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-border bg-surface p-4 shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-2xl font-semibold tracking-tight",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: hint
			})
		]
	});
}
function ReportsView() {
	const data = useHr();
	const { lines, locked } = linesFor(data, data.period);
	const map = (0, import_react.useMemo)(() => employeeMap(data.employees), [data.employees]);
	const [dept, setDept] = (0, import_react.useState)("all");
	const departments = (0, import_react.useMemo)(() => Array.from(new Set(data.employees.map((e) => e.department))).sort(), [data.employees]);
	const scoped = dept === "all" ? lines : lines.filter((l) => map.get(l.employeeId)?.department === dept);
	const totals = sumLines(scoped);
	const byDept = departments.map((name) => {
		return {
			name,
			...sumLines(lines.filter((l) => map.get(l.employeeId)?.department === name))
		};
	}).filter((d) => d.count > 0);
	const trend = Object.keys(data.snapshots).sort().map((month) => ({
		label: monthLabel(month).slice(0, 3),
		total: data.snapshots[month]?.reduce((s, l) => s + l.net, 0) ?? 0
	}));
	const lop = scoped.reduce((s, l) => s + l.lop, 0);
	const bonus = scoped.reduce((s, l) => s + l.bonus, 0);
	const extra = scoped.reduce((s, l) => s + l.extra, 0);
	const statutory = totals.deductions - lop - extra;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5 p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-bold tracking-tight",
					children: "Reports"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						monthLabel(data.period),
						" · ",
						locked ? "Completed run" : "Draft projection"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MonthPicker, {
						value: data.period,
						onChange: data.setPeriod
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						onClick: () => downloadText(`payroll-${data.period}.csv`, payrollCsv(scoped, data.employees, data.period)),
						children: "Export CSV"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "Net payroll",
						value: inr(totals.net)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "Gross + bonus",
						value: inr(totals.gross)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "Statutory",
						value: inr(statutory)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "Loss of pay",
						value: inr(lop)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-border bg-surface p-4 shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 font-semibold",
					children: "Department cost"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeptChart, { data: byDept.map((d) => ({
					name: d.name,
					net: d.net
				})) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "overflow-hidden rounded-2xl border border-border bg-surface shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-3 border-b border-border p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-semibold",
							children: "Breakdown"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "h-11 rounded-xl border border-border bg-surface px-3 text-sm",
							value: dept,
							onChange: (e) => setDept(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "all",
								children: "All departments"
							}), departments.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: name }, name))]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-3xl text-left text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "text-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 font-medium",
											children: "Department"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 font-medium",
											children: "People"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 font-medium",
											children: "Gross"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 font-medium",
											children: "Deductions"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 font-medium",
											children: "Net"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: (dept === "all" ? byDept : byDept.filter((d) => d.name === dept)).map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border last:border-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 font-medium",
										children: row.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: row.count
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: inr(row.gross)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: inr(row.deductions)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 font-semibold",
										children: inr(row.net)
									})
								]
							}, row.name)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "px-4 py-3 text-sm text-muted",
						children: [
							"Bonus ",
							inr(bonus),
							" · extra deductions ",
							inr(extra),
							" · loss of pay ",
							inr(lop),
							". Completed months stay frozen."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-border bg-surface p-4 shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 font-semibold",
					children: "Completed months"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendChart, { data: trend })]
			})
		]
	});
}
function Mini({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-border bg-surface p-4 shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "truncate text-xl font-semibold",
			children: value
		})]
	});
}
function DocumentsView() {
	const documents = useHr((s) => s.documents);
	const employees = useHr((s) => s.employees);
	const addDocument = useHr((s) => s.addDocument);
	const removeDocument = useHr((s) => s.removeDocument);
	const map = employeeMap(employees);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [title, setTitle] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)(DOC_CATEGORIES[0]);
	const [employeeId, setEmployeeId] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)("2026-10-08");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5 p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-bold tracking-tight",
					children: "Documents"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Policies, offers, and payroll notes kept with the company file."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					onClick: () => setOpen(true),
					children: "Add document"
				})]
			}),
			documents.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "rounded-2xl border border-border bg-surface shadow-card",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					title: "No documents yet",
					body: "Add a policy or an offer letter so the team can find it later."
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-3 md:grid-cols-2",
				children: documents.map((doc) => {
					const person = doc.employeeId ? map.get(doc.employeeId) : void 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-col rounded-2xl border border-border bg-surface p-4 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold tracking-wide text-primary",
									children: doc.category
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-semibold",
									children: doc.title
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "h-11 rounded-xl px-3 text-sm text-danger hover:bg-danger-soft",
									onClick: () => {
										removeDocument(doc.id);
										toast.success("Document removed");
									},
									children: "Remove"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 flex-1 text-sm text-muted",
								children: doc.note
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 text-xs text-muted",
								children: [prettyDate(doc.date), person ? ` · ${person.name}` : ""]
							})
						]
					}, doc.id);
				})
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-3 sm:items-center",
				onMouseDown: () => setOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "dialog",
					"aria-label": "Add document",
					className: "w-full max-w-lg rounded-2xl bg-surface p-5 shadow-card",
					onMouseDown: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold",
							children: "Add document"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mb-1 block font-medium",
										children: "Title"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: fieldClass,
										value: title,
										onChange: (e) => setTitle(e.target.value)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mb-1 block font-medium",
										children: "Category"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										className: fieldClass,
										value: category,
										onChange: (e) => setCategory(e.target.value),
										children: DOC_CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mb-1 block font-medium",
										children: "Linked employee"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: fieldClass,
										value: employeeId,
										onChange: (e) => setEmployeeId(e.target.value),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											children: "Company-wide"
										}), employees.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: e.id,
											children: e.name
										}, e.id))]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mb-1 block font-medium",
										children: "Date"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "date",
										className: fieldClass,
										value: date,
										onChange: (e) => setDate(e.target.value)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mb-1 block font-medium",
										children: "Note"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										className: "min-h-24 w-full rounded-xl border border-border px-3 py-2 text-sm outline-none focus:border-primary",
										value: note,
										onChange: (e) => setNote(e.target.value)
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
								onClick: () => setOpen(false),
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
								onClick: () => {
									if (title.trim().length < 2) {
										toast.error("Add a title");
										return;
									}
									addDocument({
										title: title.trim(),
										category,
										note: note.trim() || "No note added.",
										date,
										employeeId: employeeId || void 0
									});
									toast.success("Document added");
									setTitle("");
									setNote("");
									setOpen(false);
								},
								children: "Save"
							})]
						})
					]
				})
			}) : null
		]
	});
}
function SettingsView() {
	const settings = useHr((s) => s.settings);
	const employees = useHr((s) => s.employees);
	const updateSettings = useHr((s) => s.updateSettings);
	const loadData = useHr((s) => s.loadData);
	const resetDemo = useHr((s) => s.resetDemo);
	const [company, setCompany] = (0, import_react.useState)(settings.company);
	const [adminName, setAdminName] = (0, import_react.useState)(settings.adminName);
	const [adminRole, setAdminRole] = (0, import_react.useState)(settings.adminRole);
	const [workingDays, setWorkingDays] = (0, import_react.useState)(String(settings.workingDays));
	const [payDay, setPayDay] = (0, import_react.useState)(String(settings.payDay));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-3xl flex-col gap-5 p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold tracking-tight",
				children: "Settings"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Company profile and how draft payroll calculates loss of pay."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-border bg-surface p-5 shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "Company"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm sm:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-1 block font-medium",
									children: "Company name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: fieldClass,
									value: company,
									onChange: (e) => setCompany(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-1 block font-medium",
									children: "Admin name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: fieldClass,
									value: adminName,
									onChange: (e) => setAdminName(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-1 block font-medium",
									children: "Role"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: fieldClass,
									value: adminRole,
									onChange: (e) => setAdminRole(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-1 block font-medium",
									children: "Working days / month"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: fieldClass,
									inputMode: "numeric",
									value: workingDays,
									onChange: (e) => setWorkingDays(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-1 block font-medium",
									children: "Pay day"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: fieldClass,
									inputMode: "numeric",
									value: payDay,
									onChange: (e) => setPayDay(e.target.value)
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "Loss of pay uses gross ÷ working days. 26 Jan, 15 Aug, and 2 Oct are paid holidays. Completed payroll months ignore later changes until reopened."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
							onClick: () => {
								const days = Math.round(Number(workingDays));
								const pay = Math.round(Number(payDay));
								if (!company.trim() || !adminName.trim()) {
									toast.error("Company and admin name are required");
									return;
								}
								if (days < 20 || days > 31 || pay < 1 || pay > 28) {
									toast.error("Working days must be 20–31 and pay day 1–28");
									return;
								}
								updateSettings({
									company: company.trim(),
									adminName: adminName.trim(),
									adminRole: adminRole.trim() || "Admin",
									workingDays: days,
									payDay: pay
								});
								toast.success("Settings saved");
							},
							children: "Save settings"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-border bg-surface p-5 shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "Backup"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Everything stays in this browser. Download a file if you want a copy, or restore one later."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
								onClick: () => {
									const state = useHr.getState();
									const file = {
										employees: state.employees,
										marks: state.marks,
										leaves: state.leaves,
										snapshots: state.snapshots,
										adjustments: state.adjustments,
										documents: state.documents,
										settings: state.settings,
										period: state.period
									};
									downloadText("bizhr-backup.json", JSON.stringify(file), "application/json");
								},
								children: "Download backup"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
								onClick: () => downloadText("employees.csv", employeesCsv(employees)),
								children: "Employee CSV"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "inline-flex h-11 cursor-pointer items-center rounded-xl border border-border bg-surface px-4 text-sm font-medium hover:bg-bg",
								children: ["Restore backup", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: "application/json",
									className: "sr-only",
									onChange: async (e) => {
										const file = e.target.files?.[0];
										e.target.value = "";
										if (!file) return;
										try {
											const parsed = JSON.parse(await file.text());
											if (!isBackup(parsed)) {
												toast.error("That file is not a BIZHR backup");
												return;
											}
											loadData(parsed);
											toast.success("Backup restored");
										} catch {
											toast.error("Could not read that file");
										}
									}
								})]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-border bg-surface p-5 shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "Demo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Put back the original worksheet: 148 people, June 2026 completed, total payroll ₹ 82,45,600."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-11 rounded-xl bg-danger px-4 text-sm font-semibold text-on-primary",
							onClick: () => {
								resetDemo();
								const fresh = createSeed().settings;
								setCompany(fresh.company);
								setAdminName(fresh.adminName);
								setAdminRole(fresh.adminRole);
								setWorkingDays(String(fresh.workingDays));
								setPayDay(String(fresh.payDay));
								toast.success("Demo data restored");
							},
							children: "Reset demo data"
						})
					})
				]
			})
		]
	});
}
function isBackup(value) {
	if (!value || typeof value !== "object") return false;
	const v = value;
	return Array.isArray(v.employees) && v.employees.length > 0 && !!v.settings && !!v.snapshots && Array.isArray(v.leaves) && Array.isArray(v.marks) && Array.isArray(v.documents) && typeof v.period === "string";
}
function App() {
	useHydrateHr();
	const view = useHr((s) => s.view);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		view === "dashboard" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardView, {}) : null,
		view === "employees" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmployeesView, {}) : null,
		view === "attendance" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AttendanceView, {}) : null,
		view === "leave" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeaveView, {}) : null,
		view === "payroll" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PayrollView, {}) : null,
		view === "reports" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportsView, {}) : null,
		view === "documents" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentsView, {}) : null,
		view === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsView, {}) : null
	] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, { position: "top-center" })] });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(App, {});
}
//#endregion
export { Home as component };
