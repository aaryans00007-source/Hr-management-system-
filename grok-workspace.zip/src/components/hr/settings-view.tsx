import { useState } from "react";
import { toast } from "sonner";
import { createSeed, employeesCsv, type HrData } from "@/lib/hr/model";
import { useHr } from "@/lib/hr/store";
import { downloadText, fieldClass, GhostButton, PrimaryButton } from "@/components/hr/widgets";

export function SettingsView() {
  const settings = useHr((s) => s.settings);
  const employees = useHr((s) => s.employees);
  const updateSettings = useHr((s) => s.updateSettings);
  const loadData = useHr((s) => s.loadData);
  const resetDemo = useHr((s) => s.resetDemo);
  const [company, setCompany] = useState(settings.company);
  const [adminName, setAdminName] = useState(settings.adminName);
  const [adminRole, setAdminRole] = useState(settings.adminRole);
  const [workingDays, setWorkingDays] = useState(String(settings.workingDays));
  const [payDay, setPayDay] = useState(String(settings.payDay));

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-5 p-4 sm:p-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
        <p className="text-sm text-muted">Company profile and how draft payroll calculates loss of pay.</p>
      </div>
      <section className="rounded-2xl border border-border bg-surface p-5 shadow-card">
        <h2 className="font-semibold">Company</h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <label className="text-sm sm:col-span-2">
            <span className="mb-1 block font-medium">Company name</span>
            <input className={fieldClass} value={company} onChange={(e) => setCompany(e.target.value)} />
          </label>
          <label className="text-sm">
            <span className="mb-1 block font-medium">Admin name</span>
            <input className={fieldClass} value={adminName} onChange={(e) => setAdminName(e.target.value)} />
          </label>
          <label className="text-sm">
            <span className="mb-1 block font-medium">Role</span>
            <input className={fieldClass} value={adminRole} onChange={(e) => setAdminRole(e.target.value)} />
          </label>
          <label className="text-sm">
            <span className="mb-1 block font-medium">Working days / month</span>
            <input className={fieldClass} inputMode="numeric" value={workingDays} onChange={(e) => setWorkingDays(e.target.value)} />
          </label>
          <label className="text-sm">
            <span className="mb-1 block font-medium">Pay day</span>
            <input className={fieldClass} inputMode="numeric" value={payDay} onChange={(e) => setPayDay(e.target.value)} />
          </label>
        </div>
        <p className="mt-3 text-sm text-muted">
          Loss of pay uses gross ÷ working days. 26 Jan, 15 Aug, and 2 Oct are paid holidays. Completed payroll months ignore later changes until reopened.
        </p>
        <div className="mt-4">
          <PrimaryButton
            onClick={() => {
              const days = Math.round(Number(workingDays));
              const pay = Math.round(Number(payDay));
              if (!company.trim() || !adminName.trim()) {
                toast.error("Company and admin name are required");
                return;
              }
              if (days < 20 || days > 31 || pay < 1 || pay > 28) {
                toast.error("Working days must be 20–31 and pay day 1–28");
                return;
              }
              updateSettings({ company: company.trim(), adminName: adminName.trim(), adminRole: adminRole.trim() || "Admin", workingDays: days, payDay: pay });
              toast.success("Settings saved");
            }}
          >
            Save settings
          </PrimaryButton>
        </div>
      </section>
      <section className="rounded-2xl border border-border bg-surface p-5 shadow-card">
        <h2 className="font-semibold">Backup</h2>
        <p className="mt-1 text-sm text-muted">Everything stays in this browser. Download a file if you want a copy, or restore one later.</p>
        <div className="mt-4 flex flex-wrap gap-2">
          <GhostButton
            onClick={() => {
              const state = useHr.getState();
              const file = {
                employees: state.employees,
                marks: state.marks,
                leaves: state.leaves,
                snapshots: state.snapshots,
                adjustments: state.adjustments,
                documents: state.documents,
                settings: state.settings,
                period: state.period,
              };
              downloadText("bizhr-backup.json", JSON.stringify(file), "application/json");
            }}
          >
            Download backup
          </GhostButton>
          <GhostButton onClick={() => downloadText("employees.csv", employeesCsv(employees))}>Employee CSV</GhostButton>
          <label className="inline-flex h-11 cursor-pointer items-center rounded-xl border border-border bg-surface px-4 text-sm font-medium hover:bg-bg">
            Restore backup
            <input
              type="file"
              accept="application/json"
              className="sr-only"
              onChange={async (e) => {
                const file = e.target.files?.[0];
                e.target.value = "";
                if (!file) return;
                try {
                  const parsed: unknown = JSON.parse(await file.text());
                  if (!isBackup(parsed)) {
                    toast.error("That file is not a BIZHR backup");
                    return;
                  }
                  loadData(parsed);
                  toast.success("Backup restored");
                } catch {
                  toast.error("Could not read that file");
                }
              }}
            />
          </label>
        </div>
      </section>
      <section className="rounded-2xl border border-border bg-surface p-5 shadow-card">
        <h2 className="font-semibold">Demo</h2>
        <p className="mt-1 text-sm text-muted">Put back the original worksheet: 148 people, June 2026 completed, total payroll ₹ 82,45,600.</p>
        <div className="mt-4">
          <button
            type="button"
            className="h-11 rounded-xl bg-danger px-4 text-sm font-semibold text-on-primary"
            onClick={() => {
              resetDemo();
              const fresh = createSeed().settings;
              setCompany(fresh.company);
              setAdminName(fresh.adminName);
              setAdminRole(fresh.adminRole);
              setWorkingDays(String(fresh.workingDays));
              setPayDay(String(fresh.payDay));
              toast.success("Demo data restored");
            }}
          >
            Reset demo data
          </button>
        </div>
      </section>
    </div>
  );
}

function isBackup(value: unknown): value is HrData {
  if (!value || typeof value !== "object") return false;
  const v = value as Partial<HrData>;
  return Array.isArray(v.employees) && v.employees.length > 0 && !!v.settings && !!v.snapshots && Array.isArray(v.leaves) && Array.isArray(v.marks) && Array.isArray(v.documents) && typeof v.period === "string";
}
