import { useEffect, useState, type ReactNode } from "react";
import { Check, ChevronLeft, ChevronRight, Calendar, X } from "lucide-react";
import { clsx } from "clsx";
import { monthLabel } from "@/lib/hr/model";

export const fieldClass =
  "h-11 w-full rounded-xl border border-border bg-surface px-3 text-sm text-fg outline-none transition-colors focus:border-primary";

export function useMounted() {
  const [on, setOn] = useState(false);
  useEffect(() => setOn(true), []);
  return on;
}

export function Avatar({ name, female, size = "md" }: { name: string; female?: boolean; size?: "sm" | "md" }) {
  const initials = name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() ?? "")
    .join("");
  return (
    <span
      className={clsx(
        "grid shrink-0 place-items-center rounded-full font-semibold",
        size === "sm" ? "size-9 text-xs" : "size-10 text-sm",
        female ? "bg-primary-soft text-primary-dark" : "bg-bg text-fg ring-1 ring-border",
      )}
      aria-hidden
    >
      {initials}
    </span>
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="flex flex-col gap-1.5 text-sm">
      <span className="font-medium text-fg">{label}</span>
      {children}
    </label>
  );
}

export function Modal({
  open,
  title,
  subtitle,
  onClose,
  children,
  wide,
}: {
  open: boolean;
  title: string;
  subtitle?: string;
  onClose: () => void;
  children: ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-3 sm:items-center" onMouseDown={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={clsx(
          "max-h-[92dvh] w-full overflow-y-auto rounded-2xl bg-surface p-5 shadow-card",
          wide ? "max-w-3xl" : "max-w-lg",
        )}
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold">{title}</h2>
            {subtitle ? <p className="mt-1 text-sm text-muted">{subtitle}</p> : null}
          </div>
          <button type="button" aria-label="Close" onClick={onClose} className="grid size-11 place-items-center rounded-full text-muted hover:bg-bg">
            <X className="size-5" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function ConfirmDialog({
  open,
  title,
  body,
  confirmLabel,
  danger,
  onConfirm,
  onClose,
}: {
  open: boolean;
  title: string;
  body: string;
  confirmLabel: string;
  danger?: boolean;
  onConfirm: () => void;
  onClose: () => void;
}) {
  return (
    <Modal open={open} title={title} onClose={onClose}>
      <p className="text-sm text-muted">{body}</p>
      <div className="mt-5 flex flex-wrap justify-end gap-2">
        <button type="button" onClick={onClose} className="h-11 rounded-xl px-4 text-sm font-medium text-fg hover:bg-bg">
          Cancel
        </button>
        <button
          type="button"
          onClick={onConfirm}
          className={clsx(
            "h-11 rounded-xl px-4 text-sm font-semibold text-on-primary",
            danger ? "bg-danger" : "bg-primary",
          )}
        >
          {confirmLabel}
        </button>
      </div>
    </Modal>
  );
}

const PAGE_SIZES = [5, 10, 20, 50];

export function Pagination({
  page,
  pages,
  pageSize,
  total,
  onPage,
  onPageSize,
  noun,
}: {
  page: number;
  pages: number;
  pageSize: number;
  total: number;
  onPage: (page: number) => void;
  onPageSize: (size: number) => void;
  noun: string;
}) {
  const from = total === 0 ? 0 : (page - 1) * pageSize + 1;
  const to = Math.min(total, page * pageSize);
  const items = pageList(page, pages);
  return (
    <div className="flex flex-col gap-3 border-t border-border px-4 py-3 text-sm text-muted sm:flex-row sm:items-center sm:justify-between">
      <p>
        Showing {from} to {to} of {total} {noun}
      </p>
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1">
          <PageButton label="Previous page" disabled={page <= 1} onClick={() => onPage(page - 1)}>
            <ChevronLeft className="size-4" />
          </PageButton>
          {items.map((item, i) =>
            item === "..." ? (
              <span key={`gap-${i}`} className="px-1">
                …
              </span>
            ) : (
              <button
                key={item}
                type="button"
                onClick={() => onPage(item)}
                className={clsx(
                  "grid size-11 place-items-center rounded-xl text-sm font-semibold",
                  item === page ? "bg-primary text-on-primary" : "text-fg hover:bg-bg",
                )}
                aria-current={item === page ? "page" : undefined}
              >
                {item}
              </button>
            ),
          )}
          <PageButton label="Next page" disabled={page >= pages} onClick={() => onPage(page + 1)}>
            <ChevronRight className="size-4" />
          </PageButton>
        </div>
        <label className="flex items-center gap-2">
          <span>Rows per page</span>
          <select
            className="h-11 rounded-xl border border-border bg-surface px-2 text-fg"
            value={pageSize}
            onChange={(e) => onPageSize(Number(e.target.value))}
          >
            {PAGE_SIZES.map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </select>
        </label>
      </div>
    </div>
  );
}

function PageButton({
  children,
  label,
  disabled,
  onClick,
}: {
  children: ReactNode;
  label: string;
  disabled?: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      disabled={disabled}
      onClick={onClick}
      className="grid size-11 place-items-center rounded-xl text-fg hover:bg-bg disabled:opacity-40"
    >
      {children}
    </button>
  );
}

function pageList(page: number, pages: number): Array<number | "..."> {
  if (pages <= 7) return Array.from({ length: pages }, (_, i) => i + 1);
  const items: Array<number | "..."> = [1];
  const start = Math.max(2, page - 1);
  const end = Math.min(pages - 1, page + 1);
  if (start > 2) items.push("...");
  for (let i = start; i <= end; i += 1) items.push(i);
  if (end < pages - 1) items.push("...");
  items.push(pages);
  return items;
}

export function MonthPicker({ value, onChange }: { value: string; onChange: (next: string) => void }) {
  const [open, setOpen] = useState(false);
  const [year, setYear] = useState(Number(value.slice(0, 4)) || 2026);
  const names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => {
          setYear(Number(value.slice(0, 4)) || 2026);
          setOpen((v) => !v);
        }}
        className="inline-flex h-11 items-center gap-2 rounded-xl border border-border bg-surface px-3 text-sm font-medium"
      >
        <Calendar className="size-4 text-muted" />
        {monthLabel(value)}
        <ChevronRight className={clsx("size-4 text-muted transition-transform", open && "rotate-90")} />
      </button>
      {open ? (
        <>
          <button type="button" className="fixed inset-0 z-30 cursor-default" aria-label="Close month picker" onClick={() => setOpen(false)} />
          <div className="absolute right-0 z-40 mt-2 w-72 rounded-2xl border border-border bg-surface p-3 shadow-card">
            <div className="mb-2 flex items-center justify-between">
              <button type="button" className="grid size-11 place-items-center rounded-xl hover:bg-bg" aria-label="Previous year" onClick={() => setYear((y) => y - 1)}>
                <ChevronLeft className="size-4" />
              </button>
              <span className="font-semibold">{year}</span>
              <button type="button" className="grid size-11 place-items-center rounded-xl hover:bg-bg" aria-label="Next year" onClick={() => setYear((y) => y + 1)}>
                <ChevronRight className="size-4" />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {names.map((name, i) => {
                const key = `${year}-${String(i + 1).padStart(2, "0")}`;
                const active = key === value;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => {
                      onChange(key);
                      setOpen(false);
                    }}
                    className={clsx(
                      "h-11 rounded-xl text-sm font-medium",
                      active ? "bg-primary text-on-primary" : "hover:bg-bg",
                    )}
                  >
                    {name}
                  </button>
                );
              })}
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}

export function StatusPill({
  tone,
  children,
  check,
}: {
  tone: "good" | "warn" | "bad" | "neutral";
  children: ReactNode;
  check?: boolean;
}) {
  return (
    <span
      className={clsx(
        "inline-flex h-8 items-center gap-1 rounded-full px-3 text-xs font-semibold",
        tone === "good" && "bg-primary-soft text-primary-dark",
        tone === "warn" && "bg-warning-soft text-warning",
        tone === "bad" && "bg-danger-soft text-danger",
        tone === "neutral" && "bg-bg text-muted",
      )}
    >
      {children}
      {check ? <Check className="size-3.5" /> : null}
    </span>
  );
}

export function EmptyState({ title, body }: { title: string; body: string }) {
  return (
    <div className="px-6 py-16 text-center">
      <p className="font-semibold">{title}</p>
      <p className="mx-auto mt-1 max-w-sm text-sm text-muted">{body}</p>
    </div>
  );
}

export function downloadText(filename: string, text: string, type = "text/csv;charset=utf-8") {
  const blob = new Blob([text], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function PrimaryButton({
  children,
  onClick,
  type = "button",
}: {
  children: ReactNode;
  onClick?: () => void;
  type?: "button" | "submit";
}) {
  return (
    <button type={type} onClick={onClick} className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-primary px-4 text-sm font-semibold text-on-primary hover:bg-primary-dark">
      {children}
    </button>
  );
}

export function GhostButton({ children, onClick, type = "button" }: { children: ReactNode; onClick?: () => void; type?: "button" | "submit" }) {
  return (
    <button type={type} onClick={onClick} className="inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-border bg-surface px-4 text-sm font-medium hover:bg-bg">
      {children}
    </button>
  );
}
