import { useState, type ReactNode } from "react";
import { clsx } from "clsx";
import {
  Bell,
  Building2,
  CalendarCheck,
  CalendarDays,
  ChevronDown,
  FileBarChart,
  Files,
  IndianRupee,
  LayoutDashboard,
  Menu,
  Settings,
  Users,
  type LucideIcon,
} from "lucide-react";
import { notifications, type ViewId } from "@/lib/hr/model";
import { useHr } from "@/lib/hr/store";
import { Avatar, ConfirmDialog } from "@/components/hr/widgets";

const NAV: { id: ViewId; label: string; icon: LucideIcon; short: string }[] = [
  { id: "dashboard", label: "Dashboard", short: "Home", icon: LayoutDashboard },
  { id: "employees", label: "Employees", short: "People", icon: Users },
  { id: "attendance", label: "Attendance", short: "Attend", icon: CalendarCheck },
  { id: "leave", label: "Leave", short: "Leave", icon: CalendarDays },
  { id: "payroll", label: "Payroll", short: "Pay", icon: IndianRupee },
  { id: "reports", label: "Reports", short: "Reports", icon: FileBarChart },
  { id: "documents", label: "Documents", short: "Docs", icon: Files },
  { id: "settings", label: "Settings", short: "Setup", icon: Settings },
];

const TOP = NAV.filter((item) => ["employees", "attendance", "leave", "payroll", "reports"].includes(item.id));

export function Shell({ children }: { children: ReactNode }) {
  const view = useHr((s) => s.view);
  const setView = useHr((s) => s.setView);
  const settings = useHr((s) => s.settings);
  const leaves = useHr((s) => s.leaves);
  const snapshots = useHr((s) => s.snapshots);
  const resetDemo = useHr((s) => s.resetDemo);
  const pending = leaves.filter((l) => l.status === "pending").length;
  const notes = notifications({ employees: [], marks: [], leaves, snapshots, adjustments: {}, documents: [], settings, period: "" });
  const [open, setOpen] = useState(false);
  const [bell, setBell] = useState(false);
  const [companyOpen, setCompanyOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  const go = (id: ViewId) => {
    setView(id);
    setOpen(false);
    setBell(false);
    setCompanyOpen(false);
    setAdminOpen(false);
  };

  return (
    <div className="flex h-dvh bg-bg text-fg">
      {open ? (
        <button type="button" className="fixed inset-0 z-40 bg-ink/40 lg:hidden" aria-label="Close menu" onClick={() => setOpen(false)} />
      ) : null}
      <aside
        className={clsx(
          "fixed inset-y-0 left-0 z-50 flex w-60 flex-col border-r border-border bg-surface transition-transform lg:static lg:translate-x-0",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex h-16 items-center px-5">
          <div>
            <p className="text-2xl font-extrabold tracking-tight text-primary">BIZHR</p>
            <p className="text-xs text-muted">by Qklipit</p>
          </div>
        </div>
        <nav className="flex min-h-0 flex-1 flex-col gap-1 overflow-y-auto px-3 py-2">
          {NAV.map((item) => {
            const active = view === item.id;
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => go(item.id)}
                className={clsx(
                  "flex h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium",
                  active ? "bg-primary text-on-primary" : "text-fg hover:bg-bg",
                )}
              >
                <Icon className="size-4 shrink-0" />
                <span className="truncate">{item.label}</span>
                {item.id === "leave" && pending > 0 ? (
                  <span className={clsx("ml-auto rounded-full px-2 text-xs font-semibold", active ? "bg-on-primary text-primary" : "bg-primary-soft text-primary-dark")}>
                    {pending}
                  </span>
                ) : null}
              </button>
            );
          })}
        </nav>
        <div className="relative p-3">
          <button
            type="button"
            onClick={() => setCompanyOpen((v) => !v)}
            className="flex w-full items-center gap-3 rounded-2xl border border-border p-3 text-left hover:bg-bg"
          >
            <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-primary-soft text-primary">
              <Building2 className="size-5" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block truncate text-sm font-semibold">{settings.company}</span>
              <span className="block text-xs text-muted">{settings.adminRole}</span>
            </span>
            <ChevronDown className="size-4 shrink-0 text-muted" />
          </button>
          {companyOpen ? (
            <div className="absolute inset-x-3 bottom-full z-40 mb-2 rounded-2xl border border-border bg-surface p-1 shadow-card">
              <MenuItem label="Company settings" onClick={() => go("settings")} />
              <MenuItem label="Payroll reports" onClick={() => go("reports")} />
              <MenuItem label="Reset demo data" onClick={() => { setCompanyOpen(false); setConfirmReset(true); }} />
            </div>
          ) : null}
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="relative z-20 flex h-16 shrink-0 items-center gap-2 border-b border-border bg-surface px-3 sm:px-5">
          <button type="button" className="grid size-11 place-items-center rounded-xl hover:bg-bg lg:hidden" aria-label="Open menu" onClick={() => setOpen(true)}>
            <Menu className="size-5" />
          </button>
          <nav className="no-scrollbar hidden min-w-0 flex-1 items-center gap-1 overflow-x-auto md:flex">
            {TOP.map((item) => {
              const active = view === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => go(item.id)}
                  className={clsx(
                    "h-16 shrink-0 border-b-2 px-3 text-sm",
                    active ? "border-primary font-semibold text-fg" : "border-transparent text-muted hover:text-fg",
                  )}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>
          <div className="ml-auto flex items-center gap-1">
            <div className="relative">
              <button type="button" aria-label="Notifications" onClick={() => setBell((v) => !v)} className="relative grid size-11 place-items-center rounded-full hover:bg-bg">
                <Bell className="size-5" />
                {notes.length > 0 ? <span className="absolute top-2 right-2 size-2 rounded-full bg-danger" /> : null}
              </button>
              {bell ? (
                <>
                  <button type="button" className="fixed inset-0 z-30 cursor-default" aria-label="Close notifications" onClick={() => setBell(false)} />
                  <div className="absolute right-0 z-40 mt-2 w-80 max-w-[calc(100vw-1.5rem)] rounded-2xl border border-border bg-surface p-2 shadow-card">
                    <p className="px-2 py-1 text-sm font-semibold">Notifications</p>
                    {notes.length === 0 ? <p className="px-2 py-4 text-sm text-muted">You're all caught up.</p> : null}
                    {notes.map((note) => (
                      <button key={note.id} type="button" onClick={() => go(note.view)} className="block w-full rounded-xl px-2 py-3 text-left hover:bg-bg">
                        <span className="block text-sm font-semibold">{note.title}</span>
                        <span className="block text-xs text-muted">{note.detail}</span>
                      </button>
                    ))}
                  </div>
                </>
              ) : null}
            </div>
            <div className="relative">
              <button type="button" onClick={() => setAdminOpen((v) => !v)} className="flex h-11 items-center gap-2 rounded-full pr-2 pl-1 hover:bg-bg">
                <Avatar name={settings.adminName} size="sm" />
                <span className="hidden text-left sm:block">
                  <span className="block text-sm font-semibold leading-tight">{settings.adminName}</span>
                  <span className="block text-xs text-muted">{settings.adminRole}</span>
                </span>
                <ChevronDown className="hidden size-4 text-muted sm:block" />
              </button>
              {adminOpen ? (
                <>
                  <button type="button" className="fixed inset-0 z-30 cursor-default" aria-label="Close account menu" onClick={() => setAdminOpen(false)} />
                  <div className="absolute right-0 z-40 mt-2 w-52 rounded-2xl border border-border bg-surface p-1 shadow-card">
                    <MenuItem label="Settings" onClick={() => go("settings")} />
                    <MenuItem label="Documents" onClick={() => go("documents")} />
                    <MenuItem label="Reset demo data" onClick={() => { setAdminOpen(false); setConfirmReset(true); }} />
                  </div>
                </>
              ) : null}
            </div>
          </div>
        </header>
        <div className="min-h-0 flex-1 overflow-y-auto pb-20 lg:pb-0">{children}</div>
        <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-border bg-surface lg:hidden">
          {TOP.map((item) => {
            const active = view === item.id;
            const Icon = item.icon;
            return (
              <button key={item.id} type="button" onClick={() => go(item.id)} className={clsx("flex h-16 flex-col items-center justify-center gap-1 text-xs", active ? "text-primary" : "text-muted")}>
                <Icon className="size-5" />
                <span className="max-w-full truncate px-1">{item.short}</span>
              </button>
            );
          })}
        </nav>
      </div>
      <ConfirmDialog
        open={confirmReset}
        title="Reset demo data?"
        body="This restores the original June 2026 payroll, 148 employees, and sample leave. Your edits on this browser will be replaced."
        confirmLabel="Reset"
        danger
        onClose={() => setConfirmReset(false)}
        onConfirm={() => {
          resetDemo();
          setConfirmReset(false);
          setOpen(false);
        }}
      />
    </div>
  );
}

function MenuItem({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="flex h-11 w-full items-center rounded-xl px-3 text-left text-sm font-medium hover:bg-bg">
      {label}
    </button>
  );
}
