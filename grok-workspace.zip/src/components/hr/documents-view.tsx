import { useState } from "react";
import { toast } from "sonner";
import { DOC_CATEGORIES, employeeMap, prettyDate } from "@/lib/hr/model";
import { useHr } from "@/lib/hr/store";
import { EmptyState, fieldClass, GhostButton, PrimaryButton } from "@/components/hr/widgets";

export function DocumentsView() {
  const documents = useHr((s) => s.documents);
  const employees = useHr((s) => s.employees);
  const addDocument = useHr((s) => s.addDocument);
  const removeDocument = useHr((s) => s.removeDocument);
  const map = employeeMap(employees);
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState<string>(DOC_CATEGORIES[0]);
  const [employeeId, setEmployeeId] = useState("");
  const [note, setNote] = useState("");
  const [date, setDate] = useState("2026-10-08");

  return (
    <div className="flex flex-col gap-5 p-4 sm:p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Documents</h1>
          <p className="text-sm text-muted">Policies, offers, and payroll notes kept with the company file.</p>
        </div>
        <PrimaryButton onClick={() => setOpen(true)}>Add document</PrimaryButton>
      </div>
      {documents.length === 0 ? (
        <section className="rounded-2xl border border-border bg-surface shadow-card">
          <EmptyState title="No documents yet" body="Add a policy or an offer letter so the team can find it later." />
        </section>
      ) : (
        <ul className="grid gap-3 md:grid-cols-2">
          {documents.map((doc) => {
            const person = doc.employeeId ? map.get(doc.employeeId) : undefined;
            return (
              <li key={doc.id} className="flex flex-col rounded-2xl border border-border bg-surface p-4 shadow-card">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold tracking-wide text-primary">{doc.category}</p>
                    <h2 className="font-semibold">{doc.title}</h2>
                  </div>
                  <button
                    type="button"
                    className="h-11 rounded-xl px-3 text-sm text-danger hover:bg-danger-soft"
                    onClick={() => {
                      removeDocument(doc.id);
                      toast.success("Document removed");
                    }}
                  >
                    Remove
                  </button>
                </div>
                <p className="mt-2 flex-1 text-sm text-muted">{doc.note}</p>
                <p className="mt-3 text-xs text-muted">
                  {prettyDate(doc.date)}
                  {person ? ` · ${person.name}` : ""}
                </p>
              </li>
            );
          })}
        </ul>
      )}
      {open ? (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-3 sm:items-center" onMouseDown={() => setOpen(false)}>
          <div role="dialog" aria-label="Add document" className="w-full max-w-lg rounded-2xl bg-surface p-5 shadow-card" onMouseDown={(e) => e.stopPropagation()}>
            <h2 className="text-lg font-semibold">Add document</h2>
            <div className="mt-4 grid gap-3">
              <label className="text-sm">
                <span className="mb-1 block font-medium">Title</span>
                <input className={fieldClass} value={title} onChange={(e) => setTitle(e.target.value)} />
              </label>
              <label className="text-sm">
                <span className="mb-1 block font-medium">Category</span>
                <select className={fieldClass} value={category} onChange={(e) => setCategory(e.target.value)}>
                  {DOC_CATEGORIES.map((item) => (
                    <option key={item}>{item}</option>
                  ))}
                </select>
              </label>
              <label className="text-sm">
                <span className="mb-1 block font-medium">Linked employee</span>
                <select className={fieldClass} value={employeeId} onChange={(e) => setEmployeeId(e.target.value)}>
                  <option value="">Company-wide</option>
                  {employees.map((e) => (
                    <option key={e.id} value={e.id}>{e.name}</option>
                  ))}
                </select>
              </label>
              <label className="text-sm">
                <span className="mb-1 block font-medium">Date</span>
                <input type="date" className={fieldClass} value={date} onChange={(e) => setDate(e.target.value)} />
              </label>
              <label className="text-sm">
                <span className="mb-1 block font-medium">Note</span>
                <textarea className="min-h-24 w-full rounded-xl border border-border px-3 py-2 text-sm outline-none focus:border-primary" value={note} onChange={(e) => setNote(e.target.value)} />
              </label>
            </div>
            <div className="mt-5 flex justify-end gap-2">
              <GhostButton onClick={() => setOpen(false)}>Cancel</GhostButton>
              <PrimaryButton
                onClick={() => {
                  if (title.trim().length < 2) {
                    toast.error("Add a title");
                    return;
                  }
                  addDocument({
                    title: title.trim(),
                    category,
                    note: note.trim() || "No note added.",
                    date,
                    employeeId: employeeId || undefined,
                  });
                  toast.success("Document added");
                  setTitle("");
                  setNote("");
                  setOpen(false);
                }}
              >
                Save
              </PrimaryButton>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
