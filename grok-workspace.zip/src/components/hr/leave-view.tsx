import { useState } from "react";
import { toast } from "sonner";
import { clsx } from "clsx";
import {
  eachWorkingDay,
  employeeMap,
  LEAVE_QUOTA,
  LEAVE_TYPES,
  leaveReserved,
  prettyDate,
  type LeaveStatus,
  type LeaveType,
} from "@/lib/hr/model";
import { useHr } from "@/lib/hr/store";
import { Avatar, EmptyState, fieldClass, GhostButton, Pagination, PrimaryButton, StatusPill } from "@/components/hr/widgets";

export function LeaveView() {
  const employees = useHr((s) => s.employees);
  const leaves = useHr((s) => s.leaves);
  const addLeave = useHr((s) => s.addLeave);
  const decideLeave = useHr((s) => s.decideLeave);
  const withdrawLeave = useHr((s) => s.withdrawLeave);
  const map = employeeMap(employees);
  const [tab, setTab] = useState<LeaveStatus | "all">("pending");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [open, setOpen] = useState(false);
  const [employeeId, setEmployeeId] = useState(employees.find((e) => e.status === "active")?.id ?? "");
  const [type, setType] = useState<LeaveType>("Casual");
  const [from, setFrom] = useState("2026-10-09");
  const [to, setTo] = useState("2026-10-09");
  const [reason, setReason] = useState("");

  const filtered = leaves.filter((l) => tab === "all" || l.status === tab);
  const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const safePage = Math.min(page, pages);
  const rows = filtered.slice((safePage - 1) * pageSize, safePage * pageSize);
  const days = eachWorkingDay(from, to);
  const selected = employees.find((e) => e.id === employeeId);
  const left = selected && type !== "Unpaid" ? LEAVE_QUOTA[type] - leaveReserved(leaves, selected.id, type) : null;

  return (
    <div className="flex flex-col gap-5 p-4 sm:p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Leave</h1>
          <p className="text-sm text-muted">{leaves.filter((l) => l.status === "pending").length} waiting for a decision</p>
        </div>
        <PrimaryButton onClick={() => setOpen(true)}>Apply leave</PrimaryButton>
      </div>
      <div className="flex flex-wrap gap-2">
        {(["pending", "approved", "rejected", "all"] as const).map((key) => (
          <button
            key={key}
            type="button"
            onClick={() => { setTab(key); setPage(1); }}
            className={clsx("h-11 rounded-full px-4 text-sm font-medium capitalize", tab === key ? "bg-primary text-on-primary" : "bg-surface text-fg ring-1 ring-border")}
          >
            {key}
          </button>
        ))}
      </div>
      <section className="overflow-hidden rounded-2xl border border-border bg-surface shadow-card">
        {rows.length === 0 ? (
          <EmptyState title="Nothing in this tab" body="New requests show up under Pending until you approve or reject them." />
        ) : (
          <ul className="divide-y divide-border">
            {rows.map((leave) => {
              const e = map.get(leave.employeeId);
              return (
                <li key={leave.id} className="flex flex-col gap-3 px-4 py-4 lg:flex-row lg:items-center">
                  <div className="flex min-w-0 flex-1 items-center gap-3">
                    <Avatar name={e?.name ?? "?"} female={e?.gender === "f"} />
                    <div className="min-w-0">
                      <p className="truncate font-semibold">{e?.name ?? "Employee"} <span className="font-normal text-muted">{e?.code}</span></p>
                      <p className="text-sm text-muted">
                        {leave.type} · {prettyDate(leave.from)}{leave.from !== leave.to ? ` – ${prettyDate(leave.to)}` : ""} · {leave.days} day{leave.days === 1 ? "" : "s"}
                      </p>
                      <p className="text-sm">{leave.reason}</p>
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {leave.status === "pending" ? <StatusPill tone="warn">Pending</StatusPill> : null}
                    {leave.status === "approved" ? <StatusPill tone="good" check>Approved</StatusPill> : null}
                    {leave.status === "rejected" ? <StatusPill tone="bad">Rejected</StatusPill> : null}
                    {leave.status === "pending" ? (
                      <>
                        <button type="button" className="h-11 rounded-xl bg-primary px-3 text-sm font-semibold text-on-primary" onClick={() => { decideLeave(leave.id, "approved"); toast.success("Leave approved and marked on attendance"); }}>
                          Approve
                        </button>
                        <button type="button" className="h-11 rounded-xl px-3 text-sm font-medium text-danger hover:bg-danger-soft" onClick={() => { decideLeave(leave.id, "rejected"); toast.success("Leave rejected"); }}>
                          Reject
                        </button>
                        <button type="button" className="h-11 rounded-xl px-3 text-sm text-muted hover:bg-bg" onClick={() => { withdrawLeave(leave.id); toast.success("Request withdrawn"); }}>
                          Withdraw
                        </button>
                      </>
                    ) : null}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
        <Pagination page={safePage} pages={pages} pageSize={pageSize} total={filtered.length} noun="requests" onPage={setPage} onPageSize={(size) => { setPageSize(size); setPage(1); }} />
      </section>

      {open ? (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-3 sm:items-center" onMouseDown={() => setOpen(false)}>
          <div role="dialog" aria-label="Apply leave" className="w-full max-w-lg rounded-2xl bg-surface p-5 shadow-card" onMouseDown={(e) => e.stopPropagation()}>
            <h2 className="text-lg font-semibold">Apply leave</h2>
            <div className="mt-4 grid gap-3">
              <label className="text-sm">
                <span className="mb-1 block font-medium">Employee</span>
                <select className={fieldClass} value={employeeId} onChange={(e) => setEmployeeId(e.target.value)}>
                  {employees.filter((e) => e.status === "active").map((e) => (
                    <option key={e.id} value={e.id}>{e.name} · {e.code}</option>
                  ))}
                </select>
              </label>
              <label className="text-sm">
                <span className="mb-1 block font-medium">Type</span>
                <select className={fieldClass} value={type} onChange={(e) => setType(e.target.value as LeaveType)}>
                  {LEAVE_TYPES.map((item) => (
                    <option key={item}>{item}</option>
                  ))}
                </select>
              </label>
              <div className="grid grid-cols-2 gap-3">
                <label className="text-sm">
                  <span className="mb-1 block font-medium">From</span>
                  <input type="date" className={fieldClass} value={from} onChange={(e) => setFrom(e.target.value)} />
                </label>
                <label className="text-sm">
                  <span className="mb-1 block font-medium">To</span>
                  <input type="date" className={fieldClass} value={to} onChange={(e) => setTo(e.target.value)} />
                </label>
              </div>
              <label className="text-sm">
                <span className="mb-1 block font-medium">Reason</span>
                <textarea className="min-h-24 w-full rounded-xl border border-border px-3 py-2 text-sm outline-none focus:border-primary" value={reason} onChange={(e) => setReason(e.target.value)} />
              </label>
              <p className="text-sm text-muted">
                {days.length} working day{days.length === 1 ? "" : "s"}
                {left !== null ? ` · ${Math.max(0, left)} ${type.toLowerCase()} left` : ""}
              </p>
            </div>
            <div className="mt-5 flex justify-end gap-2">
              <GhostButton onClick={() => setOpen(false)}>Cancel</GhostButton>
              <PrimaryButton
                onClick={() => {
                  const result = addLeave({ employeeId, type, from, to, reason });
                  if (!result.ok) {
                    toast.error(result.reason);
                    return;
                  }
                  toast.success("Leave request submitted");
                  setReason("");
                  setOpen(false);
                  setTab("pending");
                }}
              >
                Submit
              </PrimaryButton>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
