import { Toaster } from "sonner";
import { useHr, useHydrateHr } from "@/lib/hr/store";
import { Shell } from "@/components/hr/shell";
import { PayrollView } from "@/components/hr/payroll-view";
import { EmployeesView } from "@/components/hr/employees-view";
import { AttendanceView } from "@/components/hr/attendance-view";
import { LeaveView } from "@/components/hr/leave-view";
import { DashboardView } from "@/components/hr/dashboard-view";
import { ReportsView } from "@/components/hr/reports-view";
import { DocumentsView } from "@/components/hr/documents-view";
import { SettingsView } from "@/components/hr/settings-view";

export function App() {
  useHydrateHr();
  const view = useHr((s) => s.view);
  return (
    <>
      <Shell>
        {view === "dashboard" ? <DashboardView /> : null}
        {view === "employees" ? <EmployeesView /> : null}
        {view === "attendance" ? <AttendanceView /> : null}
        {view === "leave" ? <LeaveView /> : null}
        {view === "payroll" ? <PayrollView /> : null}
        {view === "reports" ? <ReportsView /> : null}
        {view === "documents" ? <DocumentsView /> : null}
        {view === "settings" ? <SettingsView /> : null}
      </Shell>
      <Toaster position="top-center" />
    </>
  );
}
