import { dayKind, inr, linesFor, monthLabel, prettyDate, TODAY, type ViewId } from "@/lib/hr/model";
import { useHr } from "@/lib/hr/store";
import { TrendChart } from "@/components/hr/charts";
import { StatusPill } from "@/components/hr/widgets";

export function DashboardView() {
  const data = useHr();
  const { employees, marks, leaves, settings, period, setView, setPeriod, decideLeave } = data;
  const active = employees.filter((e) => e.status === "active");
  const todayPeople = active.filter((e) => e.joinDate <= TODAY);
  const present = todayPeople.filter((e) => dayKind(e, TODAY, marks) === "present").length;
  const away = todayPeople.filter((e) => {
    const kind = dayKind(e, TODAY, marks);
    return kind === "absent" || kind === "unpaid" || kind === "leave" || kind === "half";
  }).length;
  const pending = leaves.filter((l) => l.status === "pending");
  const { lines, locked } = linesFor(data, period);
  const net = lines.reduce((s, l) => s + l.net, 0);
  const trend = Object.keys(data.snapshots)
    .sort()
    .map((month) => ({ label: monthLabel(month).slice(0, 3), total: data.snapshots[month]?.reduce((s, l) => s + l.net, 0) ?? 0 }));
  const deptNet = new Map<string, number>();
  const map = new Map(employees.map((e) => [e.id, e]));
  for (const line of lines) {
    const dept = map.get(line.employeeId)?.department ?? "Other";
    deptNet.set(dept, (deptNet.get(dept) ?? 0) + line.net);
  }
  const bars = [...deptNet.entries()].sort((a, b) => b[1] - a[1]);
  const max = Math.max(...bars.map((b) => b[1]), 1);
  const recent = [...employees].sort((a, b) => b.joinDate.localeCompare(a.joinDate)).slice(0, 5);

  return (
    <div className="flex flex-col gap-5 p-4 sm:p-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{settings.company}</h1>
          <p className="text-sm text-muted">Overview for {prettyDate(TODAY)}</p>
        </div>
        <button type="button" onClick={() => setView("payroll")} className="h-11 rounded-xl bg-primary px-4 text-sm font-semibold text-on-primary">
          Open payroll
        </button>
      </div>
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Tile label="Active employees" value={String(active.length)} hint={`${employees.length - active.length} inactive`} />
        <Tile label="Present today" value={String(present)} hint={`${away} away or half day`} />
        <Tile label="Leave waiting" value={String(pending.length)} hint="Needs a decision" />
        <Tile label={monthLabel(period)} value={inr(net)} hint={locked ? "Payroll completed" : "Draft projection"} />
      </div>
      <div className="grid gap-3 xl:grid-cols-5">
        <section className="rounded-2xl border border-border bg-surface p-4 shadow-card xl:col-span-3">
          <h2 className="font-semibold">Payroll trend</h2>
          <p className="mb-2 text-sm text-muted">Completed months, net pay</p>
          <TrendChart data={trend} />
        </section>
        <section className="rounded-2xl border border-border bg-surface p-4 shadow-card xl:col-span-2">
          <h2 className="font-semibold">Cost by department</h2>
          <p className="mb-3 text-sm text-muted">{monthLabel(period)}</p>
          <ul className="flex flex-col gap-3">
            {bars.map(([name, value]) => (
              <li key={name}>
                <div className="mb-1 flex justify-between text-sm">
                  <span>{name}</span>
                  <span className="font-medium">{inr(value)}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-bg">
                  <div className="h-full rounded-full bg-primary" style={{ width: `${Math.max(4, (value / max) * 100)}%` }} />
                </div>
              </li>
            ))}
          </ul>
        </section>
      </div>
      <div className="grid gap-3 lg:grid-cols-2">
        <section className="rounded-2xl border border-border bg-surface p-4 shadow-card">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-semibold">Pending leave</h2>
            <button type="button" className="text-sm font-medium text-primary" onClick={() => setView("leave")}>View all</button>
          </div>
          {pending.length === 0 ? <p className="text-sm text-muted">No requests waiting.</p> : null}
          <ul className="flex flex-col gap-3">
            {pending.slice(0, 4).map((leave) => {
              const e = map.get(leave.employeeId);
              return (
                <li key={leave.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-bg px-3 py-2">
                  <div>
                    <p className="text-sm font-semibold">{e?.name}</p>
                    <p className="text-xs text-muted">{leave.type} · {leave.days} day{leave.days === 1 ? "" : "s"} · {leave.reason}</p>
                  </div>
                  <button
                    type="button"
                    className="h-10 rounded-xl bg-primary px-3 text-sm font-semibold text-on-primary"
                    onClick={() => decideLeave(leave.id, "approved")}
                  >
                    Approve
                  </button>
                </li>
              );
            })}
          </ul>
        </section>
        <section className="rounded-2xl border border-border bg-surface p-4 shadow-card">
          <h2 className="mb-3 font-semibold">Recently joined</h2>
          <ul className="flex flex-col gap-3">
            {recent.map((e) => (
              <li key={e.id} className="flex items-center justify-between gap-3 text-sm">
                <div>
                  <p className="font-semibold">{e.name}</p>
                  <p className="text-xs text-muted">{e.department} · {prettyDate(e.joinDate)}</p>
                </div>
                {e.status === "active" ? <StatusPill tone="good">Active</StatusPill> : <StatusPill tone="neutral">Inactive</StatusPill>}
              </li>
            ))}
          </ul>
          <div className="mt-4 flex flex-wrap gap-2">
            {([
              ["employees", "Employees"],
              ["attendance", "Attendance"],
              ["reports", "Reports"],
            ] as const).map(([id, label]) => (
              <button key={id} type="button" onClick={() => setView(id as ViewId)} className="h-11 rounded-xl border border-border px-3 text-sm font-medium hover:bg-bg">
                {label}
              </button>
            ))}
            <button type="button" onClick={() => setPeriod(TODAY.slice(0, 7))} className="h-11 rounded-xl border border-border px-3 text-sm font-medium hover:bg-bg">
              Jump to October
            </button>
          </div>
        </section>
      </div>
    </div>
  );
}

function Tile({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="rounded-2xl border border-border bg-surface p-4 shadow-card">
      <p className="text-sm text-muted">{label}</p>
      <p className="truncate text-2xl font-semibold tracking-tight">{value}</p>
      <p className="text-xs text-muted">{hint}</p>
    </div>
  );
}
