import { useMemo, useState } from "react";
import { employeeMap, inr, linesFor, monthLabel, payrollCsv, sumLines } from "@/lib/hr/model";
import { useHr } from "@/lib/hr/store";
import { DeptChart, TrendChart } from "@/components/hr/charts";
import { downloadText, GhostButton, MonthPicker } from "@/components/hr/widgets";

export function ReportsView() {
  const data = useHr();
  const { lines, locked } = linesFor(data, data.period);
  const map = useMemo(() => employeeMap(data.employees), [data.employees]);
  const [dept, setDept] = useState("all");
  const departments = useMemo(() => Array.from(new Set(data.employees.map((e) => e.department))).sort(), [data.employees]);
  const scoped = dept === "all" ? lines : lines.filter((l) => map.get(l.employeeId)?.department === dept);
  const totals = sumLines(scoped);
  const byDept = departments.map((name) => {
    const group = lines.filter((l) => map.get(l.employeeId)?.department === name);
    const sum = sumLines(group);
    return { name, ...sum };
  }).filter((d) => d.count > 0);
  const trend = Object.keys(data.snapshots)
    .sort()
    .map((month) => ({ label: monthLabel(month).slice(0, 3), total: data.snapshots[month]?.reduce((s, l) => s + l.net, 0) ?? 0 }));
  const lop = scoped.reduce((s, l) => s + l.lop, 0);
  const bonus = scoped.reduce((s, l) => s + l.bonus, 0);
  const extra = scoped.reduce((s, l) => s + l.extra, 0);
  const statutory = totals.deductions - lop - extra;

  return (
    <div className="flex flex-col gap-5 p-4 sm:p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Reports</h1>
          <p className="text-sm text-muted">
            {monthLabel(data.period)} · {locked ? "Completed run" : "Draft projection"}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <MonthPicker value={data.period} onChange={data.setPeriod} />
          <GhostButton onClick={() => downloadText(`payroll-${data.period}.csv`, payrollCsv(scoped, data.employees, data.period))}>
            Export CSV
          </GhostButton>
        </div>
      </div>
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Mini label="Net payroll" value={inr(totals.net)} />
        <Mini label="Gross + bonus" value={inr(totals.gross)} />
        <Mini label="Statutory" value={inr(statutory)} />
        <Mini label="Loss of pay" value={inr(lop)} />
      </div>
      <section className="rounded-2xl border border-border bg-surface p-4 shadow-card">
        <h2 className="mb-2 font-semibold">Department cost</h2>
        <DeptChart data={byDept.map((d) => ({ name: d.name, net: d.net }))} />
      </section>
      <section className="sheet overflow-hidden rounded-2xl border border-border bg-surface shadow-card">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border p-4">
          <h2 className="font-semibold">Breakdown</h2>
          <select className="h-11 rounded-xl border border-border bg-surface px-3 text-sm" value={dept} onChange={(e) => setDept(e.target.value)}>
            <option value="all">All departments</option>
            {departments.map((name) => (
              <option key={name}>{name}</option>
            ))}
          </select>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-3xl text-left text-sm">
            <thead className="text-muted">
              <tr className="border-b border-border">
                <th className="px-4 py-3 font-medium">Department</th>
                <th className="px-4 py-3 font-medium">People</th>
                <th className="px-4 py-3 font-medium">Gross</th>
                <th className="px-4 py-3 font-medium">Deductions</th>
                <th className="px-4 py-3 font-medium">Net</th>
              </tr>
            </thead>
            <tbody>
              {(dept === "all" ? byDept : byDept.filter((d) => d.name === dept)).map((row) => (
                <tr key={row.name} className="border-b border-border last:border-0">
                  <td className="px-4 py-3 font-medium">{row.name}</td>
                  <td className="px-4 py-3">{row.count}</td>
                  <td className="px-4 py-3">{inr(row.gross)}</td>
                  <td className="px-4 py-3">{inr(row.deductions)}</td>
                  <td className="px-4 py-3 font-semibold">{inr(row.net)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="px-4 py-3 text-sm text-muted">
          Bonus {inr(bonus)} · extra deductions {inr(extra)} · loss of pay {inr(lop)}. Completed months stay frozen.
        </p>
      </section>
      <section className="rounded-2xl border border-border bg-surface p-4 shadow-card">
        <h2 className="mb-2 font-semibold">Completed months</h2>
        <TrendChart data={trend} />
      </section>
    </div>
  );
}

function Mini({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-border bg-surface p-4 shadow-card">
      <p className="text-sm text-muted">{label}</p>
      <p className="truncate text-xl font-semibold">{value}</p>
    </div>
  );
}
