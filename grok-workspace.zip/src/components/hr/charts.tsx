import { Area, AreaChart, Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { inr } from "@/lib/hr/model";
import { useMounted } from "@/components/hr/widgets";

export function Sparkline({ data }: { data: { label: string; total: number }[] }) {
  const on = useMounted();
  if (!on) return <div className="h-16 w-full" />;
  return (
    <div className="h-16 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 8, right: 0, left: 0, bottom: 0 }}>
          <Area type="monotone" dataKey="total" stroke="var(--color-primary)" fill="var(--color-primary-soft)" strokeWidth={2} dot={false} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

export function TrendChart({ data }: { data: { label: string; total: number }[] }) {
  const on = useMounted();
  if (!on) return <div className="h-64 w-full rounded-xl bg-bg" />;
  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
          <CartesianGrid stroke="var(--color-border)" vertical={false} />
          <XAxis dataKey="label" tick={{ fill: "var(--color-muted)", fontSize: 12 }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fill: "var(--color-muted)", fontSize: 12 }} axisLine={false} tickLine={false} width={72} tickFormatter={(v: number) => inr(v).replace("₹ ", "₹")} />
          <Tooltip formatter={(value) => inr(Number(value ?? 0))} />
          <Area type="monotone" dataKey="total" name="Net payroll" stroke="var(--color-primary)" fill="var(--color-primary-soft)" strokeWidth={2} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

export function DeptChart({ data }: { data: { name: string; net: number }[] }) {
  const on = useMounted();
  if (!on) return <div className="h-72 w-full rounded-xl bg-bg" />;
  return (
    <div className="h-72 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
          <CartesianGrid stroke="var(--color-border)" vertical={false} />
          <XAxis dataKey="name" tick={{ fill: "var(--color-muted)", fontSize: 11 }} axisLine={false} tickLine={false} interval={0} angle={-25} height={56} textAnchor="end" />
          <YAxis tick={{ fill: "var(--color-muted)", fontSize: 12 }} axisLine={false} tickLine={false} width={72} tickFormatter={(v: number) => inr(v).replace("₹ ", "₹")} />
          <Tooltip formatter={(value) => inr(Number(value ?? 0))} />
          <Bar dataKey="net" name="Net pay" fill="var(--color-primary)" radius={[6, 6, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
