import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  dayKind,
  isHoliday,
  isWeekoff,
  monthDates,
  monthLabel,
  prettyDate,
  weekdayShort,
  type DayKind,
  type MarkStatus,
} from "@/lib/hr/model";
import { useHr } from "@/lib/hr/store";
import { Avatar, fieldClass, GhostButton, MonthPicker } from "@/components/hr/widgets";
import { clsx } from "clsx";

const OPTIONS: { value: MarkStatus | "present"; label: string }[] = [
  { value: "present", label: "Present" },
  { value: "absent", label: "Absent" },
  { value: "half", label: "Half day" },
  { value: "leave", label: "Paid leave" },
  { value: "unpaid", label: "Unpaid leave" },
];

export function AttendanceView() {
  const employees = useHr((s) => s.employees);
  const marks = useHr((s) => s.marks);
  const period = useHr((s) => s.period);
  const setPeriod = useHr((s) => s.setPeriod);
  const setMark = useHr((s) => s.setMark);
  const clearDay = useHr((s) => s.clearDay);
  const dates = useMemo(() => monthDates(period), [period]);
  const [day, setDay] = useState(() => dates.find((d) => !isWeekoff(d) && !isHoliday(d)) ?? dates[0] ?? period + "-01");
  const [query, setQuery] = useState("");
  const [onlyExceptions, setOnlyExceptions] = useState(false);
  const [showInactive, setShowInactive] = useState(false);

  useEffect(() => {
    const next = monthDates(period);
    const preferred = next.includes("2026-10-08") && period === "2026-10" ? "2026-10-08" : (next.find((d) => !isWeekoff(d) && !isHoliday(d)) ?? next[0]);
    if (preferred) setDay(preferred);
  }, [period]);

  const holiday = isHoliday(day);
  const weekend = isWeekoff(day);
  const lockedDay = holiday || weekend;
  const visible = employees.filter((e) => {
    if (!showInactive && e.status !== "active") return false;
    if (e.joinDate > day) return false;
    const hay = `${e.name} ${e.code} ${e.department}`.toLowerCase();
    if (!hay.includes(query.trim().toLowerCase())) return false;
    if (!onlyExceptions) return true;
    const kind = dayKind(e, day, marks);
    return kind === "absent" || kind === "half" || kind === "leave" || kind === "unpaid";
  });

  const active = employees.filter((e) => e.status === "active" && e.joinDate <= day);
  const counts = countKinds(active.map((e) => dayKind(e, day, marks)));

  return (
    <div className="flex flex-col gap-5 p-4 sm:p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Attendance</h1>
          <p className="text-sm text-muted">{prettyDate(day)} · {monthLabel(period)}</p>
        </div>
        <MonthPicker value={period} onChange={setPeriod} />
      </div>

      <div className="sheet">
        <div className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
        {dates.map((date) => {
          const off = isWeekoff(date) || isHoliday(date);
          const selected = date === day;
          return (
            <button
              key={date}
              type="button"
              onClick={() => setDay(date)}
              className={clsx(
                "flex h-16 w-14 shrink-0 flex-col items-center justify-center rounded-xl border text-xs",
                selected ? "border-primary bg-primary text-on-primary" : off ? "border-transparent bg-surface text-muted" : "border-border bg-surface",
              )}
            >
              <span>{weekdayShort(date)}</span>
              <span className="text-sm font-semibold">{Number(date.slice(8))}</span>
            </button>
          );
        })}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        <Chip label="Present" value={counts.present} />
        <Chip label="Absent / unpaid" value={counts.absent + counts.unpaid} />
        <Chip label="Half day" value={counts.half} />
        <Chip label="Paid leave" value={counts.leave} />
      </div>

      {holiday ? <p className="rounded-2xl bg-primary-soft px-4 py-3 text-sm text-primary-dark">National holiday — paid day off. Attendance is not required.</p> : null}
      {weekend ? <p className="rounded-2xl bg-bg px-4 py-3 text-sm text-muted">Weekend. Loss of pay is not counted.</p> : null}

      <section className="sheet overflow-hidden rounded-2xl border border-border bg-surface shadow-card">
        <div className="flex flex-col gap-3 border-b border-border p-4 lg:flex-row lg:items-center">
          <input className={clsx(fieldClass, "lg:max-w-xs")} placeholder="Search employee" value={query} onChange={(e) => setQuery(e.target.value)} />
          <label className="flex h-11 items-center gap-2 text-sm">
            <input type="checkbox" checked={onlyExceptions} onChange={(e) => setOnlyExceptions(e.target.checked)} />
            Exceptions only
          </label>
          <label className="flex h-11 items-center gap-2 text-sm">
            <input type="checkbox" checked={showInactive} onChange={(e) => setShowInactive(e.target.checked)} />
            Show inactive
          </label>
          <div className="lg:ml-auto">
            <GhostButton
              onClick={() => {
                if (lockedDay) return;
                clearDay(day);
                toast.success("Everyone marked present");
              }}
            >
              Mark everyone present
            </GhostButton>
          </div>
        </div>
        <ul className="divide-y divide-border">
          {visible.slice(0, 80).map((e) => {
            const kind = dayKind(e, day, marks);
            const editable = !lockedDay && e.status === "active";
            return (
              <li key={e.id} className="flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-center">
                <div className="flex min-w-0 flex-1 items-center gap-3">
                  <Avatar name={e.name} female={e.gender === "f"} />
                  <div className="min-w-0">
                    <p className="truncate font-semibold">{e.name}</p>
                    <p className="text-xs text-muted">{e.code} · {e.department}</p>
                  </div>
                </div>
                {editable ? (
                  <select
                    className={clsx(fieldClass, "sm:max-w-48", kind !== "present" && "border-primary text-primary-dark")}
                    value={kind === "weekoff" || kind === "holiday" ? "present" : kind}
                    onChange={(e2) => setMark(e.id, day, e2.target.value as MarkStatus | "present")}
                  >
                    {OPTIONS.map((opt) => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                ) : (
                  <span className="text-sm text-muted">{labelFor(kind, e.status)}</span>
                )}
              </li>
            );
          })}
          {visible.length === 0 ? <li className="px-4 py-10 text-center text-sm text-muted">No employees match.</li> : null}
          {visible.length > 80 ? <li className="px-4 py-3 text-sm text-muted">Showing 80 of {visible.length}. Search to narrow the list.</li> : null}
        </ul>
      </section>
    </div>
  );
}

function countKinds(kinds: DayKind[]) {
  return kinds.reduce(
    (a, k) => ({ ...a, [k]: (a[k] ?? 0) + 1 }),
    { present: 0, absent: 0, half: 0, leave: 0, unpaid: 0, weekoff: 0, holiday: 0 } as Record<DayKind, number>,
  );
}

function labelFor(kind: DayKind, status: string) {
  if (status !== "active") return "Inactive";
  if (kind === "holiday") return "Holiday";
  if (kind === "weekoff") return "Week off";
  return kind;
}

function Chip({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-2xl border border-border bg-surface px-4 py-3 shadow-card">
      <p className="text-xs text-muted">{label}</p>
      <p className="text-xl font-semibold">{value}</p>
    </div>
  );
}
