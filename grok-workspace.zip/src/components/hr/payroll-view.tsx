import { useMemo, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { Check, IndianRupee, Receipt, TrendingUp, Users } from "lucide-react";
import { clsx } from "clsx";
import {
  employeeMap,
  inr,
  linesFor,
  monthLabel,
  payrollCsv,
  shortMonth,
  sumLines,
  type Employee,
  type PayLine,
} from "@/lib/hr/model";
import { useHr } from "@/lib/hr/store";
import { Sparkline } from "@/components/hr/charts";
import { Avatar, ConfirmDialog, downloadText, EmptyState, fieldClass, GhostButton, MonthPicker, Pagination, PrimaryButton, StatusPill } from "@/components/hr/widgets";

type SortKey = "code" | "name" | "department" | "gross" | "deductions" | "net";

export function PayrollView() {
  const data = useHr();
  const { period, employees, setPeriod, setView, completePayroll, reopenPayroll, setAdjustment } = data;
  const map = useMemo(() => employeeMap(employees), [employees]);
  const { lines, locked } = linesFor(data, period);
  const [dept, setDept] = useState("all");
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [sortKey, setSortKey] = useState<SortKey>("code");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("asc");
  const [slip, setSlip] = useState<PayLine | null>(null);
  const [confirm, setConfirm] = useState<"complete" | "reopen" | null>(null);

  const departments = useMemo(() => Array.from(new Set(employees.map((e) => e.department))).sort(), [employees]);
  const deptLines = dept === "all" ? lines : lines.filter((l) => map.get(l.employeeId)?.department === dept);
  const totals = sumLines(deptLines);
  const filtered = deptLines.filter((l) => {
    const e = map.get(l.employeeId);
    if (!e) return false;
    const hay = `${e.name} ${e.code} ${e.department}`.toLowerCase();
    return hay.includes(query.trim().toLowerCase());
  });
  const sorted = [...filtered].sort((a, b) => {
    const ea = map.get(a.employeeId);
    const eb = map.get(b.employeeId);
    const dir = sortDir === "asc" ? 1 : -1;
    const av = sortValue(sortKey, a, ea);
    const bv = sortValue(sortKey, b, eb);
    if (typeof av === "number" && typeof bv === "number") return (av - bv) * dir;
    return String(av).localeCompare(String(bv)) * dir;
  });
  const pages = Math.max(1, Math.ceil(sorted.length / pageSize));
  const safePage = Math.min(page, pages);
  const rows = sorted.slice((safePage - 1) * pageSize, safePage * pageSize);
  const trend = useMemo(
    () =>
      Object.keys(data.snapshots)
        .sort()
        .map((month) => ({
          label: shortMonth(month),
          total: data.snapshots[month]?.reduce((s, l) => s + l.net, 0) ?? 0,
        })),
    [data.snapshots],
  );

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setSortKey(key);
      setSortDir(key === "name" || key === "department" || key === "code" ? "asc" : "desc");
    }
    setPage(1);
  };

  return (
    <div className="flex flex-col gap-5 p-4 sm:p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-bold tracking-tight">Payroll</h1>
        <div className="flex flex-wrap items-center gap-2">
          <MonthPicker
            value={period}
            onChange={(next) => {
              setPeriod(next);
              setPage(1);
              setSlip(null);
            }}
          />
          {locked ? (
            <span className="inline-flex h-11 items-center gap-2 rounded-full bg-primary px-4 text-sm font-bold tracking-wide text-on-primary">
              PAYROLL COMPLETED
              <span className="grid size-5 place-items-center rounded-full bg-on-primary text-primary">
                <Check className="size-3.5" />
              </span>
            </span>
          ) : (
            <button
              type="button"
              onClick={() => setConfirm("complete")}
              className="inline-flex h-11 items-center gap-2 rounded-full bg-primary px-4 text-sm font-bold tracking-wide text-on-primary hover:bg-primary-dark"
            >
              COMPLETE PAYROLL
            </button>
          )}
          {locked ? (
            <button type="button" onClick={() => setConfirm("reopen")} className="h-11 rounded-xl px-3 text-sm font-medium text-muted hover:bg-surface hover:text-fg">
              Reopen
            </button>
          ) : null}
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Stat icon={<Users className="size-5" />} label="Employees" value={String(totals.count)} hint={dept === "all" ? "Total Active" : dept} />
        <Stat
          icon={<Check className="size-5" />}
          label="Processed"
          value={locked ? `${totals.count} / ${totals.count}` : `0 / ${totals.count}`}
          hint={locked ? "100% Completed" : "Not completed"}
        />
        <Stat icon={<IndianRupee className="size-5" />} label="Total Payroll" value={inr(totals.net)} hint={dept === "all" ? "All Departments" : dept} />
        <div className="rounded-2xl border border-border bg-surface p-4 shadow-card">
          <div className="mb-1 flex items-center justify-between">
            <p className="text-sm text-muted">Auto-Calculated</p>
            <TrendingUp className="size-4 text-primary" />
          </div>
          <Sparkline data={trend.length ? trend : [{ label: period.slice(5), total: totals.net }]} />
        </div>
      </div>

      <section className="sheet overflow-hidden rounded-2xl border border-border bg-surface shadow-card">
        <div className="flex flex-col gap-3 border-b border-border p-4 sm:flex-row sm:items-center">
          <input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setPage(1);
            }}
            placeholder="Search name or code"
            className={clsx(fieldClass, "sm:max-w-xs")}
          />
          <select
            value={dept}
            onChange={(e) => {
              setDept(e.target.value);
              setPage(1);
            }}
            className={clsx(fieldClass, "sm:max-w-xs")}
          >
            <option value="all">All departments</option>
            {departments.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
          <div className="sm:ml-auto">
            <GhostButton
              onClick={() => downloadText(`payroll-${period}.csv`, payrollCsv(deptLines, employees, period))}
            >
              Export CSV
            </GhostButton>
          </div>
        </div>
        {rows.length === 0 ? (
          <EmptyState title="No employees in this view" body="Try another department, or add an active employee who joined before this month ends." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-3xl text-left text-sm">
              <thead className="text-muted">
                <tr className="border-b border-border">
                  <Th label="Employee" k="name" sortKey={sortKey} sortDir={sortDir} onSort={toggleSort} />
                  <Th label="Department" k="department" sortKey={sortKey} sortDir={sortDir} onSort={toggleSort} />
                  <Th label="Gross Salary" k="gross" sortKey={sortKey} sortDir={sortDir} onSort={toggleSort} />
                  <Th label="Deductions" k="deductions" sortKey={sortKey} sortDir={sortDir} onSort={toggleSort} />
                  <Th label="Net Salary" k="net" sortKey={sortKey} sortDir={sortDir} onSort={toggleSort} />
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 font-medium">
                    <span className="sr-only">Payslip</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {rows.map((line) => {
                  const e = map.get(line.employeeId);
                  return (
                    <tr key={line.employeeId} className="border-b border-border last:border-0 hover:bg-bg">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <Avatar name={e?.name ?? "?"} female={e?.gender === "f"} />
                          <div>
                            <p className="font-semibold">{e?.name ?? "Former employee"}</p>
                            <p className="text-xs text-muted">{e?.code ?? line.employeeId}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">{e?.department ?? "—"}</td>
                      <td className="px-4 py-3 font-medium">{inr(line.gross + line.bonus)}</td>
                      <td className="px-4 py-3">{inr(line.deductions)}</td>
                      <td className="px-4 py-3 font-semibold">{inr(line.net)}</td>
                      <td className="px-4 py-3">
                        {locked ? <StatusPill tone="good" check>Processed</StatusPill> : <StatusPill tone="warn">Draft</StatusPill>}
                      </td>
                      <td className="px-4 py-3">
                        <button type="button" aria-label={`Payslip for ${e?.name ?? "employee"}`} onClick={() => setSlip(line)} className="grid size-11 place-items-center rounded-xl text-muted hover:bg-primary-soft hover:text-primary">
                          <Receipt className="size-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
        <Pagination
          page={safePage}
          pages={pages}
          pageSize={pageSize}
          total={sorted.length}
          noun="employees"
          onPage={setPage}
          onPageSize={(size) => {
            setPageSize(size);
            setPage(1);
          }}
        />
      </section>

      {slip ? (
        <Payslip
          line={slip}
          employee={map.get(slip.employeeId)}
          month={period}
          locked={locked}
          company={data.settings.company}
          onClose={() => setSlip(null)}
          onSave={(bonus, extra) => {
            setAdjustment(period, slip.employeeId, { bonus, extra });
            toast.success("Adjustment saved");
            setSlip(null);
          }}
          onAttendance={() => {
            setSlip(null);
            setView("attendance");
          }}
        />
      ) : null}

      <ConfirmDialog
        open={confirm === "complete"}
        title={`Complete ${monthLabel(period)}?`}
        body="Salaries lock for this month. Later attendance or salary edits will not change this run unless you reopen it."
        confirmLabel="Complete payroll"
        onClose={() => setConfirm(null)}
        onConfirm={() => {
          const result = completePayroll(period);
          setConfirm(null);
          if (!result.ok) toast.error(result.reason);
          else toast.success(`${monthLabel(period)} payroll completed`);
        }}
      />
      <ConfirmDialog
        open={confirm === "reopen"}
        title={`Reopen ${monthLabel(period)}?`}
        body="Locked amounts are discarded. The month is recalculated from current salaries, bonuses, and attendance — including loss of pay."
        confirmLabel="Reopen"
        danger
        onClose={() => setConfirm(null)}
        onConfirm={() => {
          reopenPayroll(period);
          setConfirm(null);
          toast.success(`${monthLabel(period)} is a draft again`);
        }}
      />
    </div>
  );
}

function sortValue(key: SortKey, line: PayLine, employee?: Employee) {
  if (key === "gross") return line.gross + line.bonus;
  if (key === "deductions") return line.deductions;
  if (key === "net") return line.net;
  if (key === "name") return employee?.name ?? "";
  if (key === "department") return employee?.department ?? "";
  return employee?.code ?? line.employeeId;
}

function Th({
  label,
  k,
  sortKey,
  sortDir,
  onSort,
}: {
  label: string;
  k: SortKey;
  sortKey: SortKey;
  sortDir: "asc" | "desc";
  onSort: (key: SortKey) => void;
}) {
  const active = sortKey === k;
  return (
    <th className="px-4 py-3 font-medium">
      <button type="button" onClick={() => onSort(k)} className="inline-flex items-center gap-1">
        {label}
        <span className="text-xs">{active ? (sortDir === "asc" ? "↑" : "↓") : ""}</span>
      </button>
    </th>
  );
}

function Stat({ icon, label, value, hint }: { icon: ReactNode; label: string; value: string; hint: string }) {
  return (
    <div className="flex items-center gap-4 rounded-2xl border border-border bg-surface p-4 shadow-card">
      <span className="grid size-12 shrink-0 place-items-center rounded-full bg-primary-soft text-primary">{icon}</span>
      <div className="min-w-0">
        <p className="text-sm text-muted">{label}</p>
        <p className="truncate text-2xl font-semibold tracking-tight">{value}</p>
        <p className="text-xs text-muted">{hint}</p>
      </div>
    </div>
  );
}

function Payslip({
  line,
  employee,
  month,
  locked,
  company,
  onClose,
  onSave,
  onAttendance,
}: {
  line: PayLine;
  employee?: Employee;
  month: string;
  locked: boolean;
  company: string;
  onClose: () => void;
  onSave: (bonus: number, extra: number) => void;
  onAttendance: () => void;
}) {
  const [bonus, setBonus] = useState(String(line.bonus || ""));
  const [extra, setExtra] = useState(String(line.extra || ""));
  const bonusN = Math.max(0, Math.round(Number(bonus) || 0));
  const extraN = Math.max(0, Math.round(Number(extra) || 0));
  const statutory = line.deductions - line.lop - line.extra;
  const previewNet = line.gross + (locked ? line.bonus : bonusN) - (statutory + line.lop + (locked ? line.extra : extraN));

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-3 sm:items-center" onMouseDown={onClose}>
      <div role="dialog" aria-label="Payslip" className="max-h-[92dvh] w-full max-w-lg overflow-y-auto rounded-2xl bg-surface p-5 shadow-card" onMouseDown={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-xs font-semibold tracking-wide text-primary">{company}</p>
            <h2 className="text-lg font-semibold">Payslip · {monthLabel(month)}</h2>
          </div>
          {locked ? <StatusPill tone="good" check>Processed</StatusPill> : <StatusPill tone="warn">Draft</StatusPill>}
        </div>
        <div className="mt-4 flex items-center gap-3">
          <Avatar name={employee?.name ?? "?"} female={employee?.gender === "f"} />
          <div>
            <p className="font-semibold">{employee?.name ?? "Former employee"}</p>
            <p className="text-sm text-muted">
              {employee?.code} · {employee?.department} · {employee?.designation}
            </p>
          </div>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
          <Row label="Gross earnings" value={inr(line.gross)} />
          <Row label="Bonus" value={inr(locked ? line.bonus : bonusN)} />
          <Row label="PF, tax & other" value={inr(statutory)} />
          <Row label="Loss of pay" value={inr(line.lop)} />
          <Row label="Extra deduction" value={inr(locked ? line.extra : extraN)} />
          <Row label="Net pay" value={inr(previewNet)} strong />
        </div>
        {!locked ? (
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <label className="text-sm">
              <span className="mb-1 block font-medium">Bonus</span>
              <input className={fieldClass} inputMode="numeric" value={bonus} onChange={(e) => setBonus(e.target.value)} />
            </label>
            <label className="text-sm">
              <span className="mb-1 block font-medium">Extra deduction</span>
              <input className={fieldClass} inputMode="numeric" value={extra} onChange={(e) => setExtra(e.target.value)} />
            </label>
          </div>
        ) : (
          <p className="mt-4 text-sm text-muted">This month is locked. Reopen payroll to change bonus or deductions.</p>
        )}
        <div className="mt-5 flex flex-wrap justify-end gap-2">
          <GhostButton onClick={onAttendance}>Attendance</GhostButton>
          <GhostButton
            onClick={() => {
              const html = payslipHtml({ company, month: monthLabel(month), employee, line, net: previewNet, statutory, bonus: locked ? line.bonus : bonusN, extra: locked ? line.extra : extraN });
              const w = window.open("", "_blank", "noopener,noreferrer");
              if (!w) {
                toast.error("Allow pop-ups to print the payslip");
                return;
              }
              w.document.write(html);
              w.document.close();
              w.focus();
              w.print();
            }}
          >
            Print
          </GhostButton>
          {locked ? (
            <PrimaryButton onClick={onClose}>Close</PrimaryButton>
          ) : (
            <PrimaryButton onClick={() => onSave(bonusN, extraN)}>Save adjustment</PrimaryButton>
          )}
        </div>
      </div>
    </div>
  );
}

function Row({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className="rounded-xl bg-bg px-3 py-2">
      <p className="text-xs text-muted">{label}</p>
      <p className={strong ? "font-semibold" : "font-medium"}>{value}</p>
    </div>
  );
}

function payslipHtml({
  company,
  month,
  employee,
  line,
  net,
  statutory,
  bonus,
  extra,
}: {
  company: string;
  month: string;
  employee?: Employee;
  line: PayLine;
  net: number;
  statutory: number;
  bonus: number;
  extra: number;
}) {
  const row = (label: string, value: string) => `<tr><td style="padding:8px 0;color:#6b7682">${label}</td><td style="padding:8px 0;text-align:right;font-weight:600">${value}</td></tr>`;
  return `<!doctype html><html><head><title>Payslip ${employee?.code ?? ""}</title></head><body style="font-family:sans-serif;color:#1b2430;padding:32px">
  <p style="color:#1c9a48;font-weight:700;margin:0">${company}</p>
  <h1 style="margin:4px 0 16px">Payslip · ${month}</h1>
  <p style="margin:0"><strong>${employee?.name ?? ""}</strong> · ${employee?.code ?? ""} · ${employee?.department ?? ""}</p>
  <p style="margin:4px 0 16px;color:#6b7682">${employee?.designation ?? ""}</p>
  <table style="width:100%;border-collapse:collapse">${row("Gross", inr(line.gross))}${row("Bonus", inr(bonus))}${row("PF, tax & other", inr(statutory))}${row("Loss of pay", inr(line.lop))}${row("Extra deduction", inr(extra))}${row("Net pay", inr(net))}</table>
  </body></html>`;
}
