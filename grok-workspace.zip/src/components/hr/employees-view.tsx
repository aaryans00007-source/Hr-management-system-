import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Plus } from "lucide-react";
import { clsx } from "clsx";
import {
  DEPARTMENTS,
  employeesCsv,
  grossOf,
  inr,
  leaveReserved,
  LEAVE_QUOTA,
  LEAVE_TYPES,
  monthDates,
  ROLES,
  statutoryOf,
  dayKind,
  type Employee,
  type EmpStatus,
  type Gender,
} from "@/lib/hr/model";
import { useHr } from "@/lib/hr/store";
import { Avatar, downloadText, EmptyState, fieldClass, GhostButton, Pagination, PrimaryButton, StatusPill } from "@/components/hr/widgets";

type Draft = {
  name: string;
  gender: Gender;
  department: string;
  designation: string;
  email: string;
  phone: string;
  joinDate: string;
  status: EmpStatus;
  basic: string;
  hra: string;
  special: string;
  pf: string;
  tax: string;
  other: string;
};

const emptyDraft = (): Draft => ({
  name: "",
  gender: "m",
  department: "Product",
  designation: "Associate",
  email: "",
  phone: "",
  joinDate: "2026-10-08",
  status: "active",
  basic: "",
  hra: "",
  special: "",
  pf: "",
  tax: "",
  other: "",
});

function fromEmployee(e: Employee): Draft {
  return {
    name: e.name,
    gender: e.gender,
    department: e.department,
    designation: e.designation,
    email: e.email,
    phone: e.phone,
    joinDate: e.joinDate,
    status: e.status,
    basic: String(e.basic),
    hra: String(e.hra),
    special: String(e.special),
    pf: String(e.pf),
    tax: String(e.tax),
    other: String(e.other),
  };
}

function num(value: string) {
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0) return null;
  return Math.round(n);
}

export function EmployeesView() {
  const employees = useHr((s) => s.employees);
  const leaves = useHr((s) => s.leaves);
  const marks = useHr((s) => s.marks);
  const period = useHr((s) => s.period);
  const addEmployee = useHr((s) => s.addEmployee);
  const updateEmployee = useHr((s) => s.updateEmployee);
  const setStatus = useHr((s) => s.setStatus);
  const [query, setQuery] = useState("");
  const [dept, setDept] = useState("all");
  const [statusFilter, setStatusFilter] = useState<"all" | EmpStatus>("all");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [editing, setEditing] = useState<string | null>(null);
  const [profile, setProfile] = useState<string | null>(null);

  const departments = useMemo(() => Array.from(new Set([...DEPARTMENTS, ...employees.map((e) => e.department)])).sort(), [employees]);
  const filtered = employees.filter((e) => {
    if (dept !== "all" && e.department !== dept) return false;
    if (statusFilter !== "all" && e.status !== statusFilter) return false;
    const hay = `${e.name} ${e.code} ${e.email} ${e.designation}`.toLowerCase();
    return hay.includes(query.trim().toLowerCase());
  });
  const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const safePage = Math.min(page, pages);
  const rows = filtered.slice((safePage - 1) * pageSize, safePage * pageSize);
  const activeCount = employees.filter((e) => e.status === "active").length;
  const person = employees.find((e) => e.id === profile);

  const save = () => {
    if (!draft) return;
    if (draft.name.trim().length < 2) {
      toast.error("Enter the employee name");
      return;
    }
    const basic = num(draft.basic);
    const hra = num(draft.hra);
    const special = num(draft.special);
    const pf = num(draft.pf);
    const tax = num(draft.tax);
    const other = num(draft.other);
    if ([basic, hra, special, pf, tax, other].some((n) => n === null)) {
      toast.error("Salary fields must be zero or more");
      return;
    }
    const gross = (basic ?? 0) + (hra ?? 0) + (special ?? 0);
    const ded = (pf ?? 0) + (tax ?? 0) + (other ?? 0);
    if (gross - ded < 0) {
      toast.error("Deductions cannot be more than gross pay");
      return;
    }
    const email = draft.email.trim().toLowerCase();
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.error("Enter a valid email");
      return;
    }
    if (employees.some((e) => e.email === email && e.id !== editing && email)) {
      toast.error("That email is already used");
      return;
    }
    const payload = {
      name: draft.name.trim(),
      gender: draft.gender,
      department: draft.department,
      designation: draft.designation.trim() || "Associate",
      email,
      phone: draft.phone.trim(),
      joinDate: draft.joinDate,
      status: draft.status,
      basic: basic ?? 0,
      hra: hra ?? 0,
      special: special ?? 0,
      pf: pf ?? 0,
      tax: tax ?? 0,
      other: other ?? 0,
    };
    if (editing) {
      updateEmployee(editing, payload);
      toast.success("Employee updated");
    } else {
      const created = addEmployee(payload);
      toast.success(`${created.name} added as ${created.code}`);
    }
    setDraft(null);
    setEditing(null);
  };

  return (
    <div className="flex flex-col gap-5 p-4 sm:p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Employees</h1>
          <p className="text-sm text-muted">
            {activeCount} active · {employees.length - activeCount} inactive
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <GhostButton onClick={() => downloadText("employees.csv", employeesCsv(employees))}>Export CSV</GhostButton>
          <PrimaryButton
            onClick={() => {
              setEditing(null);
              setDraft(emptyDraft());
            }}
          >
            <Plus className="size-4" /> Add employee
          </PrimaryButton>
        </div>
      </div>
      <section className="sheet overflow-hidden rounded-2xl border border-border bg-surface shadow-card">
        <div className="grid gap-3 border-b border-border p-4 sm:grid-cols-3">
          <input className={fieldClass} placeholder="Search name, code, email" value={query} onChange={(e) => { setQuery(e.target.value); setPage(1); }} />
          <select className={fieldClass} value={dept} onChange={(e) => { setDept(e.target.value); setPage(1); }}>
            <option value="all">All departments</option>
            {departments.map((d) => (
              <option key={d}>{d}</option>
            ))}
          </select>
          <select className={fieldClass} value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value as "all" | EmpStatus); setPage(1); }}>
            <option value="all">Active and inactive</option>
            <option value="active">Active only</option>
            <option value="inactive">Inactive only</option>
          </select>
        </div>
        {rows.length === 0 ? (
          <EmptyState title="No matching employees" body="Change the filters, or add someone new." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-3xl text-left text-sm">
              <thead className="text-muted">
                <tr className="border-b border-border">
                  <th className="px-4 py-3 font-medium">Employee</th>
                  <th className="px-4 py-3 font-medium">Department</th>
                  <th className="px-4 py-3 font-medium">Gross</th>
                  <th className="px-4 py-3 font-medium">Net</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 font-medium">Action</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((e) => (
                  <tr key={e.id} className={clsx("border-b border-border last:border-0", e.status === "inactive" && "opacity-70")}>
                    <td className="px-4 py-3">
                      <button type="button" onClick={() => setProfile(e.id)} className="flex items-center gap-3 text-left">
                        <Avatar name={e.name} female={e.gender === "f"} />
                        <span>
                          <span className="block font-semibold">{e.name}</span>
                          <span className="block text-xs text-muted">{e.code} · {e.designation}</span>
                        </span>
                      </button>
                    </td>
                    <td className="px-4 py-3">{e.department}</td>
                    <td className="px-4 py-3">{inr(grossOf(e))}</td>
                    <td className="px-4 py-3 font-semibold">{inr(grossOf(e) - statutoryOf(e))}</td>
                    <td className="px-4 py-3">
                      {e.status === "active" ? <StatusPill tone="good">Active</StatusPill> : <StatusPill tone="neutral">Inactive</StatusPill>}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex gap-1">
                        <button
                          type="button"
                          className="h-11 rounded-xl px-3 text-sm font-medium hover:bg-bg"
                          onClick={() => {
                            const next = e.status === "active" ? "inactive" : "active";
                            setStatus(e.id, next);
                            toast.success(`${e.name} is now ${next}`);
                          }}
                        >
                          {e.status === "active" ? "Deactivate" : "Activate"}
                        </button>
                        <button
                          type="button"
                          className="h-11 rounded-xl px-3 text-sm font-medium text-primary hover:bg-primary-soft"
                          onClick={() => {
                            setEditing(e.id);
                            setDraft(fromEmployee(e));
                          }}
                        >
                          Edit
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <Pagination page={safePage} pages={pages} pageSize={pageSize} total={filtered.length} noun="employees" onPage={setPage} onPageSize={(n) => { setPageSize(n); setPage(1); }} />
      </section>

      {draft ? (
        <EmployeeForm
          title={editing ? "Edit employee" : "New employee"}
          draft={draft}
          departments={departments}
          onChange={setDraft}
          onClose={() => { setDraft(null); setEditing(null); }}
          onSave={save}
        />
      ) : null}

      {person ? (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-3 sm:items-center" onMouseDown={() => setProfile(null)}>
          <div role="dialog" aria-label={person.name} className="max-h-[92dvh] w-full max-w-lg overflow-y-auto rounded-2xl bg-surface p-5 shadow-card" onMouseDown={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-3">
              <Avatar name={person.name} female={person.gender === "f"} />
              <div className="min-w-0 flex-1">
                <h2 className="truncate text-lg font-semibold">{person.name}</h2>
                <p className="text-sm text-muted">{person.code} · {person.designation} · {person.department}</p>
              </div>
              {person.status === "active" ? <StatusPill tone="good">Active</StatusPill> : <StatusPill tone="neutral">Inactive</StatusPill>}
            </div>
            <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
              <Info label="Email" value={person.email || "—"} />
              <Info label="Phone" value={person.phone || "—"} />
              <Info label="Joined" value={person.joinDate} />
              <Info label="Net salary" value={inr(grossOf(person) - statutoryOf(person))} />
              <Info label="Basic" value={inr(person.basic)} />
              <Info label="HRA" value={inr(person.hra)} />
              <Info label="Special" value={inr(person.special)} />
              <Info label="PF" value={inr(person.pf)} />
              <Info label="Tax" value={inr(person.tax)} />
              <Info label="Other" value={inr(person.other)} />
            </dl>
            <h3 className="mt-4 text-sm font-semibold">Leave balance</h3>
            <div className="mt-2 grid grid-cols-2 gap-2 text-sm sm:grid-cols-4">
              {LEAVE_TYPES.map((type) => {
                const used = leaveReserved(leaves, person.id, type);
                const left = Math.max(0, LEAVE_QUOTA[type] - used);
                return (
                  <div key={type} className="rounded-xl bg-bg px-3 py-2">
                    <p className="text-xs text-muted">{type}</p>
                    <p className="font-semibold">{type === "Unpaid" ? "Open" : `${left} left`}</p>
                  </div>
                );
              })}
            </div>
            <p className="mt-3 text-xs text-muted">
              This month attendance exceptions: {monthDates(period).filter((d) => {
                const kind = dayKind(person, d, marks);
                return kind === "absent" || kind === "half" || kind === "leave" || kind === "unpaid";
              }).length}
            </p>
            <div className="mt-5 flex flex-wrap justify-end gap-2">
              <GhostButton onClick={() => setProfile(null)}>Close</GhostButton>
              <GhostButton
                onClick={() => {
                  const next = person.status === "active" ? "inactive" : "active";
                  setStatus(person.id, next);
                  toast.success(`${person.name} is now ${next}`);
                }}
              >
                {person.status === "active" ? "Mark inactive" : "Mark active"}
              </GhostButton>
              <PrimaryButton
                onClick={() => {
                  setEditing(person.id);
                  setDraft(fromEmployee(person));
                  setProfile(null);
                }}
              >
                Edit
              </PrimaryButton>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-bg px-3 py-2">
      <dt className="text-xs text-muted">{label}</dt>
      <dd className="truncate font-medium">{value}</dd>
    </div>
  );
}

function EmployeeForm({
  title,
  draft,
  departments,
  onChange,
  onClose,
  onSave,
}: {
  title: string;
  draft: Draft;
  departments: string[];
  onChange: (draft: Draft) => void;
  onClose: () => void;
  onSave: () => void;
}) {
  const set = (patch: Partial<Draft>) => onChange({ ...draft, ...patch });
  const gross = (num(draft.basic) ?? 0) + (num(draft.hra) ?? 0) + (num(draft.special) ?? 0);
  const ded = (num(draft.pf) ?? 0) + (num(draft.tax) ?? 0) + (num(draft.other) ?? 0);
  const roles = ROLES[draft.department] ?? [];
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-3 sm:items-center" onMouseDown={onClose}>
      <div role="dialog" aria-label={title} className="max-h-[92dvh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-surface p-5 shadow-card" onMouseDown={(e) => e.stopPropagation()}>
        <h2 className="text-lg font-semibold">{title}</h2>
        <p className="mt-1 text-sm text-muted">Inactive people stay on record but drop out of future payroll runs.</p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <label className="text-sm sm:col-span-2">
            <span className="mb-1 block font-medium">Full name</span>
            <input className={fieldClass} value={draft.name} onChange={(e) => set({ name: e.target.value })} />
          </label>
          <label className="text-sm">
            <span className="mb-1 block font-medium">Gender</span>
            <select className={fieldClass} value={draft.gender} onChange={(e) => set({ gender: e.target.value as Gender })}>
              <option value="m">Male</option>
              <option value="f">Female</option>
            </select>
          </label>
          <label className="text-sm">
            <span className="mb-1 block font-medium">Status</span>
            <select className={fieldClass} value={draft.status} onChange={(e) => set({ status: e.target.value as EmpStatus })}>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </label>
          <label className="text-sm">
            <span className="mb-1 block font-medium">Department</span>
            <select className={fieldClass} value={draft.department} onChange={(e) => set({ department: e.target.value })}>
              {departments.map((d) => (
                <option key={d}>{d}</option>
              ))}
            </select>
          </label>
          <label className="text-sm">
            <span className="mb-1 block font-medium">Designation</span>
            <input className={fieldClass} list="role-list" value={draft.designation} onChange={(e) => set({ designation: e.target.value })} />
            <datalist id="role-list">
              {roles.map((role) => (
                <option key={role} value={role} />
              ))}
            </datalist>
          </label>
          <label className="text-sm">
            <span className="mb-1 block font-medium">Email</span>
            <input className={fieldClass} value={draft.email} onChange={(e) => set({ email: e.target.value })} />
          </label>
          <label className="text-sm">
            <span className="mb-1 block font-medium">Phone</span>
            <input className={fieldClass} value={draft.phone} onChange={(e) => set({ phone: e.target.value })} />
          </label>
          <label className="text-sm">
            <span className="mb-1 block font-medium">Join date</span>
            <input type="date" className={fieldClass} value={draft.joinDate} onChange={(e) => set({ joinDate: e.target.value })} />
          </label>
          {([
            ["basic", "Basic"],
            ["hra", "HRA"],
            ["special", "Special allowance"],
            ["pf", "PF deduction"],
            ["tax", "Tax"],
            ["other", "Other deduction"],
          ] as const).map(([key, label]) => (
            <label key={key} className="text-sm">
              <span className="mb-1 block font-medium">{label}</span>
              <input className={fieldClass} inputMode="numeric" value={draft[key]} onChange={(e) => set({ [key]: e.target.value })} />
            </label>
          ))}
        </div>
        <p className="mt-3 text-sm text-muted">
          Gross {inr(gross)} · Deductions {inr(ded)} · Net <span className="font-semibold text-fg">{inr(gross - ded)}</span>
        </p>
        <div className="mt-5 flex justify-end gap-2">
          <GhostButton onClick={onClose}>Cancel</GhostButton>
          <PrimaryButton onClick={onSave}>Save employee</PrimaryButton>
        </div>
      </div>
    </div>
  );
}
