export type Gender = "m" | "f";
export type EmpStatus = "active" | "inactive";
export type MarkStatus = "absent" | "half" | "leave" | "unpaid";
export type DayKind = "present" | MarkStatus | "weekoff" | "holiday";
export type LeaveType = "Casual" | "Sick" | "Earned" | "Unpaid";
export type LeaveStatus = "pending" | "approved" | "rejected";
export type ViewId =
  | "dashboard"
  | "employees"
  | "attendance"
  | "leave"
  | "payroll"
  | "reports"
  | "documents"
  | "settings";

export type Employee = {
  id: string;
  code: string;
  name: string;
  gender: Gender;
  department: string;
  designation: string;
  email: string;
  phone: string;
  joinDate: string;
  status: EmpStatus;
  basic: number;
  hra: number;
  special: number;
  pf: number;
  tax: number;
  other: number;
};

export type AttendanceMark = {
  employeeId: string;
  date: string;
  status: MarkStatus;
};

export type LeaveRequest = {
  id: string;
  employeeId: string;
  type: LeaveType;
  from: string;
  to: string;
  days: number;
  reason: string;
  status: LeaveStatus;
  appliedOn: string;
};

export type PayLine = {
  employeeId: string;
  gross: number;
  deductions: number;
  net: number;
  bonus: number;
  lop: number;
  extra: number;
};

export type Adjustment = { bonus: number; extra: number };

export type DocItem = {
  id: string;
  title: string;
  category: string;
  employeeId?: string;
  note: string;
  date: string;
};

export type CompanySettings = {
  company: string;
  adminName: string;
  adminRole: string;
  workingDays: number;
  payDay: number;
};

export type HrData = {
  employees: Employee[];
  marks: AttendanceMark[];
  leaves: LeaveRequest[];
  snapshots: Record<string, PayLine[]>;
  adjustments: Record<string, Adjustment>;
  documents: DocItem[];
  settings: CompanySettings;
  period: string;
};

export const TODAY = "2026-10-08";
export const TARGET_NET = 8245600;

export const DEPARTMENTS = [
  "Product",
  "Marketing",
  "Sales",
  "HR",
  "Finance",
  "Engineering",
  "Operations",
  "Support",
  "Design",
] as const;

export const ROLES: Record<string, string[]> = {
  Product: ["Product Manager", "Associate PM", "Product Analyst"],
  Marketing: ["Marketing Lead", "Content Strategist", "Growth Associate"],
  Sales: ["Sales Executive", "Account Manager", "Sales Lead"],
  HR: ["HR Executive", "HR Manager", "Recruiter"],
  Finance: ["Finance Analyst", "Accountant", "Finance Manager"],
  Engineering: ["Software Engineer", "Senior Engineer", "QA Engineer"],
  Operations: ["Ops Executive", "Ops Manager", "Admin Associate"],
  Support: ["Support Executive", "Support Lead", "Customer Associate"],
  Design: ["Product Designer", "Visual Designer", "Design Intern"],
};

export const DOC_CATEGORIES = ["Policy", "Payroll", "Offer", "ID proof", "Other"] as const;

export const LEAVE_QUOTA: Record<LeaveType, number> = {
  Casual: 12,
  Sick: 8,
  Earned: 15,
  Unpaid: 365,
};

export const LEAVE_TYPES: LeaveType[] = ["Casual", "Sick", "Earned", "Unpaid"];

const HOLIDAYS = new Set(["2026-01-26", "2026-08-15", "2026-10-02"]);

const MONTH_NAMES = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

const SHORT_MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export function monthLabel(ym: string) {
  const [y, m] = ym.split("-");
  return `${MONTH_NAMES[Number(m) - 1] ?? ym} ${y}`;
}

export function shortMonth(ym: string) {
  const m = Number(ym.split("-")[1]);
  return SHORT_MONTHS[m - 1] ?? ym;
}

export function inr(n: number) {
  const rounded = Math.round(n);
  const formatted = Math.abs(rounded).toLocaleString("en-IN");
  return `${rounded < 0 ? "-" : ""}₹ ${formatted}`;
}

export function isoDate(d: Date) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function prettyDate(iso: string) {
  const [y, m, d] = iso.split("-").map(Number);
  return `${d} ${SHORT_MONTHS[(m ?? 1) - 1]} ${y}`;
}

export function isWeekoff(iso: string) {
  const [y, m, d] = iso.split("-").map(Number);
  const day = new Date(y, (m ?? 1) - 1, d).getDay();
  return day === 0 || day === 6;
}

export function isHoliday(iso: string) {
  return HOLIDAYS.has(iso);
}

export function weekdayShort(iso: string) {
  const [y, m, d] = iso.split("-").map(Number);
  return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][new Date(y, (m ?? 1) - 1, d).getDay()];
}

export function monthEndIso(ym: string) {
  const [y, m] = ym.split("-").map(Number);
  return isoDate(new Date(y, m, 0));
}

export function daysInMonth(ym: string) {
  const [y, m] = ym.split("-").map(Number);
  return new Date(y, m, 0).getDate();
}

export function monthDates(ym: string) {
  const n = daysInMonth(ym);
  return Array.from({ length: n }, (_, i) => `${ym}-${String(i + 1).padStart(2, "0")}`);
}

export function eachWorkingDay(from: string, to: string) {
  const out: string[] = [];
  const [ys, ms, ds] = from.split("-").map(Number);
  const [ye, me, de] = to.split("-").map(Number);
  const cur = new Date(ys, (ms ?? 1) - 1, ds);
  const end = new Date(ye, (me ?? 1) - 1, de);
  if (Number.isNaN(cur.getTime()) || Number.isNaN(end.getTime()) || cur > end) return out;
  while (cur <= end) {
    const iso = isoDate(cur);
    if (!isWeekoff(iso) && !isHoliday(iso)) out.push(iso);
    cur.setDate(cur.getDate() + 1);
  }
  return out;
}

export function grossOf(e: Pick<Employee, "basic" | "hra" | "special">) {
  return e.basic + e.hra + e.special;
}

export function statutoryOf(e: Pick<Employee, "pf" | "tax" | "other">) {
  return e.pf + e.tax + e.other;
}

export function codeNum(code: string) {
  return Number(code.replace(/\D/g, "")) || 0;
}

export function byCode<T extends { code: string }>(a: T, b: T) {
  return codeNum(a.code) - codeNum(b.code);
}

export function nextIdentity(employees: Employee[]) {
  const max = employees.reduce((m, e) => Math.max(m, codeNum(e.code)), 0) + 1;
  return { id: `e${String(max).padStart(3, "0")}`, code: `EMP${String(max).padStart(3, "0")}` };
}

export function employeeMap(list: Employee[]) {
  return new Map(list.map((e) => [e.id, e]));
}

export function eligible(e: Employee, month: string) {
  return e.status === "active" && e.joinDate <= monthEndIso(month);
}

export function dayKind(employee: Employee, date: string, marks: AttendanceMark[]): DayKind {
  if (date < employee.joinDate) return "absent";
  if (isHoliday(date)) return "holiday";
  if (isWeekoff(date)) return "weekoff";
  const mark = marks.find((m) => m.employeeId === employee.id && m.date === date);
  return mark?.status ?? "present";
}

export function lopDays(employee: Employee, month: string, marks: AttendanceMark[]) {
  let lop = 0;
  for (const date of monthDates(month)) {
    if (date < employee.joinDate) continue;
    const kind = dayKind(employee, date, marks);
    if (kind === "absent" || kind === "unpaid") lop += 1;
    else if (kind === "half") lop += 0.5;
  }
  return lop;
}

export function blankLine(employee: Employee): PayLine {
  const gross = grossOf(employee);
  const deductions = statutoryOf(employee);
  return {
    employeeId: employee.id,
    gross,
    deductions,
    net: gross - deductions,
    bonus: 0,
    lop: 0,
    extra: 0,
  };
}

export function computeLive(data: Pick<HrData, "employees" | "marks" | "adjustments" | "settings">, month: string) {
  const days = Math.max(1, data.settings.workingDays);
  return data.employees
    .filter((e) => eligible(e, month))
    .sort(byCode)
    .map((e) => {
      const gross = grossOf(e);
      const statutory = statutoryOf(e);
      const adj = data.adjustments[`${month}:${e.id}`] ?? { bonus: 0, extra: 0 };
      const bonus = Math.max(0, Math.round(adj.bonus || 0));
      const extra = Math.max(0, Math.round(adj.extra || 0));
      const lop = Math.round((gross / days) * lopDays(e, month, data.marks));
      const deductions = statutory + extra + lop;
      return {
        employeeId: e.id,
        gross,
        deductions,
        net: gross + bonus - deductions,
        bonus,
        lop,
        extra,
      } satisfies PayLine;
    });
}

export function linesFor(data: HrData, month: string) {
  const snap = data.snapshots[month];
  if (snap) return { lines: snap, locked: true };
  return { lines: computeLive(data, month), locked: false };
}

export function sumLines(lines: PayLine[]) {
  return lines.reduce(
    (a, l) => ({
      gross: a.gross + l.gross + l.bonus,
      deductions: a.deductions + l.deductions,
      net: a.net + l.net,
      lop: a.lop + l.lop,
      count: a.count + 1,
    }),
    { gross: 0, deductions: 0, net: 0, lop: 0, count: 0 },
  );
}

export function leaveReserved(leaves: LeaveRequest[], employeeId: string, type: LeaveType) {
  return leaves
    .filter((l) => l.employeeId === employeeId && l.type === type && l.status !== "rejected")
    .reduce((s, l) => s + l.days, 0);
}

export function trendPoints(snapshots: Record<string, PayLine[]>) {
  return Object.keys(snapshots)
    .sort()
    .map((month) => ({
      month,
      label: shortMonth(month),
      total: snapshots[month].reduce((s, l) => s + l.net, 0),
    }));
}

export type Notice = { id: string; title: string; detail: string; view: ViewId };

export function notifications(data: HrData): Notice[] {
  const items: Notice[] = [];
  const pending = data.leaves.filter((l) => l.status === "pending");
  if (pending.length) {
    items.push({
      id: "leave",
      title: `${pending.length} leave ${pending.length === 1 ? "request" : "requests"} waiting`,
      detail: "Approve or reject before payroll locks",
      view: "leave",
    });
  }
  const dueMonth = TODAY.slice(0, 7);
  const day = Number(TODAY.slice(8, 10));
  if (!data.snapshots[dueMonth] && day >= data.settings.payDay) {
    items.push({
      id: "pay",
      title: `${monthLabel(dueMonth)} payroll is due`,
      detail: `Pay day is the ${data.settings.payDay}th. Review LOP and complete the run.`,
      view: "payroll",
    });
  }
  return items;
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function splitPay(gross: number, ded: number) {
  const basic = Math.round(gross * 0.62);
  let hra = Math.round((gross - basic) * 0.66);
  if (basic + hra > gross) hra = gross - basic;
  const special = gross - basic - hra;
  const pf = Math.round(ded * 0.62);
  let tax = Math.round((ded - pf) * 0.75);
  if (pf + tax > ded) tax = ded - pf;
  const other = ded - pf - tax;
  return { basic, hra, special, pf, tax, other };
}

function scaleLines(lines: PayLine[], factor: number) {
  if (factor === 1) return lines;
  const target = Math.round(lines.reduce((s, l) => s + l.net, 0) * factor);
  const next = lines.map((l) => {
    const gross = Math.max(0, Math.round(l.gross * factor));
    const deductions = Math.max(0, Math.round(l.deductions * factor));
    return { ...l, gross, deductions, net: gross - deductions, bonus: 0, lop: 0, extra: 0 };
  });
  let diff = target - next.reduce((s, l) => s + l.net, 0);
  let i = 0;
  while (diff !== 0 && i < next.length * 50) {
    const line = next[i % next.length];
    if (!line) break;
    if (diff > 0) {
      line.gross += 1;
      line.net += 1;
      diff -= 1;
    } else if (line.net > 1 && line.gross > 1) {
      line.gross -= 1;
      line.net -= 1;
      diff += 1;
    }
    i += 1;
  }
  return next;
}

const FIRST_M = [
  "Vivaan", "Aditya", "Vihaan", "Arjun", "Reyansh", "Ayaan", "Ishaan", "Shaurya", "Atharv", "Advik",
  "Pranav", "Kabir", "Dhruv", "Rudra", "Virat", "Dev", "Harsh", "Kunal", "Manav", "Nikhil",
  "Rahul", "Siddharth", "Tarun", "Varun", "Amit", "Deepak", "Gaurav", "Jatin", "Lokesh", "Mohit",
  "Naveen", "Pankaj", "Sachin", "Tushar", "Uday", "Vikas", "Ankit", "Rohit", "Karan", "Aarav",
];
const FIRST_F = [
  "Aanya", "Ananya", "Diya", "Myra", "Sara", "Ira", "Anika", "Navya", "Kiara", "Pari",
  "Anvi", "Prisha", "Kavya", "Isha", "Mira", "Riya", "Saanvi", "Avni", "Meera", "Nisha",
  "Shreya", "Tanvi", "Aditi", "Divya", "Ishita", "Khushi", "Lavanya", "Nikita", "Palak", "Ritika",
  "Sneha", "Trisha", "Vidya", "Anjali", "Bhavya", "Neha", "Pooja", "Gauri", "Heena", "Juhi",
];
const LAST = [
  "Sharma", "Verma", "Singh", "Patel", "Mehta", "Gupta", "Reddy", "Iyer", "Nair", "Khan",
  "Joshi", "Kapoor", "Malhotra", "Chopra", "Bose", "Das", "Banerjee", "Rao", "Pillai", "Jain",
  "Agarwal", "Mishra", "Yadav", "Chauhan", "Saxena", "Bhatt", "Shah", "Menon", "Naidu", "Gill",
  "Bansal", "Arora", "Khanna", "Sethi", "Dubey", "Pandey", "Tiwari", "Thakur", "Shetty", "Hegde",
];

function buildEmployees() {
  const named: Employee[] = [
    {
      id: "e001",
      code: "EMP001",
      name: "Aarav Sharma",
      gender: "m",
      department: "Product",
      designation: "Product Manager",
      email: "aarav.sharma@abcpvt.in",
      phone: "9811122301",
      joinDate: "2022-04-11",
      status: "active",
      basic: 45000,
      hra: 18000,
      special: 5750,
      pf: 5400,
      tax: 2500,
      other: 750,
    },
    {
      id: "e002",
      code: "EMP002",
      name: "Neha Verma",
      gender: "f",
      department: "Marketing",
      designation: "Marketing Lead",
      email: "neha.verma@abcpvt.in",
      phone: "9822233402",
      joinDate: "2023-01-16",
      status: "active",
      basic: 36000,
      hra: 14400,
      special: 5000,
      pf: 4320,
      tax: 1500,
      other: 380,
    },
    {
      id: "e003",
      code: "EMP003",
      name: "Rohit Singh",
      gender: "m",
      department: "Sales",
      designation: "Sales Executive",
      email: "rohit.singh@abcpvt.in",
      phone: "9833344503",
      joinDate: "2021-08-02",
      status: "active",
      basic: 48000,
      hra: 19200,
      special: 5100,
      pf: 5760,
      tax: 3000,
      other: 690,
    },
    {
      id: "e004",
      code: "EMP004",
      name: "Pooja Mehta",
      gender: "f",
      department: "HR",
      designation: "HR Executive",
      email: "pooja.mehta@abcpvt.in",
      phone: "9844455604",
      joinDate: "2024-02-19",
      status: "active",
      basic: 32000,
      hra: 12800,
      special: 4100,
      pf: 3840,
      tax: 1400,
      other: 360,
    },
    {
      id: "e005",
      code: "EMP005",
      name: "Karan Patel",
      gender: "m",
      department: "Finance",
      designation: "Finance Analyst",
      email: "karan.patel@abcpvt.in",
      phone: "9855566705",
      joinDate: "2022-11-07",
      status: "active",
      basic: 42000,
      hra: 16800,
      special: 6300,
      pf: 5040,
      tax: 2200,
      other: 560,
    },
  ];

  const used = new Set(named.map((e) => e.name));
  const rand = mulberry32(202606);
  const count = 143;
  const weights = Array.from({ length: count }, () => 0.72 + rand() * 0.7);
  const wsum = weights.reduce((a, b) => a + b, 0);
  const namedNet = named.reduce((s, e) => s + (grossOf(e) - statutoryOf(e)), 0);
  const target = TARGET_NET - namedNet;
  const nets = weights.map((w) => Math.round((target * w) / wsum));
  let diff = target - nets.reduce((a, b) => a + b, 0);
  let guard = 0;
  while (diff !== 0 && guard < 2_000_000) {
    const idx = guard % count;
    const current = nets[idx] ?? 0;
    if (diff > 0 && current < 92000) {
      nets[idx] = current + 1;
      diff -= 1;
    } else if (diff < 0 && current > 34000) {
      nets[idx] = current - 1;
      diff += 1;
    }
    guard += 1;
  }

  const rest: Employee[] = [];
  let k = 0;
  for (let i = 0; i < count; i += 1) {
    const female = i % 2 === 1;
    let name = "";
    while (!name) {
      const first = (female ? FIRST_F : FIRST_M)[k % 40];
      const last = LAST[Math.floor(k / 2) % LAST.length];
      const candidate = `${first} ${last}`;
      k += 1;
      if (first && last && !used.has(candidate)) {
        used.add(candidate);
        name = candidate;
      }
      if (k > 8000) {
        name = `Employee ${i + 6}`;
        break;
      }
    }
    const net = nets[i] ?? 50000;
    const ratio = 0.112 + rand() * 0.025;
    const ded = Math.max(1200, Math.round((net * ratio) / (1 - ratio)));
    const gross = net + ded;
    const dept = DEPARTMENTS[i % DEPARTMENTS.length] ?? "Operations";
    const roles = ROLES[dept] ?? ["Associate"];
    const designation = roles[i % roles.length] ?? "Associate";
    const n = i + 6;
    const slug = name.toLowerCase().replace(/[^a-z]+/g, ".").replace(/^\.|\.$/g, "");
    const start = new Date(2019, 3, 1).getTime();
    const end = new Date(2025, 10, 15).getTime();
    const joined = new Date(start + Math.floor(rand() * (end - start)));
    rest.push({
      id: `e${String(n).padStart(3, "0")}`,
      code: `EMP${String(n).padStart(3, "0")}`,
      name,
      gender: female ? "f" : "m",
      department: dept,
      designation,
      email: `${slug}@abcpvt.in`,
      phone: `98${String(10000000 + ((n * 7919) % 90000000)).padStart(8, "0")}`,
      joinDate: isoDate(joined),
      status: "active",
      ...splitPay(gross, ded),
    });
  }

  return [...named, ...rest].sort(byCode);
}

function buildSnapshot(employees: Employee[], factor: number) {
  const base = employees.filter((e) => e.status === "active").sort(byCode).map(blankLine);
  return scaleLines(base, factor);
}

function buildLeaves(employees: Employee[]) {
  const pick = (code: string) => employees.find((e) => e.code === code)?.id ?? "e001";
  const specs: Array<Omit<LeaveRequest, "days">> = [
    {
      id: "l1",
      employeeId: pick("EMP001"),
      type: "Casual",
      from: "2026-10-09",
      to: "2026-10-09",
      reason: "Family function",
      status: "pending",
      appliedOn: "2026-10-03",
    },
    {
      id: "l2",
      employeeId: pick("EMP002"),
      type: "Sick",
      from: "2026-10-06",
      to: "2026-10-06",
      reason: "Fever and rest advised",
      status: "approved",
      appliedOn: "2026-10-06",
    },
    {
      id: "l3",
      employeeId: pick("EMP003"),
      type: "Earned",
      from: "2026-10-13",
      to: "2026-10-14",
      reason: "Out of station",
      status: "pending",
      appliedOn: "2026-10-01",
    },
    {
      id: "l4",
      employeeId: pick("EMP004"),
      type: "Casual",
      from: "2026-06-15",
      to: "2026-06-16",
      reason: "Personal work",
      status: "approved",
      appliedOn: "2026-06-08",
    },
    {
      id: "l5",
      employeeId: pick("EMP012"),
      type: "Sick",
      from: "2026-09-18",
      to: "2026-09-18",
      reason: "Migraine",
      status: "rejected",
      appliedOn: "2026-09-20",
    },
    {
      id: "l6",
      employeeId: pick("EMP018"),
      type: "Unpaid",
      from: "2026-10-07",
      to: "2026-10-07",
      reason: "Personal travel beyond balance",
      status: "pending",
      appliedOn: "2026-10-02",
    },
    {
      id: "l7",
      employeeId: pick("EMP009"),
      type: "Earned",
      from: "2026-10-01",
      to: "2026-10-01",
      reason: "Bank and documentation",
      status: "approved",
      appliedOn: "2026-09-25",
    },
    {
      id: "l8",
      employeeId: pick("EMP021"),
      type: "Casual",
      from: "2026-10-08",
      to: "2026-10-08",
      reason: "Parent-teacher meeting",
      status: "pending",
      appliedOn: "2026-10-07",
    },
  ];
  return specs.map((s) => ({ ...s, days: eachWorkingDay(s.from, s.to).length }));
}

function buildMarks(employees: Employee[], leaves: LeaveRequest[]) {
  const rand = mulberry32(77);
  const dates = ["2026-06-03", "2026-06-10", "2026-06-18", "2026-10-01", "2026-10-05", "2026-10-06", "2026-10-07", "2026-10-08"];
  const marks: AttendanceMark[] = [];
  for (const date of dates) {
    if (isWeekoff(date) || isHoliday(date)) continue;
    for (const e of employees) {
      const r = rand();
      if (r < 0.035) marks.push({ employeeId: e.id, date, status: "absent" });
      else if (r < 0.05) marks.push({ employeeId: e.id, date, status: "half" });
    }
  }
  for (const leave of leaves) {
    if (leave.status !== "approved") continue;
    const status: MarkStatus = leave.type === "Unpaid" ? "unpaid" : "leave";
    for (const date of eachWorkingDay(leave.from, leave.to)) {
      const idx = marks.findIndex((m) => m.employeeId === leave.employeeId && m.date === date);
      if (idx >= 0) marks.splice(idx, 1);
      marks.push({ employeeId: leave.employeeId, date, status });
    }
  }
  return marks;
}

export function createSeed(): HrData {
  const employees = buildEmployees();
  const factors: Record<string, number> = {
    "2026-01": 0.86,
    "2026-02": 0.9,
    "2026-03": 0.93,
    "2026-04": 0.955,
    "2026-05": 0.978,
    "2026-06": 1,
  };
  const snapshots: Record<string, PayLine[]> = {};
  for (const [month, factor] of Object.entries(factors)) {
    snapshots[month] = buildSnapshot(employees, factor);
  }
  const leaves = buildLeaves(employees);
  const marks = buildMarks(employees, leaves);
  const documents: DocItem[] = [
    {
      id: "d1",
      title: "Employee Handbook 2026",
      category: "Policy",
      note: "Working hours, conduct, and leave rules for ABC Pvt. Ltd.",
      date: "2026-01-06",
    },
    {
      id: "d2",
      title: "POSH Policy",
      category: "Policy",
      note: "Prevention of sexual harassment at the workplace.",
      date: "2026-01-06",
    },
    {
      id: "d3",
      title: "Payroll Calendar 2026",
      category: "Payroll",
      note: "Salaries are processed by the 7th, or the previous working day.",
      date: "2026-04-01",
    },
    {
      id: "d4",
      title: "Offer — Aarav Sharma",
      category: "Offer",
      employeeId: "e001",
      note: "Product Manager, Product department.",
      date: "2022-04-01",
    },
    {
      id: "d5",
      title: "Form 16 checklist",
      category: "Payroll",
      note: "Collect PAN and investment proofs before January.",
      date: "2026-01-15",
    },
  ];
  return {
    employees,
    marks,
    leaves,
    snapshots,
    adjustments: {},
    documents,
    settings: {
      company: "ABC Pvt. Ltd.",
      adminName: "Rahul Mehta",
      adminRole: "Admin",
      workingDays: 26,
      payDay: 7,
    },
    period: "2026-06",
  };
}

export function csvCell(value: string | number) {
  const s = String(value ?? "");
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export function payrollCsv(lines: PayLine[], employees: Employee[], month: string) {
  const map = employeeMap(employees);
  const header = ["Code", "Name", "Department", "Designation", "Gross", "Bonus", "LOP", "Deductions", "Net", "Month"];
  const rows = lines.map((l) => {
    const e = map.get(l.employeeId);
    return [e?.code ?? "", e?.name ?? "", e?.department ?? "", e?.designation ?? "", l.gross, l.bonus, l.lop, l.deductions, l.net, month]
      .map(csvCell)
      .join(",");
  });
  return [header.join(","), ...rows].join("\n");
}

export function employeesCsv(employees: Employee[]) {
  const header = ["Code", "Name", "Status", "Department", "Designation", "Email", "Phone", "Join date", "Basic", "HRA", "Special", "PF", "Tax", "Other", "Gross", "Deductions", "Net"];
  const rows = [...employees].sort(byCode).map((e) =>
    [e.code, e.name, e.status, e.department, e.designation, e.email, e.phone, e.joinDate, e.basic, e.hra, e.special, e.pf, e.tax, e.other, grossOf(e), statutoryOf(e), grossOf(e) - statutoryOf(e)]
      .map(csvCell)
      .join(","),
  );
  return [header.join(","), ...rows].join("\n");
}
