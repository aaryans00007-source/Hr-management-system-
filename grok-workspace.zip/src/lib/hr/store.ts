import { useEffect } from "react";
import { create } from "zustand";
import {
  byCode,
  computeLive,
  createSeed,
  eachWorkingDay,
  LEAVE_QUOTA,
  leaveReserved,
  nextIdentity,
  type AttendanceMark,
  type CompanySettings,
  type DocItem,
  type Employee,
  type EmpStatus,
  type HrData,
  type LeaveRequest,
  type LeaveType,
  type MarkStatus,
  type ViewId,
} from "@/lib/hr/model";

const KEY = "bizhr-ledger-v1";

type Actions = {
  setView: (view: ViewId) => void;
  setPeriod: (period: string) => void;
  addEmployee: (input: Omit<Employee, "id" | "code">) => Employee;
  updateEmployee: (id: string, patch: Partial<Omit<Employee, "id" | "code">>) => void;
  setStatus: (id: string, status: EmpStatus) => void;
  setMark: (employeeId: string, date: string, status: MarkStatus | "present") => void;
  clearDay: (date: string) => void;
  addLeave: (input: {
    employeeId: string;
    type: LeaveType;
    from: string;
    to: string;
    reason: string;
  }) => { ok: true } | { ok: false; reason: string };
  decideLeave: (id: string, status: "approved" | "rejected") => void;
  withdrawLeave: (id: string) => void;
  setAdjustment: (month: string, employeeId: string, patch: { bonus?: number; extra?: number }) => void;
  completePayroll: (month: string) => { ok: true } | { ok: false; reason: string };
  reopenPayroll: (month: string) => void;
  addDocument: (doc: Omit<DocItem, "id">) => void;
  removeDocument: (id: string) => void;
  updateSettings: (patch: Partial<CompanySettings>) => void;
  loadData: (data: HrData) => void;
  resetDemo: () => void;
};

export type HrState = HrData & { view: ViewId; hydrated: boolean } & Actions;

export const useHr = create<HrState>()((set, get) => ({
  ...createSeed(),
  view: "payroll",
  hydrated: false,
  setView: (view) => set({ view }),
  setPeriod: (period) => set({ period }),
  addEmployee: (input) => {
    const { id, code } = nextIdentity(get().employees);
    const employee: Employee = {
      ...input,
      id,
      code,
      name: input.name.trim(),
      email: input.email.trim().toLowerCase(),
      designation: input.designation.trim(),
      phone: input.phone.trim(),
    };
    set((s) => ({ employees: [...s.employees, employee].sort(byCode) }));
    return employee;
  },
  updateEmployee: (id, patch) =>
    set((s) => ({
      employees: s.employees.map((e) =>
        e.id === id
          ? {
              ...e,
              ...patch,
              id: e.id,
              code: e.code,
              name: patch.name?.trim() ?? e.name,
              email: (patch.email ?? e.email).trim().toLowerCase(),
              designation: patch.designation?.trim() ?? e.designation,
            }
          : e,
      ),
    })),
  setStatus: (id, status) =>
    set((s) => ({
      employees: s.employees.map((e) => (e.id === id ? { ...e, status } : e)),
    })),
  setMark: (employeeId, date, status) =>
    set((s) => {
      const marks = s.marks.filter((m) => !(m.employeeId === employeeId && m.date === date));
      if (status === "present") return { marks };
      const next: AttendanceMark = { employeeId, date, status };
      return { marks: [...marks, next] };
    }),
  clearDay: (date) => set((s) => ({ marks: s.marks.filter((m) => m.date !== date) })),
  addLeave: (input) => {
    const s = get();
    const days = eachWorkingDay(input.from, input.to);
    if (!days.length) return { ok: false, reason: "Choose at least one working day." };
    if (!input.reason.trim()) return { ok: false, reason: "Add a short reason." };
    if (input.type !== "Unpaid") {
      const left = LEAVE_QUOTA[input.type] - leaveReserved(s.leaves, input.employeeId, input.type);
      if (days.length > left) {
        return { ok: false, reason: `Only ${Math.max(0, left)} ${input.type.toLowerCase()} day${left === 1 ? "" : "s"} left.` };
      }
    }
    const n = s.leaves.reduce((m, l) => Math.max(m, Number(l.id.slice(1)) || 0), 0) + 1;
    const leave: LeaveRequest = {
      id: `l${n}`,
      employeeId: input.employeeId,
      type: input.type,
      from: input.from,
      to: input.to,
      days: days.length,
      reason: input.reason.trim(),
      status: "pending",
      appliedOn: new Date().toISOString().slice(0, 10),
    };
    set({ leaves: [leave, ...s.leaves] });
    return { ok: true };
  },
  decideLeave: (id, status) =>
    set((s) => {
      const leave = s.leaves.find((l) => l.id === id);
      if (!leave || leave.status !== "pending") return {};
      const leaves = s.leaves.map((l) => (l.id === id ? { ...l, status } : l));
      if (status !== "approved") return { leaves };
      const dates = eachWorkingDay(leave.from, leave.to);
      const markStatus: MarkStatus = leave.type === "Unpaid" ? "unpaid" : "leave";
      const marks = s.marks.filter((m) => !(m.employeeId === leave.employeeId && dates.includes(m.date)));
      return {
        leaves,
        marks: [...marks, ...dates.map((date) => ({ employeeId: leave.employeeId, date, status: markStatus }))],
      };
    }),
  withdrawLeave: (id) =>
    set((s) => ({
      leaves: s.leaves.filter((l) => !(l.id === id && l.status === "pending")),
    })),
  setAdjustment: (month, employeeId, patch) =>
    set((s) => {
      if (s.snapshots[month]) return {};
      const key = `${month}:${employeeId}`;
      const prev = s.adjustments[key] ?? { bonus: 0, extra: 0 };
      return { adjustments: { ...s.adjustments, [key]: { ...prev, ...patch } } };
    }),
  completePayroll: (month) => {
    const data = get();
    if (data.snapshots[month]) return { ok: false, reason: "This month is already completed." };
    const lines = computeLive(data, month);
    if (!lines.length) return { ok: false, reason: "No active employees to pay in this month." };
    if (lines.some((l) => l.net < 0)) return { ok: false, reason: "Fix negative net pay before completing." };
    set({ snapshots: { ...data.snapshots, [month]: lines } });
    return { ok: true };
  },
  reopenPayroll: (month) =>
    set((s) => {
      const snapshots = { ...s.snapshots };
      delete snapshots[month];
      return { snapshots };
    }),
  addDocument: (doc) =>
    set((s) => {
      const n = s.documents.reduce((m, d) => Math.max(m, Number(d.id.slice(1)) || 0), 0) + 1;
      return { documents: [{ ...doc, id: `d${n}` }, ...s.documents] };
    }),
  removeDocument: (id) => set((s) => ({ documents: s.documents.filter((d) => d.id !== id) })),
  updateSettings: (patch) => set((s) => ({ settings: { ...s.settings, ...patch } })),
  loadData: (data) => set({ ...data, view: "payroll" }),
  resetDemo: () => set({ ...createSeed(), view: "payroll" }),
}));

function payload(s: HrState): HrData {
  return {
    employees: s.employees,
    marks: s.marks,
    leaves: s.leaves,
    snapshots: s.snapshots,
    adjustments: s.adjustments,
    documents: s.documents,
    settings: s.settings,
    period: s.period,
  };
}

function isHrData(value: unknown): value is HrData {
  if (!value || typeof value !== "object") return false;
  const v = value as Partial<HrData>;
  return Array.isArray(v.employees) && v.employees.length > 0 && !!v.settings && !!v.snapshots && Array.isArray(v.leaves) && Array.isArray(v.marks) && Array.isArray(v.documents);
}

export function useHydrateHr() {
  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const parsed: unknown = JSON.parse(raw);
        if (isHrData(parsed)) {
          useHr.setState({ ...parsed, hydrated: true });
          return;
        }
      }
    } catch {
      /* keep the demo seed */
    }
    useHr.setState({ hydrated: true });
  }, []);

  useEffect(() => {
    return useHr.subscribe((s) => {
      if (!s.hydrated) return;
      try {
        localStorage.setItem(KEY, JSON.stringify(payload(s)));
      } catch {
        /* ignore quota */
      }
    });
  }, []);
}
